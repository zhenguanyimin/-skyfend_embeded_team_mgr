#ifndef BRT_RFCOMM_IPC_H__
#define BRT_RFCOMM_IPC_H__

#include <stdint.h>

struct tag_rfcomm_msg_header {
	uint32_t	handle;
	uint8_t		credit;
	uint16_t	len;
	uint8_t		data[0];
}  __attribute__((packed)); 
typedef struct tag_rfcomm_msg_header rfcomm_msg_header_t;

typedef void (*rfcomm_ipc_message_cbk)(rfcomm_msg_header_t *msg);

void rfcomm_ipc_init_client(rfcomm_ipc_message_cbk cbk);
void rfcomm_ipc_done_client();
int rfcomm_ipc_send_data_client(uint32_t handle, uint8_t credit, void *buf, size_t size);

#endif /* BRT_RFCOMM_IPC_H__ */
