#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>
#include "ring_buffer.h"

//#define AUDIO_RECORD_READ_AGGRESSIVE

#define DBG(...) do { \
        printf(__VA_ARGS__); \
        printf("\n"); \
    } while (0);

#define QUEUE_BUFFER_SIZE (4 * 8000 * 2 * 2)
#define AUDIO_DATA_UNIT_SIZE 2048


typedef struct tag_ring_buffer {
	ring_buffer_t common;
	pthread_mutex_t mutex;
	pthread_cond_t  cond;

	size_t buf_size;
	unsigned char *audio_data_queue;
	size_t read_idx;
	size_t write_idx;
	size_t delta;

	/* start/stop the ring buffer which means to
	   leave from block when pull data from or push data from the ring-buffer. */
	unsigned char avail;
	unsigned char pull_block;
	unsigned char push_block;
} ring_buffer_impl_t;

static int ring_buffer_push(ring_buffer_t *rb, unsigned char *buffer, int length);
static int ring_buffer_pull(ring_buffer_t *rb, unsigned char *buffer, int length);
static int ring_buffer_avail(ring_buffer_t *rb);

ring_buffer_t *ring_buffer_create(int buf_size, int push_block, int pull_block)
{
	ring_buffer_impl_t *obj = (ring_buffer_impl_t *) malloc(sizeof(ring_buffer_impl_t));

	if (!obj) {
		return NULL;
	}

	obj->common.push = ring_buffer_push;
	obj->common.pull = ring_buffer_pull;
	obj->common.avail = ring_buffer_avail;
	obj->push_block = push_block;
	obj->pull_block = pull_block;
	//obj->buf_size = buf_size > 0 ? buf_size : QUEUE_BUFFER_SIZE;
	obj->buf_size = QUEUE_BUFFER_SIZE;
	obj->audio_data_queue = (unsigned char *) malloc(obj->buf_size);

	if (!obj->audio_data_queue) {
		free(obj);
		return NULL;
	}

	memset(obj->audio_data_queue, 0, sizeof(obj->buf_size));
	obj->read_idx = 0;
	obj->write_idx = 0;
	obj->delta = 0;
	obj->avail = 1;
	pthread_mutex_init(&obj->mutex, NULL);
	pthread_cond_init(&obj->cond, NULL);
	return (ring_buffer_t *) obj;
}

void ring_buffer_free(ring_buffer_t *obj)
{
	ring_buffer_impl_t *o = (ring_buffer_impl_t *) obj;

	if (o) {
		// FIXME need to singal?
		pthread_mutex_lock(&o->mutex);
		o->avail = 0;
		pthread_cond_signal(&o->cond);
		pthread_mutex_unlock(&o->mutex);
		free(o->audio_data_queue);
		pthread_mutex_destroy(&o->mutex);
		pthread_cond_destroy(&o->cond);
	}

	free(o);
}

static int ring_buffer_push(ring_buffer_t *rbb, unsigned char *buffer, int length)
{
	int  cp_len, avail;
	unsigned char *dest, *src;
	ring_buffer_impl_t *rb = (ring_buffer_impl_t *) rbb;
	pthread_mutex_lock(&rb->mutex);

	// check whether overun
	while (rb->avail && (rb->delta + length > rb->buf_size)) {
		DBG("Overrun! push %d byte, remain %d bytes not be consumed. buffer size:%d.", length, rb->delta, rb->buf_size);

		if (rb->push_block) {
			pthread_cond_wait(&rb->cond, &rb->mutex);
		} else {
			pthread_mutex_unlock(&rb->mutex);
			// FIXME just copy small data?
			return 0;
		}
	}

	if (!rb->avail) {
		pthread_mutex_unlock(&rb->mutex);
		return 0;
	}

	rb->delta += length;

	if (rb->audio_data_queue) {
		dest = rb->audio_data_queue + rb->write_idx;
		src = buffer;

		if (rb->write_idx + length >= rb->buf_size) {
			cp_len = rb->buf_size - rb->write_idx;
			memcpy(dest, src, cp_len);
			dest = rb->audio_data_queue;
			src += cp_len;
			cp_len = length - cp_len;
		} else {
			cp_len = length;
		}

		if (cp_len > 0) {
			memcpy(dest, src, cp_len);
		}

		rb->write_idx += length;
		rb->write_idx %= rb->buf_size;
		pthread_cond_signal(&rb->cond);
	}

	pthread_mutex_unlock(&rb->mutex);
	return length;
}

static int ring_buffer_avail(ring_buffer_t *rbb)
{
	int avail = 0;
	ring_buffer_impl_t *rb = (ring_buffer_impl_t *) rbb;

	pthread_mutex_lock(&rb->mutex);
	if (rb->avail) {
		avail = rb->delta;
	}
	pthread_mutex_unlock(&rb->mutex);

	return avail;
}

static int ring_buffer_pull(ring_buffer_t *rbb, unsigned char *buffer, int length)
{
	int read_len, cp_len, avail, ret_len;
	unsigned char *dest, *src;
	ring_buffer_impl_t *rb = (ring_buffer_impl_t *) rbb;
	pthread_mutex_lock(&rb->mutex);

	// if no data available, block
	while (rb->avail && (rb->delta <= (size_t) 0))
	{
		if (rb->pull_block) {
			pthread_cond_wait(&rb->cond, &rb->mutex);
		} else {
			pthread_mutex_unlock(&rb->mutex);
			return 0;
		}
	}

	if (!rb->avail) {
		pthread_mutex_unlock(&rb->mutex);
		return 0;
	}

	if (length >= (int) rb->delta) {
		read_len = (int) rb->delta;
	} else {
		read_len = length;
	}

	dest = buffer;
	src = rb->audio_data_queue + rb->read_idx;

	if (read_len + rb->read_idx >= rb->buf_size) {
		cp_len = rb->buf_size - rb->read_idx;
		memcpy(dest, src, cp_len);
		dest += cp_len;
		src = rb->audio_data_queue;
		cp_len = read_len - cp_len;
	} else {
		cp_len = read_len;
	}

	if (cp_len > 0) {
		memcpy(dest, src, cp_len);
	}

	rb->delta -= read_len;
	rb->read_idx += read_len;
	rb->read_idx %= rb->buf_size;
	pthread_cond_signal(&rb->cond);
	pthread_mutex_unlock(&rb->mutex);
	return read_len;
}

