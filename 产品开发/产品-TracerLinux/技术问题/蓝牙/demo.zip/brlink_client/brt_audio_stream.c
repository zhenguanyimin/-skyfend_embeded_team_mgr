#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "bluetooth.h"
#include "brt_event_parser.h"
#include "brt_audio_stream.h"
#include "brt_bluetooth_impl.h"
#include "brt_bluetooth_event.h"

typedef enum {
	STATE_STREAM_TYPE = 0,
	STATE_CODEC_TYPE,
	STATE_LEN,
	STATE_DATA,
};

#if 0
struct tag_brt_audio_stream_msg_header {
	uint8_t		stream_type;
	uint8_t		codec_type;
	uint16_t	len;
	uint8_t		data[0];
}  __attribute__((packed)); 
typedef struct tag_brt_audio_stream_msg_header brt_audio_stream_msg_header_t;
#endif
//#define CONFIG_AUDIO_STREAM_DBG
static int s_audio_stream_data_cbk = 0;

typedef struct tag_data_transport {
	volatile int 			alive;
	int 					fd;
	pthread_t 				thread;
	audio_stream_callback_t* cbks;
} brt_audio_stream_data_transport_t;

static brt_audio_stream_data_transport_t s_data_transport;

static void on_data_transport_established(uint8_t id, int fd);
static void close_data_transport();
static int sock_recv_all(int sock_fd, uint8_t *buf, int len);
static int sock_send_all(int sock_fd, const uint8_t *buf, int len);
static void *data_transport_thread_proc(void *arg);

void brt_audio_stream_init(audio_stream_callback_t* cbks)
{
	printf("%s->%d:%s->%s\r\n", __func__, __LINE__, __DATE__, __TIME__);
	memset(&s_data_transport, 0, sizeof(s_data_transport));
	s_data_transport.cbks = cbks;
	s_data_transport.fd = -1;
	s_data_transport.alive = 1;
	brt_bluetooth_register_data_transport_callback(IPC_ID_AUDIO, on_data_transport_established);
}

void brt_audio_stream_done()
{
	close_data_transport();
}

int brt_audio_stream_send(uint8_t stream_type, uint8_t codec_type, uint16_t len, uint8_t *data)
{
	int ret = 0;
	if(s_data_transport.fd <= 0) {
		printf("s_data_transport.fd is error\r\n");
		return -1;
	}
	if(stream_type == AUDIO_STREAM_TYPE_A2DP) {
		//TODO
	} else if (stream_type == AUDIO_STREAM_TYPE_SCO){
		ret = sock_send_all(s_data_transport.fd, data, len);
	}
	return ret;
}

/*static func*/
static void on_data_transport_established(uint8_t id, int fd)
{
	printf("%s(id=%d, fd=%d):%s:%s\n", __func__, id, fd, __DATE__, __TIME__);
	if(id == IPC_ID_AUDIO) {
		s_data_transport.alive = 1;
		s_data_transport.fd = fd;
		pthread_create(&s_data_transport.thread, NULL, data_transport_thread_proc, NULL);
	}
}

static void close_data_transport()
{
	s_data_transport.alive = 0;

	if (s_data_transport.fd > 0) {
		shutdown(s_data_transport.fd, SHUT_RDWR);
		s_data_transport.fd = -1;
	}

	printf("%s fd closed.\n", __func__);
	pthread_join(s_data_transport.thread, NULL);
	printf("%s quit.\n", __func__);
}

static int sock_send_all(int sock_fd, const uint8_t *buf, int len)
{
	int s = len;
	int ret;

	while (s) {
		do {
			ret = send(sock_fd, buf, s, 0);
		} while (ret < 0 && errno == EINTR);

		if (ret <= 0) {
			return -1;
		}

		buf += ret;
		s -= ret;
	}

	return len;
}

static int sock_recv_all(int sock_fd, uint8_t *buf, int len)
{
	int r = len;
	int ret = -1;

	while (r) {
		do {
			ret = recv(sock_fd, buf, r, MSG_WAITALL);
		} while (ret < 0 && errno == EINTR);

		if (ret <= 0) {
			return -1;
		}

		buf += ret;
		r -= ret;
	}

	return len;
}

#ifdef CONFIG_AUDIO_STREAM_DBG

#define FILL_DEBUG_EVENT(dest, src, len) do { \
	dest[0] = 0x04; \
	dest[1] = 0xFF; \
	dest[2] = (len); \
	memcpy(((char *)dest) + 3, (src), (len)); \
} while(0);
extern void brt_debug_capture(unsigned char *p_buf, uint32_t len, uint8_t is_rcvd);

#endif
static void *data_transport_thread_proc(void *arg)
{
	int ret;
	int state = STATE_STREAM_TYPE;
	uint8_t stream_type;
	uint8_t codec_type;
	uint16_t len;
	uint8_t* data = NULL;
	uint16_t offset;
#ifdef CONFIG_AUDIO_STREAM_DBG
	char debug_buf[260] = {0};
	char dbg_data[260] = {0};
#endif

	printf("%s->%d, s_data_transport.alive:%d, s_data_transport.fd:%d\r\n", __func__, __LINE__, s_data_transport.alive, s_data_transport.fd);
#ifdef CONFIG_AUDIO_STREAM_DBG	
	sprintf(dbg_data, "ZA01%02X%d\r\n", s_data_transport.alive, s_data_transport.fd);
	FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
	brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
#endif

	while (s_data_transport.alive && s_data_transport.fd > 0) {
		switch (state) {
			case STATE_STREAM_TYPE:
				len = offset = 0;
				ret = sock_recv_all(s_data_transport.fd, &stream_type, sizeof(stream_type));

				if (ret != sizeof(codec_type)) {
					ret = -1;
					goto error;
				}
				state = STATE_CODEC_TYPE;
				break;
			case STATE_CODEC_TYPE:
				
				ret = sock_recv_all(s_data_transport.fd, &codec_type, sizeof(codec_type));

				if (ret != sizeof(codec_type)) {
					ret = -1;
					goto error;
				}
				state = STATE_LEN;
				break;
			case STATE_LEN:
				ret = sock_recv_all(s_data_transport.fd, (uint8_t *) &len, sizeof(len));
				if (ret != sizeof(len)) {
					goto error;
				}

				data = malloc(len);

				if (data != NULL) {
					if (len > 0) {
						state = STATE_DATA;
					} else {
						state = STATE_STREAM_TYPE;
						if (s_data_transport.cbks->brt_audio_stream_cb) {
#ifdef CONFIG_AUDIO_STREAM_DBG
							if ((s_audio_stream_data_cbk % 100) == 0) {
								s_audio_stream_data_cbk = 0;
								printf("[%s] %s->%d packet\r\n", get_current_time_string(), __FUNCTION__, __LINE__);
								memset(debug_buf, 0, 260);
								memset(dbg_data, 0, 260);
								sprintf(dbg_data, "ZC01%02X%02X%d\r\n", stream_type, codec_type, len);
								FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
								brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
							}    
							s_audio_stream_data_cbk++;
#endif
							s_data_transport.cbks->brt_audio_stream_cb(stream_type, codec_type, len, data);
							free(data);
							data = NULL;
						} else {
#ifdef CONFIG_AUDIO_STREAM_DBG
							memset(debug_buf, 0, 260);
							memset(dbg_data, 0, 260);
							strcpy(dbg_data, "ZB01\r\n");
							FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
							brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
#endif
						}
					}	
				} else {
					goto error;
				}

				break;
			case STATE_DATA:
				ret = sock_recv_all(s_data_transport.fd, data + offset, len - offset);
				if (ret > 0) {
					offset += ret;
					if (offset >= len) {
						state = STATE_STREAM_TYPE;
						if (s_data_transport.cbks->brt_audio_stream_cb && data) {
#ifdef CONFIG_AUDIO_STREAM_DBG
							if ((s_audio_stream_data_cbk % 100) == 0) {
								s_audio_stream_data_cbk = 0;
								printf("[%s] %s->%d packet\r\n", get_current_time_string(), __FUNCTION__, __LINE__);
								memset(debug_buf, 0, 260);
								memset(dbg_data, 0, 260);
								sprintf(dbg_data, "ZC02%02X%02X%d\r\n", stream_type, codec_type, len);
								printf("%s", debug_buf);
								FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
								brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
							}    
							s_audio_stream_data_cbk++;
#endif
							s_data_transport.cbks->brt_audio_stream_cb(stream_type, codec_type, len, data);
							free(data);
							data = NULL;
						} else {
#ifdef CONFIG_AUDIO_STREAM_DBG
							memset(debug_buf, 0, 260);
							memset(dbg_data, 0, 260);
							strcpy(dbg_data, "ZB02\r\n");
							FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
							brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
#endif
						}						
					}
				} else {
					goto error;
				}
				break;
		}
	}

	if (data) {
		free(data);
		data = NULL;
	}
	
#ifdef CONFIG_AUDIO_STREAM_DBG
	memset(debug_buf, 0, 260);
	memset(dbg_data, 0, 260);
	sprintf(dbg_data, "ZA02\r\n");
	FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
	brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
#endif

error:
	printf("Data transport is broken!!! Type:Audio\n");
	
#ifdef CONFIG_AUDIO_STREAM_DBG
	memset(debug_buf, 0, 260);
	memset(dbg_data, 0, 260);
	sprintf(dbg_data, "ZA03\r\n");
	FILL_DEBUG_EVENT(debug_buf, dbg_data, strlen(dbg_data));
	brt_debug_capture(debug_buf, 3 + strlen(dbg_data), 1);
#endif
	return NULL;
}
