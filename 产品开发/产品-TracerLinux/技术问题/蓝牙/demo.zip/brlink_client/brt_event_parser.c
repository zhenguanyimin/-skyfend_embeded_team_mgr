#include "bluetooth.h"
#include "brt_event_parser.h"
#include <string.h>
#include <stdlib.h>

#define EVENT_LENGTH_OK 			0x00
#define EVENT_LENGTH_INVALID		0x01
#define EVENT_LENGTH_NOT_ENOUGH		0x02

static int process(event_parser_t *evt_parser, uint8_t * buffer, int offset, int length, parser_t *parser);
static int check_tag(const char * tag, uint8_t * buffer, int offset, int length);
static int check_event_end_pos(uint8_t * buffer, int offset, int length);
static int check_event_length(event_parser_t *evt_parser, int offset, int length, int pos, int expectedMinLen);
static int is_terminator_char(char b);
static void evt_log(const char *format, ...);

static int process_event_impl(event_parser_t *evt_parser, uint8_t *buffer, int offset, int length);

event_parser_t *create_event_parser()
{
	event_parser_t *parser = (event_parser_t *) malloc(sizeof(event_parser_t));

	if (parser) {
		memset(parser, 0, sizeof(event_parser_t));
		parser->process_event = process_event_impl;
	}

	return parser;
}

void destroy_event_parser(event_parser_t *parser)
{
	/* Nothing ? */
}

static int process_event_impl(event_parser_t *evt_parser, uint8_t *buffer, int offset, int length)
{
	int i, pos;

	if (evt_parser == NULL || evt_parser->parser_list == NULL) {
		return -1;
	}

	// TODO move this function outside.
	evt_parser->event_end_pos = check_event_end_pos(buffer, offset, length);

	for (i=0; i< evt_parser->num_of_parsers; i++) {
		if (evt_parser->parser_list != NULL) {
			pos = process(evt_parser, buffer, offset, length, evt_parser->parser_list + i);
			if (pos > 0) {
				return pos;
			}
		}
	}

	return -1;
}

static int process(event_parser_t *evt_parser, uint8_t * buffer, int offset, int length, parser_t *parser)
{
	int pos;
	int processedPos;

	// 1st step: check the keyword.
	if ((pos = check_tag(parser->get_keyword(), buffer, offset, length)) < 0) {
		return pos;
	}

	// 2rd step: check the length whether is enough.
	int valid = check_event_length(evt_parser, offset, length, pos, parser->get_min_expected_length());

	if (valid != EVENT_LENGTH_OK) {
		if (valid == EVENT_LENGTH_INVALID) {
			evt_log("%s: Invalid parameters!\n", parser->get_tag());
		} else {
			evt_log("%s: Not enough information!\n", parser->get_tag());
		}
		return evt_parser->event_end_pos;
	}

	// 3rd step: do the actual parsing.
	if ((processedPos = parser->parse(buffer, pos)) < 0) {
		return evt_parser->event_end_pos;
	}

	// 4th step: check whether there is some bytes not processed.
	if (evt_parser->event_end_pos > 0 && evt_parser->event_end_pos != processedPos) {
		evt_log("%s: Still %d characters not processed!!", parser->get_tag(), (evt_parser->event_end_pos - processedPos));
		processedPos = evt_parser->event_end_pos;
	}

	// 5th step: return the processed position(next byte).
	return processedPos;
}

static int check_tag(const char *tag, uint8_t *buffer, int offset, int length)
{
	int pos;
	int tl = strlen(tag);

	if (tl > length) {
		return -1;
	}

	for (pos = offset; pos < offset + tl; pos++) {
		if (buffer[pos] != (uint8_t) tag[pos - offset]) {
			return -1;
		}
	}
	return pos;
}

static int check_event_end_pos(uint8_t * buffer, int offset, int length)
{
	int i;
	for (i = offset; i < length + offset; i++) {
		if (buffer[i] == '\0') {
			return i;
		}
	}

	return -1;
}

static int check_event_length(event_parser_t *evt_parser, int offset, int length, int pos, int expectedMinLen)
{
	int result = EVENT_LENGTH_OK;

	if (evt_parser->event_end_pos > 0) {
		if (evt_parser->event_end_pos < pos + expectedMinLen) {
			result = EVENT_LENGTH_INVALID;
		}
	} else {
		// There is not terminated character '\0'
		if (offset + length < pos + expectedMinLen) {
			result = EVENT_LENGTH_NOT_ENOUGH;
		}
	}
	return result;
}

static int is_terminator_char(char b)
{
	if (b == '\0' || b == '\r' || b == '\n') {
		return 1;
	}
	return 0;
}

static void evt_log(const char *format, ...)
{
}


