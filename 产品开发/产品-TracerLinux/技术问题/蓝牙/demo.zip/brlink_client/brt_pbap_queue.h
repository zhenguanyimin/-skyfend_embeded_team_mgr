
typedef struct bse_pbap_queue {
	uint8_t parse_index;
	void* param;
	void * next;
}bse_pbap_queue_t;

void start_pbap_queue();
void stop_pbap_queue();
void writeto_pbap_queue(bse_pbap_queue_t *pbap_queue);
bse_pbap_queue_t* readfrom_pbap_queue();
void pbap_thread_wait();
void pbap_thread_post();
