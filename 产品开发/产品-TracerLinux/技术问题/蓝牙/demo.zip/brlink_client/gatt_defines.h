enum {
    /**Service Type.*/
    SERVICE_TYPE_PRIMARY = 0,
    /**Service Type*/
    SERVICE_TYPE_SECONDARY = 1,
};

enum {
    /** A GATT operation completed successfully */
    GATT_SUCCESS = 0x0,

    /** GATT read operation is not permitted */
    GATT_READ_NOT_PERMITTED = 0x2,

    /** GATT write operation is not permitted */
    GATT_WRITE_NOT_PERMITTED = 0x3,

    /** Insufficient authentication for a given operation */
    GATT_INSUFFICIENT_AUTHENTICATION = 0x5,

    /** The given request is not supported */
    GATT_REQUEST_NOT_SUPPORTED = 0x6,

    /** Insufficient encryption for a given operation */
    GATT_INSUFFICIENT_ENCRYPTION = 0xf,

    /** A read or write operation was requested with an invalid offset */
    GATT_INVALID_OFFSET = 0x7,

    /** A write operation exceeds the maximum length of the attribute */
    GATT_INVALID_ATTRIBUTE_LENGTH = 0xd,

    /** A remote device connection is congested. */
    GATT_CONNECTION_CONGESTED = 0x8f,

    /** A GATT operation failed, errors other than the above */
    GATT_FAILURE = 0x101,
};

enum {
    /**
    * No preferrence of physical transport for GATT connections to remote dual-mode devices
    */
    TRANSPORT_AUTO = 0,

    /**
    * Prefer BR/EDR transport for GATT connections to remote dual-mode devices
    */
    TRANSPORT_BREDR = 1,

    /**
    * Prefer LE transport for GATT connections to remote dual-mode devices
    */
    TRANSPORT_LE = 2,
};

enum {
    /**
     * Write characteristic, requesting acknoledgement by the remote device
     */
    WRITE_TYPE_DEFAULT = 0x02,

    /**
     * Wrtite characteristic without requiring a response by the remote device
     */
    WRITE_TYPE_NO_RESPONSE = 0x01,

    /**
     * Write characteristic including authentication signature
     */
    WRITE_TYPE_SIGNED = 0x04,
};

enum {
    /**
    * permission: read permission
    */
    PERMISSION_READ = 0x01,
    /**
    * permission: Allow encrypted read operations
    */
    PERMISSION_READ_ENCRYPTED = 0x02,
    /**
    * permission: Allow reading with man-in-the-middle protection
    */
    PERMISSION_READ_ENCRYPTED_MITM = 0x04,
    /**
    * permission: write permission
    */
    PERMISSION_WRITE = 0x10,
    /**
    * permission: Allow encrypted writes
    */
    PERMISSION_WRITE_ENCRYPTED = 0x20,
    /**
    * permission: Allow encrypted writes with man-in-the-middle protection
    */
    PERMISSION_WRITE_ENCRYPTED_MITM = 0x40,
    /**
    * permission: Allow signed write operations
    */
    PERMISSION_WRITE_SIGNED = 0x80,
    /**
    * permission: Allow signed write operations with man-in-the-middle protection
    */
    PERMISSION_WRITE_SIGNED_MITM = 0x100,
};

enum {
    /**
    * Characteristic proprty: Characteristic is broadcastable.
    */
    PROPERTY_BROADCAST = 0x01,
    /**
    * Characteristic property: Characteristic is readable.
    */
    PROPERTY_READ = 0x02,
    /**
    * Characteristic property: Characteristic can be written without response.
    */
    PROPERTY_WRITE_NO_RESPONSE = 0x04,
    /**
    * Characteristic property: Characteristic can be written.
    */
    PROPERTY_WRITE = 0x08,
    /**
    * Characteristic property: Characteristic supports notification
    */
    PROPERTY_NOTIFY = 0x10,
    /**
    * Characteristic property: Characteristic supports indication
    */
    PROPERTY_INDICATE = 0x20,
    /**
    * Characteristic property: Characteristic supports write with signature
    */
    PROPERTY_SIGNED_WRITE = 0x40,
    /**
    * Characteristic property: Characteristic has extended properties
    */
    PROPERTY_EXTENDED_PROPS = 0x80,
};
