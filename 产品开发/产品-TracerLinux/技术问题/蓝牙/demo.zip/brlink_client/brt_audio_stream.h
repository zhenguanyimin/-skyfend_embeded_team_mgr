 #include <stdint.h>

/*Stream Type*/
enum {
    AUDIO_STREAM_TYPE_SCO,
    AUDIO_STREAM_TYPE_A2DP,
};

/* Codec Type */
#define A2DP_CODEC_SBC              0x00/* If it's SBC's codec, the data has been decoded, so it's PCM data */
#define A2DP_CODEC_MPEG12           0x01
#define A2DP_CODEC_AAC              0x02
#define A2DP_CODEC_ATRAC            0x04
#define A2DP_CODEC_NONA2DP          0xFF


typedef void (*brt_audio_stream_cbk)(uint8_t stream_type, uint8_t codec_type, uint16_t len, uint8_t *data);

typedef struct tag_audio_stream_callback {
	brt_audio_stream_cbk brt_audio_stream_cb;
}audio_stream_callback_t;

void brt_audio_stream_init(audio_stream_callback_t* cbk);
void brt_audio_stream_done();
int brt_audio_stream_send(uint8_t stream_type, uint8_t codec_type, uint16_t len, uint8_t *data);
