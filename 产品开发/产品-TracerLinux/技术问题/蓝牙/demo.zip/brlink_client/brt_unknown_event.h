#ifndef  _BRT_UNKNOWN_EVENT_H__
#define _BRT_UNKNOWN_EVENT_H__

event_parser_t *create_unknown_event_parser();
void destroy_unknown_event_parser(event_parser_t * parser);

#endif /* _BRT_UNKNOWN_EVENT_H__BRT_UNKNOWN_EVENT_H___ */
