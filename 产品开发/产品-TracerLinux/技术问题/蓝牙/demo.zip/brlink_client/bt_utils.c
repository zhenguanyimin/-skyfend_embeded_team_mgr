#include "bt_utils.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include "brt_pbap.h"

unsigned char parse_byte(char *p)
{
	char buf[3] = {0};
	memcpy(buf, p, 2);
	return strtol(buf, NULL, 16) ;
}

unsigned char parse_byte_with_base(char *p, int base)
{
	char buf[3] = {0};
	memcpy(buf, p, 2);
	return strtol(buf, NULL, base) ;
}

unsigned char parse_char_with_base(char *p, int base)
{
	char buf[2] = {0};
	memcpy(buf, p, 1);
	return strtol(buf, NULL, base);
}

unsigned short parse_uuid16(char *p)
{
	char buf[5] = {0};
	memcpy(buf, p, 4);
	return strtol(buf, NULL, 16) ;
}

unsigned short parse_short(char *p)
{
	char buf[5] = {0};
	memcpy(buf, p, 4);
	return strtol(buf, NULL, 16) ;
}

unsigned int parse_int(char *p)
{
	char buf[9] = {0};
	memcpy(buf, p, 8);
	return strtol(buf, NULL, 16) ;
}

unsigned int parse_int_dec(char *p)
{
	char buf[9] = {0};
	memcpy(buf, p, 8);
	return strtol(buf, NULL, 10) ;
}


long parse_long(char *p)
{
	char buf[17] = {0};
	memcpy(buf, p, 17);
	return strtol(buf, NULL, 16) ;
}

static bt_bdaddr_t s_addr;

bt_bdaddr_t parse_address(char *p)
{
	int i = 0;
	char str[13];

	memset(str, 0, 13);
	memcpy(str, p, 12);
	char* end = &(str[12]);
	for(i = 0; i < 6; i++) {
		s_addr.address[5-i] = strtol(end - (i + 1) * 2 , NULL, 16) ;
		*(end - (i + 1) * 2) = 0;
	}



	return s_addr;
}

#define MAX_AT_CMD_PARAM_RAW_DATA_LEN 256
static unsigned char bytes[MAX_AT_CMD_PARAM_RAW_DATA_LEN];

unsigned char *parse_bytes(char *p, int *len)
{
	unsigned short result_len = 0;

	if (*len > MAX_AT_CMD_PARAM_RAW_DATA_LEN) {
		*len = 0;
		return 0;
	}

	str_bytes_to_raw_bytes(p, (unsigned short) *len, bytes, &result_len);
	*len = (int) (result_len & 0xFFFF);

	return bytes;
}

void parse_uuid128(char *p, bt_uuid_t *uuid_128)
{
	int i  = 0;
	char buf[3] = {0};
	for(i = 0; i < 16; i++) {
		memcpy(buf, p, 2);
		uuid_128->uu[i] = (unsigned char)strtol(buf, NULL, 16) ;
		p += 2;
	}
}

#define TERMINAL_CHAR1 '\0'
#define TERMINAL_CHAR2 '\r'
#define TERMINAL_CHAR3 '\n'
#define SBUSTITUE_BYTE  220 //0xDC
#define SBUSTITUE_BYTE1 221 //0xDD
#define SBUSTITUE_BYTE2 222 //0xDE
#define SBUSTITUE_BYTE3 223 //0xDF

unsigned char * raw_bytes_to_str_bytes(const unsigned char *raw_bytes, unsigned short raw_len,
                                       unsigned char *result_bytes, unsigned short *result_len)
{
	int terminal_bytes = 0;
	int i;
	int j = 0;

	if (raw_bytes == NULL) {
		if (result_len != NULL) {
			*result_len = 0;
		}
		return NULL;
	}

	for (i=0; i<raw_len; i++) {
		if ((raw_bytes[i] == TERMINAL_CHAR1) ||
		    (raw_bytes[i] == TERMINAL_CHAR2) ||
		    (raw_bytes[i] == TERMINAL_CHAR3)) {
			terminal_bytes++;
		}
		if (raw_bytes[i] == SBUSTITUE_BYTE) {
			terminal_bytes++;
		}
	}

	if (result_len != NULL) {
		*result_len = raw_len + terminal_bytes;
	}

	if (result_bytes != NULL) {
		for (i=0; i<raw_len; i++, j++) {
			if (raw_bytes[i] == TERMINAL_CHAR1) {
				result_bytes[j] = SBUSTITUE_BYTE;
				j++;
				result_bytes[j] = SBUSTITUE_BYTE1;
			} else if (raw_bytes[i] == TERMINAL_CHAR2) {
				result_bytes[j] = SBUSTITUE_BYTE;
				j++;
				result_bytes[j] = SBUSTITUE_BYTE2;
			} else if (raw_bytes[i] == TERMINAL_CHAR3) {
				result_bytes[j] = SBUSTITUE_BYTE;
				j++;
				result_bytes[j] = SBUSTITUE_BYTE3;
			} else if (raw_bytes[i] == SBUSTITUE_BYTE) {
				result_bytes[j] = SBUSTITUE_BYTE;
				j++;
				result_bytes[j] = SBUSTITUE_BYTE;
			} else {
				result_bytes[j] = raw_bytes[i];
			}
		}
	}

	return result_bytes;
}

void hex_to_str_ex(char *ptr,unsigned char *buf,int len)
{
	for(int i = 0; i < len; i++)
	{
		sprintf(ptr, "%02x",buf[i]);
		ptr += 2;
	}
}

int str_to_hex_ex(char *string, unsigned char *cbuf, int len)
{
	char high, low;
	int idx, ii=0;
	for (idx=0; idx<len; idx+=2)
	{
		high = string[idx];
		low = string[idx+1];

		if(high>='0' && high<='9')
			high = high-'0';
		else if(high>='A' && high<='F')
			high = high - 'A' + 10;
		else if(high>='a' && high<='f')
			high = high - 'a' + 10;
		else
			return -1;

		if(low>='0' && low<='9')
			low = low-'0';
		else if(low>='A' && low<='F')
			low = low - 'A' + 10;
		else if(low>='a' && low<='f')
			low = low - 'a' + 10;
		else
			return -1;

		cbuf[ii++] = high<<4 | low;
	}
	return 0;
}



//参数1为原始数据，参数2为数组长度，参数三为转出来的字符串
void hex_to_asciistring(uint8_t* str,uint32_t size,uint8_t* str1)
{
	uint8_t deposit [2];
	int i=0;
	uint8_t j = 0;

	for(i=0;i<size;i++)
	{

		deposit[1] = str[i] & 0x0F;
		deposit[0] = (str[i] &0xF0) >> 4;
		for(j = 0; j < 2; j++)
		{
		switch(deposit[j])
		{
			case 0x00:
			  str1[i*2+j]='0';
				break;
			case 0x01:
			  str1[i*2+j]='1';
				break;
			case 0x02:
			  str1[i*2+j]='2';
				break;
			case 0x03:
			  str1[i*2+j]='3';
				break;
			case 0x04:
			 str1[i*2+j]='4';
				break;
			case 0x05:
			  str1[i*2+j]='5';
				break;
			case 0x06:
			  str1[i*2+j]='6';
				break;
			case 0x07:
			  str1[i*2+j]='7';
				break;
			case 0x08:
			  str1[i*2+j]='8';
				break;
			case 0x09:
			  str1[i*2+j]='9';
				break;
			case 0x0A:
			  str1[i*2+j]='A';
				break;
			case 0x0B:
			  str1[i*2+j]='B';
				break;
			case 0x0C:
			  str1[i*2+j]='C';
				break;
			case 0x0D:
			  str1[i*2+j]='D';
				break;
			case 0x0E:
			  str1[i*2+j]='E';
				break;
			case 0x0F:
			  str1[i*2+j]='F';
				break;
			default:
				return ;
		}

	}

	}
   return ;
}

unsigned char * str_bytes_to_raw_bytes(const unsigned char *raw_bytes, unsigned short raw_len,
                                       unsigned char *result_bytes, unsigned short *result_len)
{
	int terminal_bytes = 0;
	int i, j = 0;

	if (raw_bytes == NULL) {
		if (result_len != NULL) {
			*result_len = 0;
		}
		return NULL;
	}


	for (i = 0; i < raw_len; i++) {
		if (raw_bytes[i] == SBUSTITUE_BYTE) {
			terminal_bytes++;
			i++;
		}
	}

	if (terminal_bytes >= raw_len) {
		if (result_len != NULL) {
			*result_len = 0;
		}
		return NULL;
	}

	if (result_len != NULL) {
		*result_len = raw_len - terminal_bytes;
	}

	for (i = 0; i < raw_len; i++, j++) {
		if (raw_bytes[i] == SBUSTITUE_BYTE && i < raw_len - 1) {
			if (raw_bytes[i+1] == SBUSTITUE_BYTE) {
				result_bytes[j] = SBUSTITUE_BYTE;
			} else if (raw_bytes[i+1] == SBUSTITUE_BYTE1) {
				result_bytes[j] = TERMINAL_CHAR1;
			} else if (raw_bytes[i+1] == SBUSTITUE_BYTE2) {
				result_bytes[j] = TERMINAL_CHAR2;
			} else if (raw_bytes[i+1] == SBUSTITUE_BYTE3) {
				result_bytes[j] = TERMINAL_CHAR3;
			} else {
				// invalid byte
			}
			i++;
		} else {
			result_bytes[j] = raw_bytes[i];
		}
	}
	return result_bytes;
}

static int reliable_memcpy(unsigned char * des, int des_remain_len, unsigned char * src, int src_len)
{
	if (des_remain_len <= 0) {
		return 0;
	}

	if (src_len > des_remain_len) {
		memcpy(des, src, des_remain_len);
		return 0;
	} else {
		memcpy(des, src, src_len);
		return 1;
	}
}

#ifdef SPLIT_NAME
void split_name(phone_book_t *phone_book, unsigned char *raw_name, int raw_name_len)
{
	if (raw_name_len == 0 || !phone_book) {
		return ;
	}

	unsigned char tmp_buf[MAX_NAME_LEN];
	unsigned char * last = tmp_buf;
	unsigned char * first = NULL;
	unsigned char * middle = NULL;
	
	int last_len = 0;
	int first_len = 0;
	int middle_len = 0;
	
	int i = 0, j = 0;
	int split_flag = 0;
	int backslash_flag = 0;
	unsigned char * p = raw_name;
	memset(tmp_buf, 0, MAX_NAME_LEN);
	for (i; i < raw_name_len; i++) {

		if (*(p + i) == ';') {
			if(backslash_flag == 1) {
				backslash_flag = 0;
				tmp_buf[j++] = *(p+i);
				continue;
			}
			if (split_flag == 0) {
				last_len = j;
				if(last_len > 0) {
					reliable_memcpy(phone_book->lastName, MAX_NAME_LEN - 1, last, last_len);
				}
				first =  tmp_buf + j;
			}
			if (split_flag == 1) {
				first_len = j - last_len;
				if(first_len > 0) {
					reliable_memcpy(phone_book->firstName, MAX_NAME_LEN - 1, first, first_len);
				}
				middle = tmp_buf + j;
			}
			if (split_flag == 2) {
				middle_len = j - last_len - first_len;
				if(middle_len > 0) {
					reliable_memcpy(phone_book->middleName, MAX_NAME_LEN - 1, middle, middle_len);
				}
			}

			if ((++split_flag) == 3) {
				break;
			}
		} else {
			if (backslash_flag == 0 && *(p + i) == '\\') {
				backslash_flag = 1;
				continue;
			} 
			if (backslash_flag == 1) {
				backslash_flag = 0;
			}
			tmp_buf[j++] = *(p+i);
		
		}
	}
}
#endif
void combine_name(unsigned char * des_name, int des_name_len, unsigned char *raw_name, int raw_name_len)
{
	if (raw_name_len == 0) {
		return ;
	}

	unsigned char * last = raw_name;
	unsigned char * first = NULL;
	unsigned char * middle = NULL;

	int last_len = 0;
	int first_len = 0;
	int middle_len = 0;

	int i = 0;
	int split_flag = 0;
	unsigned char * p = raw_name;
	int hit = 0;// 1 means is not chinese name
	for (i; i < raw_name_len; i++) {
		if (*(p + i) == ';') {
			if (split_flag == 0) {
				last_len = i;
				first = p + i + 1;
			}
			if (split_flag == 1) {
				first_len = i - last_len - 1;
				middle = p + i + 1;
			}
			if (split_flag == 2) {
				middle_len = i - last_len - first_len - 2;
			}

			if ((++split_flag) == 3) {
				break;
			}
		}

		if (hit != 1 && (isalpha(*(p + i)) || isblank(*(p + i)))) {
			hit = 1;
		}
	}

	if (last_len + first_len + middle_len >= des_name_len) {
		printf("Name Len Error. MAX_NAME_LEN = %d, real_len = %d", des_name_len, last_len + first_len + middle_len);
	}
	
	if (hit) {//not chinese name
		if (reliable_memcpy(des_name, des_name_len, first, first_len)) {
			if (reliable_memcpy(des_name + first_len, des_name_len - first_len, middle, middle_len)) {
				reliable_memcpy(des_name + first_len + middle_len, des_name_len - first_len - middle_len, last, last_len);
			}
		}
	} else {//chinese name
		if (reliable_memcpy(des_name, des_name_len, last, last_len)) {
			if (reliable_memcpy(des_name + last_len, des_name_len - last_len, middle, middle_len)) {
				reliable_memcpy(des_name + last_len + middle_len, des_name_len - last_len - middle_len, first, first_len);
			}
		}
	}

}

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

#ifdef SCM_RIGHTS

/* It seems various versions of glibc headers (i.e.
 *  * /usr/include/socketbits.h) miss one or more of these */

#ifndef CMSG_DATA
# define CMSG_DATA(cmsg) ((cmsg)->cmsg_data)
#endif

#ifndef CMSG_NXTHDR
# define CMSG_NXTHDR(mhdr, cmsg) __cmsg_nxthdr (mhdr, cmsg)
#endif

#ifndef CMSG_FIRSTHDR
# define CMSG_FIRSTHDR(mhdr) \
	((size_t) (mhdr)->msg_controllen >= sizeof (struct cmsghdr)	       \
	 ? (struct cmsghdr *) (mhdr)->msg_control : (struct cmsghdr *) NULL)
#endif

#ifndef CMSG_ALIGN
# define CMSG_ALIGN(len) (((len) + sizeof (size_t) - 1) \
		& ~(sizeof (size_t) - 1))
#endif

#ifndef CMSG_SPACE
# define CMSG_SPACE(len) (CMSG_ALIGN (len) \
		+ CMSG_ALIGN (sizeof (struct cmsghdr)))
#endif

#ifndef CMSG_LEN
# define CMSG_LEN(len)   (CMSG_ALIGN (sizeof (struct cmsghdr)) + (len))
#endif

union fdmsg {
	struct cmsghdr h;
	char buf[CMSG_SPACE(sizeof(int))];
};
#endif

int sendfd_client(int sock_fd, int send_me_fd)
{
	int ret = 0;
	struct iovec  iov[1];
	struct msghdr msg;

	iov[0].iov_base = &ret;  /* Don't send any data. Note: der Mouse
							  * <mouse@Rodents.Montreal.QC.CA> says
							  * that might work better if at least one
							  * byte is sent. */
	iov[0].iov_len  = 1;

	msg.msg_iov     = iov;
	msg.msg_iovlen  = 1;
	msg.msg_name    = 0;
	msg.msg_namelen = 0;

	{
#ifdef SCM_RIGHTS
		/* New BSD 4.4 way (ouch, why does this have to be
		 * so convoluted). */

		union  fdmsg  cmsg;
		struct cmsghdr* h;

		msg.msg_control = cmsg.buf;
		msg.msg_controllen = sizeof(union fdmsg);
		msg.msg_flags = 0;

		h = CMSG_FIRSTHDR(&msg);
		h->cmsg_len   = CMSG_LEN(sizeof(int));
		h->cmsg_level = SOL_SOCKET;
		h->cmsg_type  = SCM_RIGHTS;
		*((int*)CMSG_DATA(h)) = send_me_fd;
#else
		/* Old BSD 4.3 way. Not tested. */
		msg.msg_accrights = &send_me_fd;
		msg.msg_accrightslen = sizeof(send_me_fd);
#endif	

		if (sendmsg(sock_fd, &msg, 0) < 0) {
			ret = 0;
		} else {
			ret = 1;
		}
	}
	/*fprintf(stderr,"send %d %d %d %d\n",sock_fd, send_me_fd, ret, errno);*/
	return ret;
}

int recvfd_client(int sock_fd)
{
	int count;
	int ret = 0;
	struct iovec  iov[1];
	struct msghdr msg;

	iov[0].iov_base = &ret;  /* don't receive any data */
	iov[0].iov_len  = 1;

	msg.msg_iov = iov;
	msg.msg_iovlen = 1;
	msg.msg_name = NULL;
	msg.msg_namelen = 0;

	{
#ifdef SCM_RIGHTS
		union fdmsg  cmsg;
		struct cmsghdr* h;

		msg.msg_control = cmsg.buf;
		msg.msg_controllen = sizeof(union fdmsg);
		msg.msg_flags = 0;

		h = CMSG_FIRSTHDR(&msg);
		h->cmsg_len   = CMSG_LEN(sizeof(int));
		h->cmsg_level = SOL_SOCKET;  /* Linux does not set these */
		h->cmsg_type  = SCM_RIGHTS;  /* upon return */
		*((int*)CMSG_DATA(h)) = -1;

		if ((count = recvmsg(sock_fd, &msg, 0)) < 0) {
			ret = 0;
		} else {
			printf("%s ret %d.\n", __func__, count);
			h = CMSG_FIRSTHDR(&msg);   /* can realloc? */
			if (   h == NULL
					|| h->cmsg_len    != CMSG_LEN(sizeof(int))
					|| h->cmsg_level  != SOL_SOCKET
					|| h->cmsg_type   != SCM_RIGHTS ) {
				/* This should really never happen */
				if (h)
					fprintf(stderr,
							"%s:%d: protocol failure: %d %d %d\n",
							__FILE__, __LINE__,
							h->cmsg_len,
							h->cmsg_level, h->cmsg_type);
				else
					fprintf(stderr,
							"%s:%d: protocol failure: NULL cmsghdr*\n",
							__FILE__, __LINE__);
				ret = 0;
			} else {
				ret = *((int*)CMSG_DATA(h));
				/*fprintf(stderr, "recv ok %d\n", ret);*/
			}
		}
#else
		int receive_fd;
		msg.msg_accrights = &receive_fd;
		msg.msg_accrightslen = sizeof(receive_fd);

		if (recvmsg(sock_fd, &msg, 0) < 0) {
			ret = 0;
		} else {
			ret = receive_fd;
		}
#endif
	}

	return ret;
}

//static char time_string[64];

char *get_current_time_string()
{
	struct tm *time_info;
	struct timeval tv; 
	char time_string[64]; //null
	memset(&tv, 0, sizeof(struct timeval));
	memset(time_string, 0, 64);

	if (gettimeofday(&tv, NULL) < 0) {
	}   

	time_info = localtime(& (tv.tv_sec));
	sprintf(time_string, "[%02d:%02d:%02d:%u]", time_info->tm_hour, time_info->tm_min, time_info->tm_sec, (unsigned int) tv.tv_usec);
	return time_string;
}


