#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <signal.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

/* for gettimeofday */
#include <sys/time.h>
/* for the S_* open parameters */
#include <sys/stat.h>
/* for write */
#include <unistd.h>
/* for O_* open parameters */
#include <fcntl.h>
/* defines the O_* open parameters */
#include <fcntl.h>
#include <strings.h>

#ifndef MODULE_TAG
#define MODULE_TAG "btsnoop"
#endif

//#define BRT_DEBUG_DBG
#ifdef BRT_DEBUG_DBG
#define SNOOPDBG(fmt, arg...)  bse_print_va("btsnoop", " %s[%s]: " fmt, __FUNCTION__ , get_current_time_string(), ## arg)
#else
#define SNOOPDBG(param, arg...) {}
#endif

//#define BRT_DEBUG_EXT_PARSER_INCLUDED TRUE
#define BRT_DEBUGDISP_INCLUDED TRUE
static pthread_mutex_t utils_mutex;
static unsigned char s_buffer[1024];

enum {
    BRT_DEBUG_UNINIT,
    BRT_DEBUG_INIT,
};
static s_brt_debug_status = BRT_DEBUG_UNINIT;
static void set_brt_debug_status(int status)
{
	s_brt_debug_status = status;
}

static int get_brt_debug_status()
{
	return s_brt_debug_status;
}

static void utils_init(void)
{
	pthread_mutex_init(&utils_mutex, NULL);
	signal(SIGPIPE, SIG_IGN);
}

static void utils_lock(void)
{
	pthread_mutex_lock(&utils_mutex);
}

static void utils_unlock(void)
{
	pthread_mutex_unlock(&utils_mutex);
}

void hex_dump(unsigned char *data, size_t len)
{
	unsigned long i, j, l;
	unsigned char tmp_str[140];
	unsigned char tmp_str1[10];

	for (i = 0; i < len; i += 16) {
		int n ;

		tmp_str[0] = '\0';
		n = i ;

		for (j = 0; j < 4; j++) {
			l = n % 16;

			if (l >= 10)
				tmp_str[3 - j] = (unsigned char)('A' + l - 10);
			else
				tmp_str[3 - j] = (unsigned char)(l + '0');

			n >>= 4 ;
		}

		tmp_str[4] = '\0';
		strcat((char *) tmp_str, ": ");

		/*
		   Output the hex bytes
		 */
		for (j = i; j < (i + 16); j ++) {
			int m ;

			if (j < len) {
				m = ((unsigned int)((unsigned char) * (data + j))) / 16 ;

				if (m >= 10)
					tmp_str1[0] = 'A' + (unsigned char) m - 10;
				else
					tmp_str1[0] = (unsigned char) m + '0';

				m = ((unsigned int)((unsigned char) * (data + j))) % 16 ;

				if (m >= 10)
					tmp_str1[1] = 'A' + (unsigned char) m - 10;
				else
					tmp_str1[1] = (unsigned char) m + '0';

				tmp_str1[2] = '\0';
				strcat((char *) tmp_str, (char *) tmp_str1);
				strcat((char *) tmp_str, " ");
			} else {
				strcat((char *) tmp_str, "   ");
			}
		}

		strcat((char *) tmp_str, "  ");
		l = strlen((char *) tmp_str);

		/* Output the ASCII bytes */
		for (j = i; j < (i + 16); j++) {
			if (j < len) {
				char c = * (data + j);

				if (c < ' ' || c > 'z') {
					c = '.';
				}

				tmp_str[l ++] = c;
			} else {
				tmp_str[l ++] = ' ';
			}
		}

		tmp_str[l ++] = '\r';
		tmp_str[l ++] = '\n';
		tmp_str[l ++] = '\0';
		SNOOPDBG("%s", (const char *) tmp_str);     //add (const char*)
	}
}

/* file descriptor of the BT snoop file (by default, -1 means disabled) */
int hci_brt_debug_fd = -1;

/* Macro to perform a multiplication of 2 unsigned 32bit values and store the result
 * in an unsigned 64 bit value (as two 32 bit variables):
 * u64 = u32In1 * u32In2
 * u32OutLow = u64[31:0]
 * u32OutHi = u64[63:32]
 * basically the algorithm:
 * (hi1*2^16 + lo1)*(hi2*2^16 + lo2) = lo1*lo2 + (hi1*hi2)*2^32 + (hi1*lo2 + hi2*lo1)*2^16
 * and the carry is propagated 16 bit by 16 bit:
 * result[15:0] = lo1*lo2 & 0xFFFF
 * result[31:16] = ((lo1*lo2) >> 16) + (hi1*lo2 + hi2*lo1)
 * and so on
 */
#define HCIDISP_MULT_64(u32In1, u32In2, u32OutLo, u32OutHi)                             \
    do {                                                                                    \
        uint32_t u32In1Tmp = u32In1;                                                          \
        uint32_t u32In2Tmp = u32In2;                                                          \
        uint32_t u32Tmp, u32Carry;                                                            \
        u32OutLo = (u32In1Tmp & 0xFFFF) * (u32In2Tmp & 0xFFFF);              /*lo1*lo2*/    \
        u32OutHi = ((u32In1Tmp >> 16) & 0xFFFF) * ((u32In2Tmp >> 16) & 0xFFFF); /*hi1*hi2*/ \
        u32Tmp = (u32In1Tmp & 0xFFFF) * ((u32In2Tmp >> 16) & 0xFFFF);  /*lo1*hi2*/          \
        u32Carry = (uint32_t)((u32OutLo>>16)&0xFFFF);                                         \
        u32Carry += (u32Tmp&0xFFFF);                                                        \
        u32OutLo += (u32Tmp << 16) ;                                                        \
        u32OutHi += (u32Tmp >> 16);                                                         \
        u32Tmp = ((u32In1Tmp >> 16) & 0xFFFF) * (u32In2Tmp & 0xFFFF);                       \
        u32Carry += (u32Tmp)&0xFFFF;                                                        \
        u32Carry>>=16;                                                                      \
        u32OutLo += (u32Tmp << 16);                                                         \
        u32OutHi += (u32Tmp >> 16);                                                         \
        u32OutHi += u32Carry;                                                               \
    } while (0)

/* Macro to make an addition of 2 64 bit values:
 * result = (u32OutHi & u32OutLo) + (u32InHi & u32InLo)
 * u32OutHi = result[63:32]
 * u32OutLo = result[31:0]
 */
#define HCIDISP_ADD_64(u32InLo, u32InHi, u32OutLo, u32OutHi)                            \
    do {                                                                                    \
        (u32OutLo) += (u32InLo);                                                            \
        if ((u32OutLo) < (u32InLo)) (u32OutHi)++;                                           \
        (u32OutHi) += (u32InHi);                                                            \
    } while (0)

/* EPOCH in microseconds since 01/01/0000 : 0x00dcddb3.0f2f8000 */
#define BRT_DEBUG_EPOCH_HI 0x00dcddb3U
#define BRT_DEBUG_EPOCH_LO 0x0f2f8000U

/*******************************************************************************
 **
 ** Function         tv_to_brt_debug_ts
 **
 ** Description      This function generate a BT Snoop timestamp.
 **
 ** Returns          void
 **
 ** NOTE
 ** The return value is 64 bit as 2 32 bit variables out_lo and * out_hi.
 ** A BT Snoop timestamp is the number of microseconds since 01/01/0000.
 ** The timeval structure contains the number of microseconds since EPOCH
 ** (01/01/1970) encoded as: tv.tv_sec, number of seconds since EPOCH and
 ** tv_usec, number of microseconds in current second
 **
 ** Therefore the algorithm is:
 **  result = tv.tv_sec * 1000000
 **  result += tv.tv_usec
 **  result += EPOCH_OFFSET
 *******************************************************************************/
static void tv_to_brt_debug_ts(uint32_t *out_lo, uint32_t *out_hi, struct timeval *tv)
{
	/* multiply the seconds by 1000000 */
	HCIDISP_MULT_64(tv->tv_sec, 0xf4240, *out_lo, *out_hi);

	/* add the microseconds */
	HCIDISP_ADD_64((uint32_t)tv->tv_usec, 0, *out_lo, *out_hi);

	/* add the epoch */
	HCIDISP_ADD_64(BRT_DEBUG_EPOCH_LO, BRT_DEBUG_EPOCH_HI, *out_lo, *out_hi);
}

/*******************************************************************************
 **
 ** Function         l_to_be
 **
 ** Description      Function to convert a 32 bit value into big endian format
 **
 ** Returns          32 bit value in big endian format
*******************************************************************************/
static uint32_t l_to_be(uint32_t x)
{
#if __BIG_ENDIAN != TRUE
	x = (x >> 24) |
	    ((x >> 8) & 0xFF00) |
	    ((x << 8) & 0xFF0000) |
	    (x << 24);
#endif
	return x;
}

/*******************************************************************************
 **
 ** Function         brt_debug_is_open
 **
 ** Description      Function to check if BRT_DEBUG is open
 **
 ** Returns          1 if open otherwise 0
*******************************************************************************/
int brt_debug_is_open(void)
{
#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)
	SNOOPDBG("brt_debug_is_open: snoop fd = %d\n", hci_brt_debug_fd);

	if (hci_brt_debug_fd != -1) {
		return 1;
	}

	return 0;
#else
	return 2;  /* Snoop not available  */
#endif
}

/*******************************************************************************
 **
 ** Function         brt_debug_log_open
 **
 ** Description      Function to open the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
static int brt_debug_log_open(char *brt_debug_logfile)
{
#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)
	hci_brt_debug_fd = -1;

	SNOOPDBG("brt_debug_log_open: snoop log file = %s\n", brt_debug_logfile);

	/* write the BT snoop header */
	if ((brt_debug_logfile != NULL) && (strlen(brt_debug_logfile) != 0)) {
		hci_brt_debug_fd = open(brt_debug_logfile, \
		                      O_WRONLY | O_CREAT | O_TRUNC, \
		                      S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);

		if (hci_brt_debug_fd == -1) {
			perror("open");
			SNOOPDBG("brt_debug_log_open: Unable to open snoop log file\n");
			hci_brt_debug_fd = -1;
			return 0;
		}

		write(hci_brt_debug_fd, "btsnoop\0\0\0\0\1\0\0\x3\xea", 16);
		return 1;
	}

#endif
	return 2;  /* Snoop not available  */
}

/*******************************************************************************
 **
 ** Function         brt_debug_log_close
 **
 ** Description      Function to close the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
static int brt_debug_log_close(void)
{
#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)

	/* write the BT snoop header */
	if (hci_brt_debug_fd != -1) {
		SNOOPDBG("brt_debug_log_close: Closing snoop log file\n");
		close(hci_brt_debug_fd);
		hci_brt_debug_fd = -1;
		return 1;
	}

	return 0;
#else
	return 2;  /* Snoop not available  */
#endif
}

/*******************************************************************************
 **
 ** Function         brt_debug_hci_cmd
 **
 ** Description      Function to add a command in the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
void brt_debug_hci_cmd(unsigned char *p)
{

	if (hci_brt_debug_fd != -1) {
		uint32_t value, value_hi;
		struct timeval tv;

		/* since these display functions are called from different contexts */
		utils_lock();

		/* store the length in both original and included fields */
		SNOOPDBG("brt_debug_hci_cmd: fd = %d, len:%d", hci_brt_debug_fd, p[2]);
		value = l_to_be(p[2] + 4);
		write(hci_brt_debug_fd, &value, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* flags: command sent from the host */
		value = l_to_be(2);
		write(hci_brt_debug_fd, &value, 4);
		/* drops: none */
		value = 0;
		write(hci_brt_debug_fd, &value, 4);
		/* time */
		gettimeofday(&tv, NULL);
		tv_to_brt_debug_ts(&value, &value_hi, &tv);
		value_hi = l_to_be(value_hi);
		value = l_to_be(value);
		write(hci_brt_debug_fd, &value_hi, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* data */
		write(hci_brt_debug_fd, "\x1", 1);
		write(hci_brt_debug_fd, p, p[2] + 3);

		/* since these display functions are called from different contexts */
		utils_unlock();
	}
}

/*******************************************************************************
 **
 ** Function         brt_debug_hci_evt
 **
 ** Description      Function to add a event in the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
void brt_debug_hci_evt(unsigned char *p)
{

	if (hci_brt_debug_fd != -1) {
		uint32_t value, value_hi;
		struct timeval tv;

		/* since these display functions are called from different contexts */
		utils_lock();

		SNOOPDBG("brt_debug_hci_evt: fd = %d, len = %d.", hci_brt_debug_fd, p[1]);
		/* store the length in both original and included fields */
		value = l_to_be(p[1] + 3);
		write(hci_brt_debug_fd, &value, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* flags: event received in the host */
		value = l_to_be(3);
		write(hci_brt_debug_fd, &value, 4);
		/* drops: none */
		value = 0;
		write(hci_brt_debug_fd, &value, 4);
		/* time */
		gettimeofday(&tv, NULL);
		tv_to_brt_debug_ts(&value, &value_hi, &tv);
		value_hi = l_to_be(value_hi);
		value = l_to_be(value);
		write(hci_brt_debug_fd, &value_hi, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* data */
		write(hci_brt_debug_fd, "\x4", 1);
		write(hci_brt_debug_fd, p, p[1] + 2);

		/* since these display functions are called from different contexts */
		utils_unlock();
	}
}

/*******************************************************************************
 **
 ** Function         brt_debug_sco_data
 **
 ** Description      Function to add a SCO data packet in the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
void brt_debug_sco_data(unsigned char *p, uint8_t is_rcvd)
{
	SNOOPDBG("brt_debug_sco_data: fd = %d", hci_brt_debug_fd);

	if (hci_brt_debug_fd != -1) {
		uint32_t value, value_hi;
		struct timeval tv;

		/* since these display functions are called from different contexts */
		utils_lock();

		/* store the length in both original and included fields */
		value = l_to_be(p[2] + 4);
		write(hci_brt_debug_fd, &value, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* flags: data can be sent or received */
		value = l_to_be(is_rcvd ? 1 : 0);
		write(hci_brt_debug_fd, &value, 4);
		/* drops: none */
		value = 0;
		write(hci_brt_debug_fd, &value, 4);
		/* time */
		gettimeofday(&tv, NULL);
		tv_to_brt_debug_ts(&value, &value_hi, &tv);
		value_hi = l_to_be(value_hi);
		value = l_to_be(value);
		write(hci_brt_debug_fd, &value_hi, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* data */
		write(hci_brt_debug_fd, "\x3", 1);
		write(hci_brt_debug_fd, p, p[2] + 3);

		/* since these display functions are called from different contexts */
		utils_unlock();
	}
}

/*******************************************************************************
 **
 ** Function         brt_debug_acl_data
 **
 ** Description      Function to add an ACL data packet in the BRT_DEBUG file
 **
 ** Returns          None
*******************************************************************************/
void brt_debug_acl_data(unsigned char *p, uint8_t is_rcvd)
{

	if (hci_brt_debug_fd != -1) {
		uint32_t value, value_hi;
		struct timeval tv;

		/* since these display functions are called from different contexts */
		utils_lock();

		/* store the length in both original and included fields */
		value = l_to_be((p[3] << 8) + p[2] + 5);
		SNOOPDBG("brt_debug_acl_data: fd = %d, len:%d", hci_brt_debug_fd, (value - 5));
		write(hci_brt_debug_fd, &value, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* flags: data can be sent or received */
		value = l_to_be(is_rcvd ? 1 : 0);
		write(hci_brt_debug_fd, &value, 4);
		/* drops: none */
		value = 0;
		write(hci_brt_debug_fd, &value, 4);
		/* time */
		gettimeofday(&tv, NULL);
		tv_to_brt_debug_ts(&value, &value_hi, &tv);
		value_hi = l_to_be(value_hi);
		value = l_to_be(value);
		write(hci_brt_debug_fd, &value_hi, 4);
		write(hci_brt_debug_fd, &value, 4);
		/* data */
		write(hci_brt_debug_fd, "\x2", 1);
		write(hci_brt_debug_fd, p, (p[3] << 8) + p[2] + 4);

		/* since these display functions are called from different contexts */
		utils_unlock();
	}
}


/********************************************************************************
 ** API allow external realtime parsing of output using e.g hcidump
 *********************************************************************************/

#define EXT_PARSER_PORT 4338

static pthread_t thread_id;
static int s_listen = -1;
static int ext_parser_fd = -1;

static void ext_parser_detached(void);

static int ext_parser_accept(int port)
{
	socklen_t           clilen;
	struct sockaddr_in  cliaddr, servaddr;
	int s, srvlen;
	int n = 1;
	int size_n;
	int result = 0;

	SNOOPDBG("waiting for connection on port %d", port);
	if (s_listen > 0) {
		SNOOPDBG("The previous listen socket did not shutdown!");
		close(s_listen);
		s_listen = -1;
	}

	s_listen = socket(AF_INET, SOCK_STREAM, 0);

	if (s_listen < 0) {
		SNOOPDBG("listener not created: listen fd %d", s_listen);
		return -1;
	}

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(port);

	srvlen = sizeof(servaddr);

	/* allow reuse of sock addr upon bind */
	result = setsockopt(s_listen, SOL_SOCKET, SO_REUSEADDR, &n, sizeof(n));

	if (result < 0) {
		perror("setsockopt");
	}

	result = bind(s_listen, (struct sockaddr *) &servaddr, srvlen);

	if (result < 0)
		perror("bind");

	result = listen(s_listen, 1);

	if (result < 0)
		perror("listen");

	clilen = sizeof(struct sockaddr_in);

	s = accept(s_listen, (struct sockaddr *) &cliaddr, &clilen);

	if (s < 0) {
		perror("accept");
		return -1;
	}

	SNOOPDBG("connected (%d)", s);

	return s;
}

static int send_ext_parser(char *p, int len)
{
	int n = 0;

	/* check if io socket is connected */
	if (ext_parser_fd == -1)
		return 0;

	SNOOPDBG("write %d to snoop socket\n", len);

	utils_lock();
	if (ext_parser_fd > 0) {
		n = write(ext_parser_fd, p, len);
	}
	utils_unlock();

	if (n <= 0) {
		ext_parser_detached();
	}

	return n;
}

static void ext_parser_detached(void)
{
	//SNOOPDBG("ext parser detached");

	utils_lock();
	if (ext_parser_fd > 0)
		close(ext_parser_fd);

	if (s_listen > 0)
		close(s_listen);

	ext_parser_fd = -1;
	s_listen = -1;
	utils_unlock();
}

static void interruptFn(int sig)
{
	//SNOOPDBG("interruptFn");
	pthread_exit(0);
}

static void ext_parser_thread(void *param)
{
	int fd;
	int sig = SIGUSR2;
	sigset_t sigSet;
	sigemptyset(&sigSet);
	sigaddset(&sigSet, sig);

	//SNOOPDBG("ext_parser_thread");

	prctl(PR_SET_NAME, (unsigned long)"BtsnoopExtParser", 0, 0, 0);

	pthread_sigmask(SIG_UNBLOCK, &sigSet, NULL);

	struct sigaction act;
	act.sa_handler = interruptFn;
	sigaction(sig, &act, NULL);

	do {
		fd = ext_parser_accept(EXT_PARSER_PORT);

		utils_lock();
		ext_parser_fd = fd;

		SNOOPDBG("ext parser attached on fd %d\n", ext_parser_fd);
		utils_unlock();
	} while (1);
}

void brt_debug_stop_listener(void)
{
	ext_parser_detached();
}

void brt_debug_init(void)
{
	if(get_brt_debug_status() != BRT_DEBUG_UNINIT) {
		return ;
	}
	set_brt_debug_status(BRT_DEBUG_INIT);
#if defined(BRT_DEBUG_EXT_PARSER_INCLUDED) && (BRT_DEBUG_EXT_PARSER_INCLUDED == TRUE)
	SNOOPDBG("brt_debug_init");

	utils_init();

	/* always setup ext listener port */
	if (pthread_create(&thread_id, NULL,
	                   (void *)ext_parser_thread, NULL) != 0)
		perror("pthread_create");

#endif
}

void brt_debug_open(char *p_path)
{
#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)
	SNOOPDBG("brt_debug_open");
	brt_debug_log_open(p_path);
#endif // BRT_DEBUGDISP_INCLUDED
}

void brt_debug_close(void)
{
#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)
	SNOOPDBG("brt_debug_close");
	brt_debug_log_close();
#endif
}

void brt_debug_cleanup(void)
{
#if defined(BRT_DEBUG_EXT_PARSER_INCLUDED) && (BRT_DEBUG_EXT_PARSER_INCLUDED == TRUE)
	SNOOPDBG("brt_debug_cleanup");
	pthread_kill(thread_id, SIGUSR2);
	pthread_join(thread_id, NULL);
	ext_parser_detached();
#endif
	set_brt_debug_status(BRT_DEBUG_UNINIT);
}


#define HCIT_TYPE_COMMAND   1
#define HCIT_TYPE_ACL_DATA  2
#define HCIT_TYPE_SCO_DATA  3
#define HCIT_TYPE_EVENT     4

//void brt_debug_capture(HC_BT_HDR *p_buf, unsigned char is_rcvd)
void brt_debug_capture(unsigned char *p_buf, uint32_t len, uint8_t is_rcvd)
{
	//unsigned char *p = (uint8_t *)(p_buf + 1) + p_buf->offset;
	unsigned char *p = p_buf;
	unsigned char event = *p_buf;
	uint32_t sent = 0;
	uint32_t l;

#if defined(BRT_DEBUG_EXT_PARSER_INCLUDED) && (BRT_DEBUG_EXT_PARSER_INCLUDED == TRUE)
	s_buffer[0] = is_rcvd;
	while (sent < len) {
		l = (len - sent) > 1023 ? 1023 : (len - sent);
		memcpy(s_buffer + 1, p + sent, l);
		send_ext_parser((char *)s_buffer, l + 1);
		sent += l;
	}
	return;
#endif

#if defined(BRT_DEBUGDISP_INCLUDED) && (BRT_DEBUGDISP_INCLUDED == TRUE)

	if (hci_brt_debug_fd == -1)
		return;
#if 0
	switch (p_buf->event & MSG_EVT_MASK) {
	case MSG_HC_TO_STACK_HCI_EVT:
		SNOOPDBG("TYPE : EVT");
		brt_debug_hci_evt(p);
		break;

	case MSG_HC_TO_STACK_HCI_ACL:
	case MSG_STACK_TO_HC_HCI_ACL:
		SNOOPDBG("TYPE : ACL");
		brt_debug_acl_data(p, is_rcvd);
		break;

	case MSG_HC_TO_STACK_HCI_SCO:
	case MSG_STACK_TO_HC_HCI_SCO:
		SNOOPDBG("TYPE : SCO");
		brt_debug_sco_data(p, is_rcvd);
		break;

	case MSG_STACK_TO_HC_HCI_CMD:
		SNOOPDBG("TYPE : CMD");
		brt_debug_hci_cmd(p);
		break;
	}
#else

	p += 1;
	switch (event) {
	case 1: // COMMAND
		brt_debug_hci_cmd(p);
		break;

	case 2: // ACL
		brt_debug_acl_data(p, is_rcvd);
		break;

	case 3: // SCO
		brt_debug_sco_data(p, is_rcvd);
		break;

	case 4: // EVENT
		brt_debug_hci_evt(p);
		break;
	}
#endif

#endif // BRT_DEBUGDISP_INCLUDED
}


