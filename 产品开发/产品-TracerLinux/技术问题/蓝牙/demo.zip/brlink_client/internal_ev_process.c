#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <errno.h>
#include <pthread.h>
#include "internal_ev_process.h"
#include "bt_utils.h"

enum {
	STATE_TYPE,
	STATE_LEN,
	STATE_VALUE
};

typedef struct tag_internal_ev_node_cbk {
	internal_event_callback cbk;
	struct list_head node;
} internal_ev_cbk_node_t;

typedef struct tag_internal_event_block {
	/* used as communication node */
	int sock_fds[2];
	/* event data cache */
	uint8_t *ev_buf;
	int buf_off;
	int buf_size;

	/* current state of event parser */
	uint8_t state;
	/* save the parsed event data */
	ev_data_t ev_data;
	/* registered callback list */
	struct list_head ev_cbk_list;
	pthread_mutex_t lock;
} internal_ev_block_t;

static internal_ev_block_t s_block;

static internal_ev_cbk_node_t *node_alloc(internal_event_callback cbk)
{
	internal_ev_cbk_node_t * node;

	if ((node = malloc(sizeof(*node))) == NULL) {
		return NULL;
	}

	node->cbk = cbk;
}

void brt_internal_event_init()
{
	int ret;

	memset(&s_block, 0, sizeof(internal_ev_block_t));
	ret = socketpair(AF_UNIX, SOCK_STREAM, 0, s_block.sock_fds);

	if (ret < 0) {
		printf("Create socketpair failed in %s. Error:%s.\n", __func__, strerror(errno));
		s_block.sock_fds[0] = s_block.sock_fds[1] = 0;
	}

	s_block.ev_buf = malloc(EV_BUFFER_SIZE);
	s_block.buf_off = 0;
	s_block.buf_size = EV_BUFFER_SIZE;
	s_block.state = STATE_TYPE;
	INIT_LIST_HEAD(&s_block.ev_cbk_list);
	pthread_mutex_init(&s_block.lock, NULL);
}

void brt_internal_event_done()
{
	internal_ev_cbk_node_t *tmp = NULL;
	internal_ev_cbk_node_t *ntmp = NULL;

	if (s_block.sock_fds[0] > 0) {
		close(s_block.sock_fds[0]);
	}

	if (s_block.sock_fds[1] > 0) {
		close(s_block.sock_fds[1]);
	}

	if (NULL != s_block.ev_buf) {
		free(s_block.ev_buf);
		s_block.ev_buf = NULL;
	}

	pthread_mutex_lock(&s_block.lock);
	list_for_each_entry_safe(tmp, ntmp, &s_block.ev_cbk_list, node) {
		if (tmp != NULL) {
			list_del(&tmp->node);
			free(tmp);
		}
	}
	pthread_mutex_unlock(&s_block.lock);
	pthread_mutex_destroy(&s_block.lock);
}

void brt_internal_event_register(internal_event_callback cbk)
{
	internal_ev_cbk_node_t *ev_node = node_alloc(cbk);

	pthread_mutex_lock(&s_block.lock);
	if (ev_node != NULL) {
		list_add(&ev_node->node, &s_block.ev_cbk_list);
	}
	pthread_mutex_unlock(&s_block.lock);
}

void brt_internal_event_unregister(internal_event_callback cbk)
{
	uint8_t found = 0;
	internal_ev_cbk_node_t *tmp = NULL;

	pthread_mutex_lock(&s_block.lock);
	list_for_each_entry(tmp, &s_block.ev_cbk_list, node) {
		if (tmp->cbk == cbk) {
			found = 1;
			break;
		}
	}

	if (found && tmp != NULL) {
		list_del(&tmp->node);
		free(tmp);
	}

	pthread_mutex_unlock(&s_block.lock);
}

static void notify_internal_event(ev_data_t *ev)
{
	internal_ev_cbk_node_t *tmp = NULL;

	if (ev == NULL) {
		return;
	}

	pthread_mutex_lock(&s_block.lock);
	list_for_each_entry(tmp, &s_block.ev_cbk_list, node) {
		if (tmp->cbk != NULL) {
			tmp->cbk(ev);
		}
	}
	pthread_mutex_unlock(&s_block.lock);
}

static void push_ev_data(void *buf, size_t count)
{
	if (s_block.buf_off + count > s_block.buf_size) {
		s_block.buf_size += ((count + EV_BUFFER_SIZE - 1) / EV_BUFFER_SIZE) * EV_BUFFER_SIZE;
		s_block.ev_buf = realloc(s_block.ev_buf, s_block.buf_size);
	}

	memcpy(s_block.ev_buf + s_block.buf_off, buf, count);
	s_block.buf_off += count;
}

static void process_ev_data()
{
	int off = 0;
	int cp_len = 0;
	int expected_len = 0;
	int remain_len = 0;

	while (off < s_block.buf_off) {
		switch (s_block.state) {
			case STATE_TYPE:
				s_block.ev_data.type = *(s_block.ev_buf + off);
				s_block.state = STATE_LEN;
				off++;
				break;
			case STATE_LEN:
				s_block.ev_data.len = *(s_block.ev_buf + off);
				if (s_block.ev_data.len > EV_BUFFER_SIZE) {
					printf("Warning!!! The maximum length of internal event data size should be less than %d, current len:%d.type:%d.\n", EV_BUFFER_SIZE, s_block.ev_data.len, s_block.ev_data.type);
					s_block.state = STATE_VALUE;
				} else if (s_block.ev_data.len > 0) {
					s_block.state = STATE_VALUE;
				} else {
					s_block.ev_data.off = 0;
					s_block.state = STATE_TYPE;
					notify_internal_event(&s_block.ev_data);
				}
				off++;
				break;
			case STATE_VALUE:
				remain_len = s_block.buf_off - off;
				expected_len = s_block.ev_data.len - s_block.ev_data.off;

				if (remain_len >= expected_len) {
					cp_len = (s_block.ev_data.len > EV_BUFFER_SIZE ? EV_BUFFER_SIZE : s_block.ev_data.len) - s_block.ev_data.off;
					
					if (cp_len > 0) {
						memcpy(s_block.ev_data.value + s_block.ev_data.off, s_block.ev_buf + off, cp_len);
					}
					off += expected_len;
					s_block.ev_data.off = 0;
					s_block.state = STATE_TYPE;
					notify_internal_event(&s_block.ev_data);
				} else {
					cp_len = remain_len > (EV_BUFFER_SIZE - s_block.ev_data.off) ? (EV_BUFFER_SIZE - s_block.ev_data.off): remain_len;

					if (cp_len > 0) {
						memcpy(s_block.ev_data.value + s_block.ev_data.off, s_block.ev_buf + off, cp_len);
					}
					off += remain_len;
					s_block.ev_data.off += cp_len;
				}
				break;
			default:
				/* should not be here */
				off = s_block.buf_off;
				break;
		}
	}

	s_block.buf_off -= off; /* should be 0 */
}

ssize_t read_all(int fd, void *buf, size_t count)
{
	fd_set rfds;
	int retval;
	int max_fd = s_block.sock_fds[0] > fd ? s_block.sock_fds[0] : fd;

	FD_ZERO(&rfds);
	FD_SET(fd, &rfds);
	FD_SET(s_block.sock_fds[0], &rfds);

	retval = select(max_fd + 1, &rfds, NULL, NULL, NULL);

	if (retval == -1) {
		return -1;
	} else if (retval) {
		if (FD_ISSET(s_block.sock_fds[0], &rfds)) {
			retval = read(s_block.sock_fds[0], buf, count);
			push_ev_data(buf, retval);
			process_ev_data();
			return 0;
		} else {
			return read(fd, buf, count);
		}
	}
}

int brt_internal_event_send(uint8_t event, uint8_t data_len, void *data)
{
	ev_data_t ev;
	int cp_len;
	int ret = 0;
	
	cp_len = data_len > EV_BUFFER_SIZE ? EV_BUFFER_SIZE : data_len;
	ev.type = event;
	ev.len = cp_len;

	if (ev.len > 0) {
		memcpy(ev.value, data, ev.len);
	}

	if (s_block.sock_fds[1] > 0) {
		ret = write(s_block.sock_fds[1], &ev, 2 + ev.len);
		ret = (ret == 2 + ev.len);
	}

	return ret;
}

