#include <pthread.h>
#include <stdint.h>
#include <semaphore.h>

#include "brt_pbap_queue.h"

sem_t sem;
static int s_queue_count = 0;
static pthread_mutex_t s_queue_lock;
static bse_pbap_queue_t *s_bse_pbap_queue = NULL;

void start_pbap_queue()
{
	s_queue_count = 0;
	sem_init(&sem, 0, 0);
	pthread_mutex_init(&s_queue_lock, NULL);
}

void stop_pbap_queue()
{
	s_queue_count = 0;
	//FIXME sem_post?
	sem_destroy(&sem);
	pthread_mutex_destroy(&s_queue_lock);
}

void writeto_pbap_queue(bse_pbap_queue_t *pbap_queue)
{
	pthread_mutex_lock(&s_queue_lock);
	if(pbap_queue == NULL){
		printf("ERROR: pbap_queue is NULL !!!\r\n");
		pthread_mutex_unlock(&s_queue_lock);
		return;
	}
	if(s_bse_pbap_queue == NULL){
		s_bse_pbap_queue = pbap_queue;
		s_bse_pbap_queue->next = NULL;
	} else {
		bse_pbap_queue_t *p_cur = s_bse_pbap_queue;
		bse_pbap_queue_t *p_pre = s_bse_pbap_queue;
		while(p_cur) {
			p_pre = p_cur;
			p_cur = p_pre->next;
		}
		p_pre->next = pbap_queue;
	}
	pbap_thread_post();
	s_queue_count ++;
//	printf("[%s] %s->%d:s_queue_count is %d\r\n", get_current_time_string(), __func__, __LINE__, s_queue_count);
	pthread_mutex_unlock(&s_queue_lock);
}


bse_pbap_queue_t* readfrom_pbap_queue()
{
	
	bse_pbap_queue_t *p_cur = s_bse_pbap_queue;
	if(p_cur != NULL) {
		pthread_mutex_lock(&s_queue_lock);
		s_queue_count--;
//		printf("[%s] %s->%d:s_queue_count is %d\r\n", get_current_time_string(), __func__, __LINE__, s_queue_count);
		s_bse_pbap_queue = p_cur->next;
		pthread_mutex_unlock(&s_queue_lock);
	}
	return p_cur;
}

void pbap_thread_wait()
{
	sem_wait(&sem);
}

void pbap_thread_post()
{
	sem_post(&sem);
}

