#ifndef BTAPP_UTILS_H__
#define BTAPP_UTILS_H__

#include "bluetooth.h"

/**
  * Convert byte stream which may include NULL-terminated character(\0) to a new byte stream.
  * The new byte stream will exclude any NULL-terminated character.
  * NOTE: the new byte stream may be larger than the original byte stream.
  *       You can call the "str_bytes_to_raw_bytes" to convert it back to the original byte stream.
  *
  * Parameters:
  * raw_bytes:   The original byte stream which want to be converted.
  * raw_length:  The length of the raw bytes.
  * result_byte: The buffer which keep the result byte stream. If is NULL, no conversion will be done,
  *              but just return the length the result byte stream through the output parameter result_len,
  *              else, the caller should keep the space is enough to keep the result.
  * result_len:  [output parameter]. The length of the result byte stream.
  *
  * Return:
        the pointer of the result byte stream.
  */
unsigned char * raw_bytes_to_str_bytes(const unsigned char *raw_bytes, unsigned short raw_len,
                                       unsigned char *result_bytes, unsigned short *result_len);

/**
  * Do the reverse conversion as "raw_bytes_to_str_bytes".
  *
  * Parameters:
  * raw_bytes:  The original byte stream which want to be converted.
  * raw_length: the length of the raw bytes.
  * result_byte: the buffer which keep the result byte stream. If is NULL, no conversion will be done,
  *              but just return the length the result byte stream through the output parameter result_len.
  * result_len:  [output parameter]. The length of the result byte stream.
  *
  * Return:
        the pointer of the result byte stream.
  */
unsigned char * str_bytes_to_raw_bytes(const unsigned char *raw_bytes, unsigned short raw_len,
                                       unsigned char *result_bytes, unsigned short *result_len);

unsigned char parse_byte(char *p);
unsigned char parse_byte_with_base(char *p, int base);
unsigned char parse_char_with_base(char *p, int base);
unsigned short parse_uuid16(char *p);
unsigned short parse_short(char *p);
unsigned int parse_int(char *p);
long parse_long(char *p);
void parse_uuid128(char *p, bt_uuid_t *uuid_128);
bt_bdaddr_t parse_address(char *p);
unsigned char *parse_bytes(char *p, int *len);
void combine_name(unsigned char * des_name, int des_name_len, unsigned char *raw_name, int raw_name_len);
int sendfd_client(int sock_fd, int send_me_fd);
int recvfd_client(int sock_fd);
void hex_to_str_ex(char *ptr,unsigned char *buf,int len);
void hex_to_asciistring(uint8_t* str,uint32_t size,uint8_t* str1);
struct list_head {
	struct list_head *next, *prev;
}; 

#define LIST_HEAD_INIT(name) { &(name), &(name) }

#define LIST_HEAD(name) \
		struct list_head name = LIST_HEAD_INIT(name)

static inline void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

static inline void __list_add(struct list_head *new, struct list_head *prev, struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

static inline void list_add(struct list_head *new, struct list_head *head)
{
		__list_add(new, head, head->next);
}


static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
		__list_add(new, head->prev, head);
}

static inline void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

static inline void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

#define list_entry(ptr, type, member) \
	({				\
	 	void *__mptr = (void *)(ptr);					\
	 	((type *)(__mptr - ((size_t)&((type *)0)->member))); })


#define list_first_entry(ptr, type, member) \
		list_entry((ptr)->next, type, member)

#define list_last_entry(ptr, type, member) \
		list_entry((ptr)->prev, type, member)

#define list_first_entry_or_null(ptr, type, member) ({ \
			struct list_head *head__ = (ptr); \
			struct list_head *pos__ = (head__->next); \
			pos__ != head__ ? list_entry(pos__, type, member) : NULL; \
		})

#define list_next_entry(pos, member) \
		list_entry((pos)->member.next, typeof(*(pos)), member)

#define list_prev_entry(pos, member) \
		list_entry((pos)->member.prev, typeof(*(pos)), member)

#define list_for_each(pos, head) \
		for (pos = (head)->next; pos != (head); pos = pos->next)

#define list_for_each_prev(pos, head) \
		for (pos = (head)->prev; pos != (head); pos = pos->prev)

#define list_for_each_safe(pos, n, head) \
		for (pos = (head)->next, n = pos->next; pos != (head); \
						pos = n, n = pos->next)

#define list_for_each_entry(pos, head, member)				\
		for (pos = list_first_entry(head, typeof(*pos), member);	\
		     &pos->member != (head);					\
		     pos = list_next_entry(pos, member))

#define list_for_each_entry_safe(pos, n, head, member)			\
		for (pos = list_first_entry(head, typeof(*pos), member),	\
			n = list_next_entry(pos, member);			\
		     &pos->member != (head); 					\
		     pos = n, n = list_next_entry(n, member))

#endif // BTAPP_UTILS_H__

