#ifndef _BRT_CLIENT_H__
#define _BRT_CLIENT_H__

int brt_sdk_init();
int brt_sdk_init_ex(const char *path);
void brt_sdk_done();

#endif /* _BRT_CLIENT_H__ */
