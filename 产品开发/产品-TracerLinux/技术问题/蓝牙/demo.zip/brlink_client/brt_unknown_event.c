#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bluetooth.h"
#include "bt_utils.h"
#include "brt_event_parser.h"
#include "brt_unknown_event.h"

static int unknown_process_event(struct tag_event_parser *evt_parser, uint8_t *buffer, int offset, int length);

event_parser_t *create_unknown_event_parser()
{
	event_parser_t *base = create_event_parser();

	if (base == NULL) {
		return NULL;
	}

	base->process_event = unknown_process_event;
	return base;
}

void destroy_unknown_event_parser(event_parser_t * parser)
{
	if (parser != NULL) {
		free(parser);
	}
}

static int unknown_process_event(struct tag_event_parser *evt_parser, uint8_t *buffer, int offset, int length)
{
	int i;

	for (i = 0; i < length; i++) {
		if (buffer[offset + i] == '\0') {
			return offset + i;
		}
	}
	return -1;
}
