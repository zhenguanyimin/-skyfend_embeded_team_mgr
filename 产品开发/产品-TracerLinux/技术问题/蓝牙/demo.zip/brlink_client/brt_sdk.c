#include <unistd.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "brt_sdk.h"
#include "brt_event_parser.h"
#include "brt_unknown_event.h"
#include "bt_utils.h"

//#define VERBOSE_LOG
#define log printf

#ifdef VERBOSE_LOG
#include "brt_debug.h"

//For YINGTAI, do not delete this
//#include "../include/autoconf.h"

#define vlog log 
static uint8_t debug_rx_buf[260];
static uint8_t debug_tx_buf[260];
#define FILL_DEBUG_EVENT(dest, src, len) do { \
	dest[0] = 0x04; \
	dest[1] = 0xFF; \
	dest[2] = (len); \
	memcpy(((char *)dest) + 3, (src), (len)); \
} while(0);

#define FILL_DEBUG_CMD(dest, src, len) do { \
	dest[0] = 0x01; \
	dest[1] = 0x01; \
	dest[2] = 0xFC; \
	dest[3] = (len); \
	memcpy(((char *)dest) + 4, (src), (len)); \
} while(0);

#else
#define vlog(...) ((void *) 0)
#endif

#define READ_BUFFER_SIZE 4095

#ifdef CONFIG_EV_LOOPER_ADD_INTERNAL
#include "internal_ev_process.h"
#else
#define read_all read
#endif

static void dump_at_event(void *buf, size_t len)
{
#ifdef VERBOSE_LOG_NO_OUTDEBUGSTRING
	unsigned long i, j, l;
	unsigned char tmp_str[140];
	unsigned char tmp_str1[10];
	unsigned char *data = (unsigned char *)buf;

	for (i = 0; i < len; i += 16) {
		int n ;
		tmp_str[0] = '\0';
		n = i ;

		for (j = 0; j < 4; j++) {
			l = n % 16;

			if (l >= 10)
				tmp_str[3 - j] = (unsigned char)('A' + l - 10);
			else
				tmp_str[3 - j] = (unsigned char)(l + '0');

			n >>= 4 ;
		}

		tmp_str[4] = '\0';
		strcat((char *) tmp_str, ": ");

		/*
		   Output the hex bytes
		 */
		for (j = i; j < (i + 16); j ++) {
			int m ;

			if (j < len) {
				m = ((unsigned int)(*(data + j))) / 16 ;

				if (m >= 10)
					tmp_str1[0] = 'A' + (unsigned char) m - 10;
				else
					tmp_str1[0] = (unsigned char) m + '0';

				m = ((unsigned int)(*(data + j))) % 16 ;

				if (m >= 10)
					tmp_str1[1] = 'A' + (unsigned char) m - 10;
				else
					tmp_str1[1] = (unsigned char) m + '0';

				tmp_str1[2] = '\0';
				strcat((char *) tmp_str, (char *) tmp_str1);
				strcat((char *) tmp_str, " ");
			} else {
				strcat((char *) tmp_str, "   ");
			}
		}

		strcat((char *) tmp_str, "  ");
		l = strlen((char *) tmp_str);

		/* Output the ASCII bytes */
		for (j = i; j < (i + 16); j++) {
			if (j < len) {
				char c = * (data + j);

				if (c < ' ' || c > 'z') {
					c = '.';
				}

				tmp_str[l ++] = c;
			} else {
				tmp_str[l ++] = ' ';
			}
		}

		tmp_str[l ++] = '\r';
		tmp_str[l ++] = '\n';
		tmp_str[l ++] = '\0';
		log("%s", (const char *) tmp_str);
	}
#endif
}

static int s_client_fd;
static int s_running;
static size_t s_offset = 0;
static uint8_t s_buffer[READ_BUFFER_SIZE + 1];

#define MAX_PARSER_NUMBER 16
#define MAX_CONN_COUNT 3
static event_parser_t *s_parsers[MAX_PARSER_NUMBER];
static int s_parser_list_count = 0;

static void *receive_message_proc(void *arg);

static int connect_to_server(const char *path)
{
//	int sd;
//	struct sockaddr_un addr;
//#ifdef CONFIG_PROJECT_YINGTAI
//	int reconn_socket = 0;
//#endif
//	char server_path[128];
//
//	memset(&addr, 0, sizeof(struct sockaddr_un));
//	addr.sun_family = AF_UNIX;
//
//	if (path) {
//		snprintf(server_path, 128, "%s/goc_serial", path);
//	} else {
//		strcpy(server_path, "/data/goc_serial");
//	}
//
//	strncpy(addr.sun_path, server_path, sizeof(addr.sun_path) -1);
//	if (strlen(server_path) < sizeof(addr.sun_path)) {
//		strncpy(addr.sun_path, server_path, sizeof(addr.sun_path) -1);
//	} else {
//		return -1;
//	}
//
//	sd = socket(AF_UNIX, SOCK_STREAM, 0);
//
//	if (sd == -1) {
//		log("create socket failed:%s.\n", strerror(errno));
//		return -1;
//	}
//retry_conn:
//	if (connect(sd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) == -1) {
//		log("connect %s socket failed:%s.\n", addr.sun_path,strerror(errno));
//#ifdef CONFIG_PROJECT_YINGTAI
//		 if(reconn_socket++ < MAX_CONN_COUNT) {
//	            usleep(50 * 1000);
//	            goto retry_conn;
//	     }
//#endif
//		close(sd);
//		return -1;
//	} else {
//		//log("[%s] connect socket successed.\n", get_current_time_string());
//	}

	int fd = -1;
    if (s_running)
    	return -1;
    printf("command_start\n");
    fd = open("/dev/goc_serial", O_RDWR);
    if (fd < 0) {
        printf("%s:open /dev/goc_serial error", __func__);
        return -1;
    }
    s_running = 1;
    pthread_t thread;
    if (pthread_create(&thread, NULL, receive_message_proc, (void*)fd)) {
    	printf("%s create command_reader error", __func__);
        s_running = 0;
        close(fd);
        fd = -1;
        return false;
    }


	s_client_fd = fd;



	return fd;
}

static void disconnect_from_server()
{
	s_running = 0;
	close(s_client_fd);
	s_client_fd = 0;
}

void send_at_command(char *command, int len)
{
#ifdef VERBOSE_LOG
	int i, dtlen, dlen;
	dtlen = strlen(command);
#endif
	if (s_client_fd > 0) {
		write(s_client_fd, command, strlen(command));
		printf("%s %s count:%d ret:%s\n", __FUNCTION__,command,strlen(command),strerror(errno));
#ifdef VERBOSE_LOG
		for(i=0;i<dtlen;i+= dlen) {
			if (i + 0xFF < dtlen) {
				dlen = 0xFF;
			} else {
				dlen = (dtlen - i);
			}

			FILL_DEBUG_CMD(debug_tx_buf, command + i, dlen);
			brt_debug_capture(debug_tx_buf, 4 + dlen, 0);
		}
#endif
	}
}

int recv_data_transport_fd()
{
	int ret;
	if ((ret = recvfd_client(s_client_fd)) == 0) {
		/* try again? */
		ret = recvfd_client(s_client_fd);
	}

	return ret;
}

void register_event_parser(event_parser_t *parser)
{
	s_parsers[s_parser_list_count++] = parser;
}

void unregister_event_parser(event_parser_t *parser)
{
	int i;
	for (i=0; i<MAX_PARSER_NUMBER; i++) {
		if (s_parsers[i] == parser) {
			s_parsers[i] = NULL;
			s_parser_list_count--;
		}
	}
}

static int process_event(uint8_t *buffer, int n_bytes)
{
	int offset = 0;
	int pos;
	uint8_t hit = 1;
	int i = 0;

	while (offset < n_bytes && hit) {
		hit = 0;
		for (i=0; i<MAX_PARSER_NUMBER; i++) {
			event_parser_t *p = s_parsers[i];
			if (p != NULL) {
				if ((pos = p->process_event(p, buffer, offset, n_bytes - offset)) > 0) {
					hit = 1;
					offset = pos;
					break;
				}
			}
		}

		/* remove suffix '\0' */
		while (offset < n_bytes) {
			if (buffer[offset] == '\0') {
				offset++;
			} else {
				break;
			}
		}
	}

	return offset;
}
#ifdef CONFIG_PROJECT_YINGTAI
static int check_process_exists(char *proc_name)
{
    FILE* fp;
    int count = 1;
    char buf[256];
    char command[150];

    sprintf(command, "ps -ef | grep %s | grep -v grep | wc -l", proc_name);

    if((fp = popen(command,"r")) == NULL) {
        printf("[%s] Commands are not executed", get_current_time_string());
        return 1;
    }


    if( (fgets(buf,256,fp))!= NULL ) {
        count = atoi(buf);
        if(count == 0) {
            printf("[%s], process not exist!\n", get_current_time_string());
        } else {
            printf("[%s], process exist [%d]!\n",get_current_time_string(), count);
        }
    } else {
        count = 1;
    }

    printf("[%s], %s->%d, process exist [%d]!\n",get_current_time_string(), __func__, __LINE__, count);
    pclose(fp);
    return count;
}

#define STACK_ERR_EVENT "PA0D\r\n"
#define MAX_READ_RETRY 5
#endif

static void on_char(char c){
	static char buffer[READ_BUFFER_SIZE] = {0};
	static unsigned int count = 0;

	if(count+2 == READ_BUFFER_SIZE){
		count = 0;
		return;
	}

	if('\r' == c || '\n' == c){
//		printf("123count %d:%x ",count,c);
		if(count == 0)return;
		buffer[count++] = '\0';
		printf("count %d command %s\n",count,buffer);
		process_event(buffer, count);
		count = 0;
	}else{
		buffer[count++] = c;
//		printf("count %d:%x ",count,c);
	}
}

static void *receive_message_proc(void *arg)
{
	int server = (int)(intptr_t) arg;
	int read_bytes;
	int expected_bytes;
	int total_bytes;
	int remain_bytes;
	int remain_pos;
	int processed_pos;
	memset(s_buffer,0,sizeof(s_buffer));
#ifdef CONFIG_PROJECT_YINGTAI
	int read_retry_count;
	int stack_died_flag;
#endif
	int i;
	char *extra_str = "";
#ifdef VERBOSE_LOG
	int flag, evt_cnt, dtlen, dlen = 0;
	char cnt_str[16] = {0};
#endif

	if (server <= 0) {
		return 0;
	}
#ifdef CONFIG_PROJECT_YINGTAI	
	read_retry_count = 0;
	stack_died_flag = 0;
#endif
	while (s_running) {
		expected_bytes = READ_BUFFER_SIZE - s_offset;
		read_bytes  = read_all(server, s_buffer + s_offset, expected_bytes);
		printf("%s  ret:%s\n", __FUNCTION__,strerror(errno));
		if (read_bytes <= 0) {
#ifndef CONFIG_PROJECT_YINGTAI
			usleep(500 * 1000);
			continue;
#else
			printf("[%s] read_byte is %d, errno is %s[%d]\r\n", get_current_time_string(), read_bytes, strerror(errno), errno);
			if(expected_bytes > 0 && read_retry_count++ > MAX_READ_RETRY) {
	                read_retry_count = 0;
	                if (check_process_exists("brlinkd") == 0) {
	                    if (stack_died_flag == 0) {
	                        read_bytes = sizeof(STACK_ERR_EVENT);
	                        memcpy(s_buffer + s_offset, STACK_ERR_EVENT, expected_bytes);
	                        stack_died_flag = 1;
	                    }
	                } else {
	                    usleep(100 * 1000);
	                    continue;
	                }
	            } else {
	                usleep(100 * 1000);
	                continue;
	            }
#endif
		}
#ifdef VERBOSE_LOG
		flag = 0;
		evt_cnt = 0;
		extra_str = cnt_str;

		for(i=0;i<s_offset + read_bytes;i++) {
			if (s_buffer[i] == '\r') {
				if (!flag) {
					flag = 1;
					evt_cnt++;
				}
			} else {
				flag = 0;
			}
		}
		snprintf(cnt_str, 16, " evt_num1:%4d ", evt_cnt);

		dtlen = s_offset + read_bytes;
		for(i=0;i<dtlen;i+= dlen) {
			if (i + 0xFF < dtlen) {
				dlen = 0xFF;
			} else {
				dlen = (dtlen - i);
			}

			FILL_DEBUG_EVENT(debug_rx_buf, s_buffer + i, dlen);
			brt_debug_capture(debug_rx_buf, 3 + dlen, 1);
		}
#endif

		for(i=0;i<read_bytes;i++){
			on_char(s_buffer[i]);
		}

//		vlog("[%-17s], buf[%04d + %04d]%s, evt_buf:%-50.50s\r\n", get_current_time_string(), s_offset, read_bytes, extra_str, s_buffer);
//		if (read_bytes <= 0) {
//			usleep(500 * 1000);
//			continue;
//		}

//		total_bytes = s_offset + read_bytes;
//		remain_bytes = 0;
//		remain_pos = 0;
//		s_offset = 0;

		// If the buffer is full, we should consider
		// whether the last data is a complete event.
//		if (read_bytes == expected_bytes) {
//			dump_at_event(s_buffer, total_bytes);
//			log("Buffer is full after read[%d] bytes(remain %d"
//				" bytes in buffer before read). should keep the tail part.\n", read_bytes, (total_bytes - read_bytes));
//			for (i = READ_BUFFER_SIZE - 1; i > 0; i--) {
//				if (s_buffer[i] == '\0') {
//					log("tail position: %d.\n", i);
//					remain_bytes = READ_BUFFER_SIZE - 1 - i;
//					remain_pos = i;
//					total_bytes = i + 1;
//					break;
//				}
//			}
//		}

//		if (total_bytes > 0) {
//			/*s_buffer[total_bytes] = '\0';*/
//			processed_pos = process_event(s_buffer, total_bytes);
//			// cache the bytes not be processed
//			for (i = processed_pos; i < total_bytes; i++) {
//				if (s_buffer[i] != '\0') {
//					log("incomplete event. s_buffer[%d]:%c.", i, s_buffer[i]);
//					s_buffer[s_offset++] = s_buffer[i];
//				} else {
//					break; // FIXME any more event followed?
//				}
//			}
//		}

//		if (remain_bytes > 0) {
//			memcpy(s_buffer + s_offset, s_buffer + remain_pos + 1, remain_bytes);
//			s_offset += remain_bytes;
//		}
	}

	return 0;
}

static event_parser_t * s_unknown_evt_parser = NULL;

int brt_sdk_init()
{
	return brt_sdk_init_ex(NULL);
}

static char s_socket_path[256] = {0};
int brt_sdk_init_ex(const char *path)
{
	//char socket_path[256];
#ifdef VERBOSE_LOG
	char debug_file[256];
#endif
	s_parser_list_count = 0;
	memset(s_parsers, 0, MAX_PARSER_NUMBER * sizeof(event_parser_t *));
	/* NOTE: UnkownEventParser should ALWARYS append in the end */
	s_unknown_evt_parser = create_unknown_event_parser();
	s_parsers[MAX_PARSER_NUMBER - 1] = s_unknown_evt_parser;
	memset(s_socket_path, 0, 256);
	if(path) {
		sprintf(s_socket_path, "%s", path);
	} else {
		strcpy(s_socket_path, "/data");
	}

#ifdef CONFIG_EV_LOOPER_ADD_INTERNAL
	brt_internal_event_init();
#endif
#ifdef VERBOSE_LOG
	snprintf(debug_file, 256, "%s/client_sock.log", s_socket_path);
	brt_debug_init();
	brt_debug_open(debug_file);
#endif
	return connect_to_server(s_socket_path);
}

void brt_sdk_done()
{
#ifdef VERBOSE_LOG
	brt_debug_close();
	brt_debug_cleanup();
#endif
	if (s_unknown_evt_parser != NULL) {
		s_parsers[MAX_PARSER_NUMBER - 1] = NULL;
		destroy_unknown_event_parser(s_unknown_evt_parser);
	}

	disconnect_from_server();
#ifdef CONFIG_EV_LOOPER_ADD_INTERNAL
	brt_internal_event_done();
#endif
}


#ifdef CONFIG_PROJECT_YINGTAI

#define REOPEN_BRLINKD
#define MAX_CMD_LEN 256
static char reopen_brlinkd_cmd[MAX_CMD_LEN];

void reopen_brlinkd()
{
    printf("[%s] hardware err:%s->%d\r\n", get_current_time_string(), __func__, __LINE__);
    memset(reopen_brlinkd_cmd, 0, MAX_CMD_LEN);
    printf("[%s] s_socket_path is %s\r\n", get_current_time_string(), s_socket_path);
    sprintf(reopen_brlinkd_cmd, "brlinkd config_path=/etc/brlink save_path=%s &", s_socket_path);
    printf("[%s] reopen_brlinkd_cmd is %s\r\n", get_current_time_string(), reopen_brlinkd_cmd);
    system(reopen_brlinkd_cmd);
}
 
void brt_sdk_stack_err()
{
    if (check_process_exists("brlinkd") == 0) {
        disconnect_from_server();
        printf("[%s] hardware err:%s->%d\r\n", get_current_time_string(), __func__, __LINE__);
#ifdef REOPEN_BRLINKD
        reopen_brlinkd();
#endif
        usleep(50 * 1000);//wait for brlinkd
        printf("[%s] hardware err:%s->%d\r\n", get_current_time_string(), __func__, __LINE__);
        connect_to_server(s_socket_path);
     }
}                            

#endif

