#ifndef __INTERNAL_EV_PROCESS_H__
#define __INTERNAL_EV_PROCESS_H__

#define EV_BUFFER_SIZE 64

#define INT_EV_HFP_QUERY_CUR_CALLS 0x01

typedef struct tag_ev_data {
	uint8_t type;
	uint8_t len;
	uint8_t value[EV_BUFFER_SIZE]; /* FIXME max lenth of event data */
	size_t off;
} ev_data_t;

typedef void (*internal_event_callback)(ev_data_t *ev);

void brt_internal_event_init();
void brt_internal_event_done();
void brt_internal_event_register(internal_event_callback cbk);
void brt_internal_event_unregister(internal_event_callback cbk);
int  brt_internal_event_send(uint8_t event, uint8_t data_len, void *data);

ssize_t read_all(int fd, void *buf, size_t count);

#endif /* __INTERNAL_EV_PROCESS_H__ */
