#ifndef _BRT_EVENT_PARSER_H__
#define _BRT_EVENT_PARSER_H__

typedef struct tag_parser {
	const char *(*get_keyword)();
	const char *(*get_tag)();
	int (*get_min_expected_length)();
	int (*parse)(uint8_t *buffer, int pos);
} parser_t;

typedef struct tag_event_parser {
	int event_end_pos;
	int num_of_parsers;
	parser_t *parser_list;
	int (*process_event)(struct tag_event_parser *evt_parser, uint8_t *buffer, int offset, int length);
} event_parser_t;

event_parser_t *create_event_parser();
void destroy_event_parser(event_parser_t *parser);

#endif /*_BRT_EVENT_PARSER_H__*/
