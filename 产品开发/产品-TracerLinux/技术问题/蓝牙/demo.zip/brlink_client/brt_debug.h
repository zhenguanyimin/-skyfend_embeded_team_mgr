#ifndef BRT_DEBUG_H__
#define BRT_DEBUG_H__

void brt_debug_init(void);
void brt_debug_open(char *p_path);
void brt_debug_close(void);
void brt_debug_cleanup(void);
void brt_debug_capture(unsigned char *p_buf, uint32_t len, uint8_t is_rcvd);

#endif /*BRT_DEBUG_H__*/
