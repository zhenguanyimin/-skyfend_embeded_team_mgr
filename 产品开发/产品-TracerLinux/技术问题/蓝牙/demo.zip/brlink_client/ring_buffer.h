#ifndef RING_BUFFER_H__
#define RING_BUFFER_H__

typedef struct tag_ring_buffer_base {
	int (*push)(struct tag_ring_buffer_base *obj, unsigned char *buffer, int length);
	int (*pull)(struct tag_ring_buffer_base *obj, unsigned char *buffer, int length);
	int (*avail)(struct tag_ring_buffer_base *obj);
} ring_buffer_t;

ring_buffer_t *ring_buffer_create(int buf_size, int push_block, int pull_block);
void ring_buffer_free(ring_buffer_t *obj);

#endif /*RING_BUFFER_H__*/
