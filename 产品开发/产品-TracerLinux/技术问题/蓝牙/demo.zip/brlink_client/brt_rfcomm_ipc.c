#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdbool.h>
#include "bluetooth.h"
#include "brt_event_parser.h"
#include "brt_rfcomm_ipc.h"
#include "brt_bluetooth_impl.h"
#include "brt_bluetooth_event.h"

//For HSAE, do not delete this
//#include "../../server/include/autoconf.h"

typedef enum {
	STATE_HANDLE = 0,
	STATE_CREDIT,
	STATE_LEN,
	STATE_DATA,
};

typedef struct tag_data_transport {
	volatile int 			alive;
	int 					fd;
	pthread_t 				thread;
	rfcomm_ipc_message_cbk	cbk;
} rfcomm_data_transport_t;

static rfcomm_data_transport_t s_data_transport;

static void on_data_transport_established(uint8_t id, int fd);
static void *data_transport_thread_proc(void *arg);
static void close_data_transport();
static int sock_send_all(int sock_fd, const uint8_t *buf, int len);
static int sock_recv_all(int sock_fd, uint8_t *buf, int len);

#ifdef CONFIG_RFCOMM_SEPARATE_SOCKET
#define RFCOMM_BUF_SIZE 10240
#define BT_SERVER_SOCKET_PATH "/etc/bluetooth"

static int s_rfcomm_client_fd;
static int s_rfcomm_running;
static size_t s_rfcomm_offset = 0;
static uint8_t s_rfcomm_buffer[RFCOMM_BUF_SIZE + 1];

static void *receive_rfcomm_message_proc(void *arg)
{
	int server = (int)(intptr_t) arg;
	int rc;
	int offset;
	int len;	

	if (server < 0) {
		return 0;
	}

	while (s_rfcomm_running) {
		int state = STATE_HANDLE;
		uint32_t handle;
		uint8_t	 credit = 0;
		uint16_t len = 0;
		uint16_t packet_data_len = 0;
		rfcomm_msg_header_t *msg = NULL;
		
		if (s_rfcomm_offset >= RFCOMM_BUF_SIZE) {
			/* should NOT reach here! */
			printf("%s\n", "Fatal error! RFCOMM Client send too much data,  the receive cache crashed!!!");
			break;
		}
		rc = read(server, s_rfcomm_buffer + s_rfcomm_offset, RFCOMM_BUF_SIZE - s_rfcomm_offset);
		if (rc > 0) {
			s_rfcomm_offset += rc;
			do {
				switch (state) {
					case STATE_HANDLE:
						packet_data_len = 0;
						offset =  sizeof(handle);
						if (s_rfcomm_offset >= offset) {
							memcpy(&handle, s_rfcomm_buffer, offset);
							state = STATE_CREDIT;
						} else {
							offset = 0;
						}
						break;
					case STATE_CREDIT:
						offset = sizeof(credit);
						if (s_rfcomm_offset >= offset) {
							memcpy(&credit, s_rfcomm_buffer, offset);
							state = STATE_LEN;	
						} else {
							offset = 0;
						}
						break;
					case STATE_LEN:				
						offset = sizeof(len);
						if (s_rfcomm_offset >= offset) {
							memcpy(&len, s_rfcomm_buffer, offset);
							state = STATE_LEN;	
						} else {
							offset = 0;
							break;
						}						
						if (len == 0) {
							msg = (rfcomm_msg_header_t *) malloc(sizeof(rfcomm_msg_header_t));
							if (msg != NULL) {
								memset(msg, 0, sizeof(rfcomm_msg_header_t));
								msg->handle = handle;
								msg->credit = credit;
								msg->len = len;
								state = STATE_HANDLE;
								if (s_data_transport.cbk) {
									s_data_transport.cbk(msg);
								}
								free(msg);
								msg = NULL;
							} else {
								goto error;
							}
						} else {
							state = STATE_DATA;
							packet_data_len = len;
						}						
						break;
					case STATE_DATA:
						offset = packet_data_len;
						if (s_rfcomm_offset >= offset) {
							msg = (rfcomm_msg_header_t *) malloc(sizeof(rfcomm_msg_header_t) + packet_data_len);
							if (msg != NULL) {
								memset(msg, 0, sizeof(rfcomm_msg_header_t) + packet_data_len);
								msg->handle = handle;
								msg->credit = credit;
								msg->len = packet_data_len;
								memcpy(msg->data, s_rfcomm_buffer, packet_data_len);
								if (s_data_transport.cbk) {
									s_data_transport.cbk(msg);								
								}
								state = STATE_HANDLE;
								free(msg);
								msg = NULL;
							} else {
								goto error;	
							}
						} else {
							offset = 0;
						}
						break;
				}
				if (offset > 0) {
					len = s_rfcomm_offset - offset;
					if (len > 0) {
						memmove(s_rfcomm_buffer, s_rfcomm_buffer + offset, len);
					}
					s_rfcomm_offset -= offset;
				}
			} while (offset > 0);
		} else {
			usleep(10 * 1000);
			continue;
		}
	}
error:
	printf("quit from RFCOMM client thread. client id:%d.");

	return 0;
}

#define MAX_CONN_COUNT 3
static int connect_to_rfcomm_server(const char *path)
{
	int sd;
	struct sockaddr_un addr;
	int reconn_socket = 0;
	char server_path[128];

	memset(&addr, 0, sizeof(struct sockaddr_un));
	addr.sun_family = AF_UNIX;

	if (path) {
		snprintf(server_path, 128, "%s/brt_rfcomm_socket", path);
	}
	printf("connect_to_rfcomm_server %s\n", server_path);

	strncpy(addr.sun_path, server_path, sizeof(addr.sun_path) -1);
	if (strlen(server_path) < sizeof(addr.sun_path)) {
		strncpy(addr.sun_path, server_path, sizeof(addr.sun_path) -1);
	} else {
		return -1;
	}

	sd = socket(AF_UNIX, SOCK_STREAM, 0);

	if (sd == -1) {
		printf("create rfcomm socket failed:%s.\n", strerror(errno));
		return -1;
	}
retry_conn:
	if (connect(sd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) == -1) {
		printf("connect rfcomm socket failed:%s.\n", strerror(errno));	
		 if(reconn_socket++ < MAX_CONN_COUNT) {
	            usleep(50 * 1000);
	            goto retry_conn;
	     }
		close(sd);
		return -1;
	} else {
		printf("[%s] connect rfcomm socket successed.\n", get_current_time_string());
	}

	s_rfcomm_client_fd = sd;
	s_rfcomm_running = 1;

	pthread_t thread;
	pthread_create(&thread, NULL, receive_rfcomm_message_proc, (void *)(intptr_t) sd);

	return sd;
}


static void disconnect_from_rfcomm_server()
{
	s_rfcomm_running = 0;
	close(s_rfcomm_client_fd);
	s_rfcomm_client_fd = 0;
}

static int rfcomm_client_send_data(uint8_t* data, int len)
{
	if (s_rfcomm_client_fd > 0) {
		write(s_rfcomm_client_fd, data, len);
	} else {
		printf("s_client_fd=%d \n", s_rfcomm_client_fd);
	}
}

#endif

void rfcomm_ipc_init_client(rfcomm_ipc_message_cbk cbk)
{
	printf("%s->%d:%s->%s\r\n", __func__, __LINE__, __DATE__, __TIME__);
	memset(&s_data_transport, 0, sizeof(s_data_transport));
	s_data_transport.cbk = cbk;
	s_data_transport.fd = -1;
	s_data_transport.alive = 1;
#ifndef CONFIG_RFCOMM_SEPARATE_SOCKET
	brt_bluetooth_register_data_transport_callback(IPC_ID_SPP, on_data_transport_established);
#else
	s_data_transport.fd = connect_to_rfcomm_server(BT_SERVER_SOCKET_PATH);
#endif
}

void rfcomm_ipc_done_client()
{
#ifndef CONFIG_RFCOMM_SEPARATE_SOCKET
	close_data_transport();
#else
	disconnect_from_rfcomm_server();
	s_data_transport.alive = 0;
	s_data_transport.fd = 0;
#endif
}

int rfcomm_ipc_send_data_client(uint32_t handle, uint8_t credit, void *buf, size_t size)
{
	int ret;
	int len = sizeof(rfcomm_msg_header_t) + size;
	rfcomm_msg_header_t *msg = NULL;
	if (s_data_transport.fd <= 0) {
		return -1;
	}
	msg = malloc(len);
	if (!msg) {
		return -1;
	}
	memset(msg, 0, len);
	msg->handle = handle;
	msg->credit = credit;
	msg->len = size;
	if (buf != NULL) {
		memcpy(msg->data, buf, size);
	}	
#ifndef CONFIG_RFCOMM_SEPARATE_SOCKET
	ret = sock_send_all(s_data_transport.fd, (uint8_t *) msg, len);
#else
	ret = rfcomm_client_send_data((uint8_t *) msg, len);
#endif
	free(msg);

	return ret;
}

static void on_data_transport_established(uint8_t id, int fd)
{
	printf("%s(id=%d, fd=%d)\n", __func__, id, fd);
	if(id == IPC_ID_SPP) {
		//close_data_transport();
		s_data_transport.alive = 1;
		s_data_transport.fd = fd;
		pthread_create(&s_data_transport.thread, NULL, data_transport_thread_proc, NULL);
	}
}


static void *data_transport_thread_proc(void *arg)
{
	int ret;
	int state = STATE_HANDLE;
	uint32_t handle;
	uint8_t	 credit;
	uint16_t len;
	uint16_t offset;

	rfcomm_msg_header_t *msg = NULL;

	while (s_data_transport.alive && s_data_transport.fd > 0) {
		switch (state) {
			case STATE_HANDLE:
				len = offset = 0;
				ret = sock_recv_all(s_data_transport.fd, &handle, sizeof(handle));

				if (ret != sizeof(handle)) {
					ret = -1;
					goto error;
				}
				state = STATE_CREDIT;
				break;
			case STATE_CREDIT:
				ret = sock_recv_all(s_data_transport.fd, &credit, sizeof(credit));

				if (ret != sizeof(credit)) {
					ret = -1;
					goto error;
				}
				state = STATE_LEN;
				break;
			case STATE_LEN:
				ret = sock_recv_all(s_data_transport.fd, (uint8_t *) &len, sizeof(len));
				if (ret != sizeof(len)) {
					goto error;
				}

				msg = malloc(sizeof(rfcomm_msg_header_t) + len);

				if (msg != NULL) {
					msg->handle = handle;
					msg->credit = credit;
					msg->len = len;
					if (len > 0) {
						state = STATE_DATA;
					} else {
						state = STATE_HANDLE;
						if (s_data_transport.cbk) {
							s_data_transport.cbk(msg);
							free(msg);
							msg = NULL;
						}
					}	
				} else {
					goto error;
				}

				break;
			case STATE_DATA:
				ret = sock_recv_all(s_data_transport.fd, msg->data + offset, len - offset);
				if (ret > 0) {
					offset += ret;
					if (offset >= len) {
						state = STATE_HANDLE;
						if (s_data_transport.cbk) {
							s_data_transport.cbk(msg);
							free(msg);
							msg = NULL;
						}
					}
				} else {
					goto error;
				}
				break;
		}
	}

	if (msg) {
		free(msg);
		msg = NULL;
	}
error:
	printf("Data transport is broken!!! Type:Rfcomm\n");
	return NULL;
}

static void close_data_transport()
{
	s_data_transport.alive = 0;

	if (s_data_transport.fd > 0) {
		shutdown(s_data_transport.fd, SHUT_RDWR);
		s_data_transport.fd = -1;
	}

	printf("%s fd closed.\n", __func__);
	pthread_join(s_data_transport.thread, NULL);
	printf("%s quit.\n", __func__);
}

static int sock_send_all(int sock_fd, const uint8_t *buf, int len)
{
	int s = len;
	int ret;

	while (s) {
		do {
			ret = send(sock_fd, buf, s, 0);
		} while (ret < 0 && errno == EINTR);

		if (ret <= 0) {
			return -1;
		}

		buf += ret;
		s -= ret;
	}

	return len;
}

static int sock_recv_all(int sock_fd, uint8_t *buf, int len)
{
	int r = len;
	int ret = -1;

	while (r) {
		do {
			ret = recv(sock_fd, buf, r, MSG_WAITALL);
		} while (ret < 0 && errno == EINTR);

		if (ret <= 0) {
			return -1;
		}

		buf += ret;
		r -= ret;
	}

	return len;
}

