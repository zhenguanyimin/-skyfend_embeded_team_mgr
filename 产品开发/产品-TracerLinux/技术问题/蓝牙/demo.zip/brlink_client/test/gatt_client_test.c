#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "gatt_client_test.h"
#include "gatt_client_conn_info.h"
#include "test.h"
#include "utils.h"

typedef struct tag_gatt_client_context {
	bluetooth_device_t devices[MAX_DEVICE_NUM];//defined in test.h
	int current_dev_num;
	int device_offset;
	int target_device;
} gatt_client_context_t;


static gatt_client_context_t gatt_context;
static bt_bdaddr_t m_device;

static bt_uuid_t s_uuid = {0x00, 0x00, 0x12, 0x34, 0x45, 0x56, 0x78, 0x00,
                           0x10, 0x11, 0x20, 0x21, 0x30, 0x31, 0x40, 0x41
                          };
static bt_uuid_t null_uuid = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
                             };

typedef struct tag_bluetooth_gatt_t {
	int is_connected;
	uint8_t client_if;
	uint16_t conn_id;
} bluetooth_gatt_client;

static bluetooth_gatt_client m_gatt_client = {0, -1, -1};

static void add_device_to_list(bt_bdaddr_t addr, char *name);
static void show_device_list();
static void select_one_device();
static int choose_gatt_device();
static int choose_a_specific_service();
enum uint8_t {
	SEARCH_SRVC_OVER,
	SEARCH_CHARA,
	SEARCH_DESC,
};
static uint8_t s_count_srvc;
static uint8_t s_count_chara;
static void continue_search(uint16_t conn_id, uint8_t type);

static void gatt_client_connect()
{
	// to connect gatt server
	if (choose_gatt_device() > 0) {
		brt_gatt_client_connect(gatt_context.devices[gatt_context.target_device].address, 0, 0);
	}
}

static void scan_result_cbk(bt_bdaddr_t address, uint8_t rssi, uint16_t adv_dataLen, uint8_t * adv_data)
{
	//TODO
}

static void scan_address_name_cbk(bt_bdaddr_t address, uint16_t nameLen, uint8_t * name)
{
	uint8_t * r_name = (uint8_t *)malloc(nameLen + 1);
	memset(r_name, 0, nameLen + 1);
	memcpy(r_name, name, nameLen);
	printf("---> GATT_Client : %s, address: {%02x:%02x:%02x:%02x:%02x:%02x}, nameLen: %d, name: %s\n",
	       __func__, address.address[0], address.address[1], address.address[2], address.address[3], address.address[4],
	       address.address[5], nameLen, r_name);

	//save device
	int i;
	int found = 0;
	if (nameLen <= 0) {
		name = "UnKnown";
	}

	for (i = 0; i < gatt_context.current_dev_num; i++) {
		if (memcmp(&address.address, &gatt_context.devices[i].address, 6) == 0) {
			found = 1;
			return;
		}
	}

	if (!found) {
		add_device_to_list(address, r_name);
	}

	if (r_name) {
		free(r_name);
	}
}

static void notify_cbk(uint16_t conn_id, bt_bdaddr_t address, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint8_t isNotify, uint16_t dataLen, uint8_t * data)
{
	printf("on_notify_callback : isNotify: %d, data: %s\n", isNotify, data);
}

static void connected_cbk(uint8_t client_if, uint16_t conn_id, uint8_t status, bt_bdaddr_t address)
{
	printf("---> GATT_Client : %s, client_if: %d, conn_id: %d, status: %d\n", __func__, client_if, conn_id, status);

	if (status != 0) {
		printf("\tStatus : %d ERROR!! \n", status);
		return;
	}

	m_gatt_client.is_connected = 1;
	m_gatt_client.client_if = client_if;
	m_gatt_client.conn_id = conn_id;
	memcpy(&m_device, &address, sizeof(m_device));

	conn_info_init(client_if, conn_id);
}

static void disconnected_cbk(uint8_t client_if, uint16_t conn_id, uint8_t status, bt_bdaddr_t address)
{
	printf("---> GATT_Client : %s, client_if: %d, conn_id: %d, status: %d\n ", __func__, client_if, conn_id, status);

	if (status != 0) {
		printf("\t Status : %d ERROR!! \n", status);
		return;
	}

	m_gatt_client.is_connected = 0;
	m_gatt_client.client_if = -1;
	m_gatt_client.conn_id = -1;
	memset(&m_device, 0, sizeof(m_device));

	conn_info_destroy();
}

static void search_completed_cbk(uint16_t conn_id, uint8_t status)
{
	printf("---> GATT_Client -- on_search_complete, conn_id: %d, status: %d \n", conn_id, status);

	conn_info_t *conn_info = get_conn_info(conn_id);

	int i = 0;
	for (i; i < conn_info->srvc_num; i++) {
		printfUuid("srvcUUID", conn_info->gatt_srvc_array[i].srvcUuid);
	}

	continue_search(conn_id, SEARCH_SRVC_OVER);


}

static void search_result_cbk(uint16_t conn_id, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid)
{
	printf("\n---> GATT_Client -- on_search_result, conn_id: %d, srvcType: %d\n", conn_id, srvcType);
	printfUuid("srvcUUID", srvcUuid);

	conn_info_add_service(srvcType, srvcInstId, srvcUuid);
}

static void get_characteristic_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint8_t charProp)
{
	printf("on_get_characteristic : status: %d, svrcInstId: %d, charInstId: %d, charProp: %d \n", status, srvcInstId, charInstId, charProp);
	printfUuid("srvcUUID", srvcUuid);
	printfUuid("\tcharaUUID", charUuid);

	//get other chara
	if (status == 0) {
		conn_info_add_characteristic(srvcType, srvcInstId, srvcUuid, charInstId, charUuid, charProp);
		brt_gatt_client_get_characteristic(conn_id, srvcType, srvcInstId, srvcUuid, charInstId, charUuid);
	} else if (status == 1) {
		printf("search chara complete\n");
		GATT_Service_t *gatt_srvc = get_gatt_srvc_by_instId(srvcInstId);
		int i = 0;
		for (i; i < gatt_srvc->chara_num; i++) {
			printfUuid("charaUUId", gatt_srvc->gatt_chara_array[i].charUuid);
		}
		continue_search(conn_id, SEARCH_CHARA);
	}
}

static void get_descriptor_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint16_t descrInstId, bt_uuid_t descrUuid)
{
	printf("on_get_descriptor: status: %d, srvcInstId: %d, charInstId: %d, descrInstId: %d\n", status, srvcInstId, charInstId, descrInstId);
	printfUuid("SrvcUUID", srvcUuid);
	printfUuid("\tcharaUUID", charUuid);
	printfUuid("\t\tdescUUID", descrUuid);
	//get other desc
	if (status == 0) {
		conn_info_add_descriptor(srvcType, srvcInstId, srvcUuid, charInstId, charUuid, descrInstId, descrUuid);
		brt_gatt_client_get_descriptor(conn_id, srvcType, srvcInstId, srvcUuid, charInstId, charUuid, descrInstId, descrUuid);
	} else {
		printf("search desc complete\n");
		GATT_Service_t *gatt_srvc = get_gatt_srvc_by_instId(srvcInstId);
		GATT_Chara_t *gatt_chara = get_gatt_chara_by_instId(gatt_srvc, charInstId);

		int i = 0;
		for (i; i < gatt_chara->desc_num; i++) {
			printfUuid("DescUUID", gatt_chara->gatt_desc_array[i].descrUuid);
		}
		continue_search(conn_id, SEARCH_DESC);
	}
}

static void get_included_service_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint8_t inclSrvcType, uint16_t inclSrvcInstId, bt_uuid_t inclSrvcUuid)
{
}

static void register_for_notifications_cbk(uint16_t conn_id, uint8_t status, uint8_t registered, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid)
{
	printf("register_for_notification_callback : status: %d", status);
}

static void read_characteristic_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint8_t charType, uint16_t dataLen, uint8_t * data)
{
	uint8_t * read = (uint8_t *)malloc(dataLen + 1);
	memset(read, 0, dataLen + 1);
	memcpy(read, data, dataLen);
	printf("on_read_charateristic_callback. status : %d, dataLen: %d, data: %s, read: %s \n", status, dataLen, data, read);
	if (read) {
		free(read);
	}
}

static void write_characteristic_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid)
{
	printf("on_write_charateristic_callback  ****  status: %d !!!\n", status);
}

static void execute_completed_cbk(uint16_t conn_id, uint8_t status)
{
}

static void read_descriptor_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint16_t descrInstId, bt_uuid_t descrUuid, uint8_t charType, uint16_t dataLen, uint8_t * data)
{
	uint8_t * read = (uint8_t *)malloc(dataLen + 1);
	memset(read, 0, dataLen + 1);
	memcpy(read, data, dataLen);
	printf("on_read_descriptor_callback. status : %d, dataLen: %d, data: %s, read: %s \n", status, dataLen, data, read);
	if (read) {
		free(read);
	}
}

static void write_descriptor_cbk(uint16_t conn_id, uint8_t status, uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint16_t descrInstId, bt_uuid_t descrUuid)
{
	printf("on_descriptor_written_callback **** status: %d !!!\n", status);
}

static void read_remote_rssi_cbk(uint8_t client_if, bt_bdaddr_t address, uint8_t rssi, uint8_t status)
{
}

static void receive_data_from_central_cbk(uint16_t conn_id, bt_bdaddr_t address, uint16_t dataLen, uint8_t * data)
{
}

static void configure_mtu_cbk(int conn_id, uint8_t status, int mtu)
{
}

static void advertise_callback_cbk(uint8_t status, uint8_t client_if)
{
}

static void scan_filter_config_cbk(int action, uint8_t client_if, uint8_t status, int filt_type, int avbl_space)
{
}

static void scan_filter_params_configured_cbk(int action, uint8_t client_if, uint8_t status, int avbl_space)
{
}

static void scan_filter_enable_disabled_cbk(int action, uint8_t client_if, uint8_t status)
{
}

static void advertise_instance_enabled_cbk(uint8_t client_if, uint8_t status)
{
}

static void advertise_data_updated_cbk(uint8_t client_if, uint8_t status)
{
}

static void advertise_data_set_cbk(uint8_t client_if, uint8_t status)
{
}

static void advertise_instance_disabled_cbk(uint8_t client_if, uint8_t status)
{
}

static void client_congestion_cbk(int conn_id, uint8_t congested)
{
}

static void batch_scan_storage_configured_cbk(uint8_t client_if, uint8_t status)
{
}

static void batch_scan_start_stopped_cbk(int startstop_action, uint8_t client_if, uint8_t status)
{
}

static void batch_scan_reports_cbk(uint8_t client_if, uint8_t status, int report_format, int num_records, uint16_t rep_dataLen, uint8_t * rep_data)
{
}

static void batch_scan_threshold_crossed_cbk(uint8_t client_if)
{
}

static gatt_client_callback_t s_gatt_cbks = {
	scan_result_cbk,
	scan_address_name_cbk,
	notify_cbk,
	connected_cbk,
	disconnected_cbk,
	search_completed_cbk,
	search_result_cbk,
	get_characteristic_cbk,
	get_descriptor_cbk,
	get_included_service_cbk,
	register_for_notifications_cbk,
	read_characteristic_cbk,
	write_characteristic_cbk,
	execute_completed_cbk,
	read_descriptor_cbk,
	write_descriptor_cbk,
	read_remote_rssi_cbk,
	receive_data_from_central_cbk,
	configure_mtu_cbk,
	advertise_callback_cbk,
	scan_filter_config_cbk,
	scan_filter_params_configured_cbk,
	scan_filter_enable_disabled_cbk,
	advertise_instance_enabled_cbk,
	advertise_data_updated_cbk,
	advertise_data_set_cbk,
	advertise_instance_disabled_cbk,
	client_congestion_cbk,
	batch_scan_storage_configured_cbk,
	batch_scan_start_stopped_cbk,
	batch_scan_reports_cbk,
	batch_scan_threshold_crossed_cbk,
};

gatt_client_callback_t * hlp_gatt_client_get_cbks()
{
	return &s_gatt_cbks;
}

static void add_device_to_list(bt_bdaddr_t addr, char *name)
{
	memcpy(&gatt_context.devices[gatt_context.device_offset].address, &addr, sizeof(addr));
	if (name && name[0]) {
		strcpy(gatt_context.devices[gatt_context.device_offset].name.name, name);
	}
	gatt_context.devices[gatt_context.device_offset].idex = gatt_context.device_offset;
	gatt_context.device_offset++;
	gatt_context.current_dev_num = gatt_context.device_offset > gatt_context.current_dev_num ? gatt_context.device_offset : gatt_context.current_dev_num;
	gatt_context.device_offset %= MAX_DEVICE_NUM;
}

static void show_device_list()
{
	int i;
	uint8_t *addr;
	printf("\nDevice List:\n");
	for (i = 0; i < gatt_context.current_dev_num; i++) {
		addr = gatt_context.devices[i].address.address;
		printf("\t[%02d] <%02X:%02X:%02X:%02X:%02X:%02X>:%s.\n", gatt_context.devices[i].idex,
		       addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], gatt_context.devices[i].name.name);
	}
	printf("\t[%02d] <go back>.\n",i);
}

static void select_one_device()
{
	int enter = 0;
	printf("Please choose a device: \n");
	scanf("%d", &gatt_context.target_device);
	scanf("%c", &enter);
}

static int choose_gatt_device()
{
	if (gatt_context.current_dev_num == 0) {
		printf("There is not any saved devices. Please choose <3> command to discover firstly.\n");
		return 0;
	} else {
		show_device_list();
		select_one_device();
		if (gatt_context.target_device == gatt_context.current_dev_num) {
			printf("exit choose gatt device !\n");
			return 0;
		}
		if (gatt_context.target_device >= gatt_context.current_dev_num) {
			printf("There is an out of range value.\n");
			choose_gatt_device();
		}
		return 1;
	}
}

static int choose_a_specific_service()
{
	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	if (conn_info) {
		int i = 0;
		for (i; i < conn_info->srvc_num; i++) {
			printf("%d -->", i);
			printfUuid("srvcUUID", conn_info->gatt_srvc_array[i].srvcUuid);
		}

		printf("choose a speciifc service\n");
		printf(">");
	}

	char buffer[10];
	fgets(buffer, 10, stdin);
	return atoi(buffer);

}

typedef struct tag_srvc_chara {
	int srvc_index;
	int chara_index;
} srvc_chara_t;

static srvc_chara_t choose_a_specific_chara()
{
	int srvc_index = choose_a_specific_service();
	int chara_index = -1;

	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	if (conn_info) {
		GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[srvc_index];
		int i = 0;
		for (i; i < gatt_srvc.chara_num; i++) {
			printf("%d -->", i);
			printfUuid("charaUUId", gatt_srvc.gatt_chara_array[i].charUuid);
		}

		printf("choose a specific characteristic\n");
		printf(">");
		char buffer[10];
		fgets(buffer, 10, stdin);
		chara_index = atoi(buffer);
	}

	srvc_chara_t srvc_chara = {srvc_index, chara_index};
	return srvc_chara;
}

typedef struct tag_srvc_chara_desc {
	int srvc_index;
	int chara_index;
	int desc_index;
} srvc_chara_desc_t;

static srvc_chara_desc_t choose_a_specific_desc()
{
	srvc_chara_t srvc_chara = choose_a_specific_chara();
	int desc_index = -1;
	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	if(conn_info) {
		GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[srvc_chara.srvc_index];
		GATT_Chara_t gatt_chara = gatt_srvc.gatt_chara_array[srvc_chara.chara_index];
		int i = 0;
		for (i; i < gatt_chara.desc_num; i++) {
			printf("%d -->", i);
			printfUuid("descUUId", gatt_chara.gatt_desc_array[i].descrUuid);
		}

		printf("choose a specific description\n");
		printf(">");
		char buffer[10];
		fgets(buffer, 10, stdin);
		desc_index = atoi(buffer);
	}
	srvc_chara_desc_t srvc_chara_desc = {srvc_chara.srvc_index, srvc_chara.chara_index, desc_index};
	return srvc_chara_desc;
	
}

static void read_or_write_chara()
{
	srvc_chara_t choose = choose_a_specific_chara();
	if (choose.chara_index < 0) return;
	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[choose.srvc_index];
	GATT_Chara_t gatt_chara = gatt_srvc.gatt_chara_array[choose.chara_index];

	printf("Read or Write ? \n");
	printf("1.	Read.\n");
	printf("2.	Write.\n");
	printf("> \n");

	char buffer[10];
	fgets(buffer, 10, stdin);
	switch (atoi(buffer)) {
		case 1:
			brt_gatt_client_read_characteristic(conn_info->conn_id, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, 0/*FIXME auth_req*/);
			break;
		case 2:
			brt_gatt_client_write_characteristic(conn_info->conn_id, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, 2/*FIXME write type*/, 0/*auth_req*/, 5, "qwert");
			break;
	}
}

static void read_or_write_desc()
{
	//TODO
	srvc_chara_desc_t choose = choose_a_specific_desc();
	if (choose.desc_index < 0) return;
	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[choose.srvc_index];
	GATT_Chara_t gatt_chara = gatt_srvc.gatt_chara_array[choose.chara_index];
	GATT_Desc_t gatt_desc = gatt_chara.gatt_desc_array[choose.desc_index];

	printf("Read or Write ? \n");
	printf("1.	Read.\n");
	printf("2.	Write.\n");
	printf("> \n");

	char buffer[10];
	fgets(buffer, 10, stdin);
	switch (atoi(buffer)) {
		case 1:
			brt_gatt_client_read_descriptor(conn_info->conn_id, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, gatt_desc.descrInstId, gatt_desc.descrUuid, 0/*FIXME auth_req*/);
			break;
		case 2:
			brt_gatt_client_write_descriptor(conn_info->conn_id, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, gatt_desc.descrInstId, gatt_desc.descrUuid, 2/*FIXME write type*/, 0/*FIXME auth_req*/, 5,"qwert");
			break;
	
	}
}

static void register_for_notification(uint8_t enable)
{
	srvc_chara_t choose = choose_a_specific_chara();
	if (choose.chara_index < 0) return;
	conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
	GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[choose.srvc_index];
	GATT_Chara_t gatt_chara = gatt_srvc.gatt_chara_array[choose.chara_index];

	brt_gatt_client_register_for_notifications(conn_info->client_if, m_device, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, enable);
}

//wlz
static void continue_search(uint16_t conn_id, uint8_t type) 
{
	conn_info_t *conn_info = get_conn_info(conn_id);
	printf("=== type : %d, s_count_srvc : %d, s_count_chara : %d \n", type, s_count_srvc, s_count_chara);
	switch (type) {
		case SEARCH_SRVC_OVER:
			s_count_srvc = 0;
			GATT_Service_t *gatt_srvc_array = conn_info->gatt_srvc_array;
			brt_gatt_client_get_characteristic(conn_info->conn_id, gatt_srvc_array[s_count_srvc].srvcType, gatt_srvc_array[s_count_srvc].srvcInstId, gatt_srvc_array[s_count_srvc].srvcUuid, 0, null_uuid);	
			printf("=== s_count_srvc = %d ,conn_info->srvc_num = %d\n", s_count_srvc, conn_info->srvc_num);
			s_count_srvc++;
			break;
		case SEARCH_CHARA:
			if (s_count_srvc < conn_info->srvc_num) {
				GATT_Service_t *gatt_srvc_array = conn_info->gatt_srvc_array;
				brt_gatt_client_get_characteristic(conn_info->conn_id, gatt_srvc_array[s_count_srvc].srvcType, gatt_srvc_array[s_count_srvc].srvcInstId, gatt_srvc_array[s_count_srvc].srvcUuid, 0, null_uuid);	
				printf("=== s_count_srvc = %d \n", s_count_srvc);
				s_count_srvc++;
			}
			else if (s_count_srvc == conn_info->srvc_num) {
				s_count_srvc = 0;
				printf("=== search all character !!\n");
				printf("=== begin search desc !! \n");
				s_count_chara = 0;
				continue_search(conn_id, SEARCH_DESC);
			}
			break;
		case SEARCH_DESC:
			if (s_count_srvc < conn_info->srvc_num) {
				GATT_Service_t *gatt_srvc = conn_info->gatt_srvc_array+s_count_srvc;
				GATT_Chara_t *gatt_chara_array = gatt_srvc->gatt_chara_array;
				if (s_count_chara < gatt_srvc->chara_num) {
					brt_gatt_client_get_descriptor(conn_info->conn_id, gatt_srvc->srvcType, gatt_srvc->srvcInstId, gatt_srvc->srvcUuid, gatt_chara_array[s_count_chara].charInstId, gatt_chara_array[s_count_chara].charUuid, 0, null_uuid);
					s_count_chara++;
				}
				if (s_count_chara == gatt_srvc->chara_num) {
					s_count_srvc++;
					s_count_chara = 0;
					printf("=== search all desc for specific chara!! \n");
				}
			}
			else {
				printf("=== search all desc !! \n");
			}
			break;
	}	
}

enum {
	GATT_CLIENT_BACK,
	GATT_CLIENT_SCAN,
	GATT_CLIENT_STOP_SCAN,
	GATT_CLIENT_CONNECT,
	GATT_CLIENT_DISCON,
	GATT_CLIENT_SEARCH,
	GATT_CLIENT_R_W_CHARA,
	GATT_CLIENT_R_W_DESC,
	GATT_CLIENT_REG_NOTIFY,
};

int enter_gatt_client_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("%d.	Go to uplater menu.\n", GATT_CLIENT_BACK);
	printf("%d.	Scan Deivces.\n", GATT_CLIENT_SCAN);
	printf("%d.	Stop device scan.\n", GATT_CLIENT_STOP_SCAN);
	printf("%d.	Connect Device.\n", GATT_CLIENT_CONNECT);
	printf("%d.	Disconnect Device.\n", GATT_CLIENT_DISCON);
	printf("%d.	Search services.\n", GATT_CLIENT_SEARCH);
	printf("%d.	Read/Write Charateristic.\n", GATT_CLIENT_R_W_CHARA);
	printf("%d.	Read/Write Descriptor.\n", GATT_CLIENT_R_W_DESC);
	printf("%d.	Register for notification.\n", GATT_CLIENT_REG_NOTIFY);

	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);

	return cmd;
}

int execute_gatt_client_command(int cmd)
{
	switch (cmd) {
		case GATT_CLIENT_SCAN:/*start LE scan*/
			//TODO set a timer for 10s
			memset(&gatt_context, 0, sizeof(gatt_context));//clean gatt_context before scan
			brt_gatt_client_scan(1);
			break;
		case GATT_CLIENT_STOP_SCAN:/*stop LE scan*/
			brt_gatt_client_scan(0);
			break;
		case GATT_CLIENT_CONNECT:/*connect LE*/
			gatt_client_connect();
			break;
		case GATT_CLIENT_DISCON:/*disconnect LE*/
			brt_gatt_client_disconnect(m_gatt_client.client_if, m_device, m_gatt_client.conn_id);
			break;
		case GATT_CLIENT_SEARCH:/*search services*/
			brt_gatt_client_search_service(m_gatt_client.conn_id, 1/*search all*/, 0);
			break;
#if 0
		case 6: 
			{ /*get chara*/
				int choose = choose_a_specific_service();
				if (choose < 0) break;
				conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
				if (conn_info) {
					GATT_Service_t *gatt_srvc_array = conn_info->gatt_srvc_array;
					brt_gatt_client_get_characteristic(conn_info->conn_id, gatt_srvc_array[choose].srvcType, gatt_srvc_array[choose].srvcInstId, gatt_srvc_array[choose].srvcUuid, 0, null_uuid);
				}
			}
			break;
		case 7: 
			{ /*get desc*/
				srvc_chara_t choose = choose_a_specific_chara();
				if (choose.chara_index < 0) break;
				conn_info_t *conn_info = get_conn_info(m_gatt_client.conn_id);
				if (conn_info) {
					GATT_Service_t gatt_srvc = conn_info->gatt_srvc_array[choose.srvc_index];
					GATT_Chara_t gatt_chara = gatt_srvc.gatt_chara_array[choose.chara_index];
					brt_gatt_client_get_descriptor(conn_info->conn_id, gatt_srvc.srvcType, gatt_srvc.srvcInstId, gatt_srvc.srvcUuid, gatt_chara.charInstId, gatt_chara.charUuid, 0, null_uuid);
				}
			}
			break;
		case 8:/*get include srvc  FIXME*/
			break;
#endif
		case GATT_CLIENT_R_W_CHARA:/*read or write chara*/
			read_or_write_chara();
			break;
		case GATT_CLIENT_R_W_DESC:/*read or write desc*/
			read_or_write_desc();
			break;
		case GATT_CLIENT_REG_NOTIFY:/*register for notification*/
			register_for_notification(1);
			break;
		case GATT_CLIENT_BACK:
			return BACK;
	}
	return GATT_CLIENT_MENU;
}

