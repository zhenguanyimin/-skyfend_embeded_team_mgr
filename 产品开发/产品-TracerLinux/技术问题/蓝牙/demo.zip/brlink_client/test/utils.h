//#include <stdio.h>
//#include <string.h>
#include "bluetooth.h"
char * convert_call_state_to_string(uint8_t state);
unsigned char parse_char_with_base(char *p, int base);
void printfUuid(unsigned char *tag, bt_uuid_t uuid);
void convert_uuid_order(char *out, char *in, int len);
void printfServerInfo(void * server_info);
void quit_client();
