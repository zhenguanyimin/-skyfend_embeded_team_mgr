#include "brt_gatt_client.h"

int enter_gatt_client_command_line();
int execute_gatt_client_command(int cmd);
gatt_client_callback_t * hlp_gatt_client_get_cbks();
