#include "brt_a2dp.h"
#include "brt_avrcp.h"

int enter_a2dp_avrcp_command_line();
int execute_a2dp_avrcp_command(int cmd);

a2dp_callback_t * hlp_a2dp_get_cbks();
avrcp_callback_t * hlp_avrcp_get_cbks();
