#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "test.h"
#include "pbap_test.h"

static bt_bdaddr_t m_device;
static int is_pbap_connected = 0;

static void connection_status_cbk(uint8_t status, bt_bdaddr_t address)
{
	printf("\n -----> PBAP %s , status:%d \n", __func__, status);
	if (status == PBAP_STATE_CONNECTED) {
		is_pbap_connected = 1;
		memcpy(&m_device, &address, sizeof(bt_bdaddr_t));
	} else if (status == PBAP_STATE_CONNECT_FAILED || status == PBAP_STATE_DISCONNECTED) {
		is_pbap_connected = 0;
		memset(&m_device, 0, sizeof(bt_bdaddr_t));
	}
}

static void get_phonebook_status_cbk(uint16_t result)
{
	printf("\n -----> PBAP %s , result:%d \n", __func__, result);
}

static void get_phonebook_size_cbk(uint16_t type, uint16_t size, uint16_t result)
{
	printf("\n -----> PBAP %s , type:%d, size:%d, result:%d \n", __func__, type, size, result);
}

static void index_data_ind_cbk(phone_book_t phone_book)
{
#ifdef SPLIT_NAME
	printf("\n -----> Pbap %s, target: %d, index: %d, lastName:%s, firstName:%s, middleName:%s, tel_type: %d, number: %s, time: %s", __func__, phone_book.target, phone_book.index, phone_book.lastName, phone_book.firstName, phone_book.middleName, phone_book.tel_type, phone_book.number, phone_book.time);
#else
	printf("\n -----> PBAP %s , target: %d, index: %d, name: %s, tel_type: %d, number: %s, time: %s",
	       __func__, phone_book.target, phone_book.index, phone_book.name,  phone_book.tel_type, phone_book.number, phone_book.time);
#endif
}

#ifdef PBAP_SEPARATE_DATA_FLAG
static void index_phonebook_ind_cbk(phone_book_ex_t phone_ex_book)
{
	int i = 0;	
#ifdef SPLIT_NAME
	printf("\n -----> PBAP %s ,target: %d,index: %d,lastName:%s,firstName:%s,middleName:%s, num_list_size: %d\r\n",
			__func__, phone_ex_book.target, phone_ex_book.index, phone_ex_book.lastName, phone_ex_book.firstName, phone_ex_book.middleName, phone_ex_book.num_list_size);
#else
	printf("\n -----> PBAP %s , target: %d, index: %d, name: %s, num_list_size: %d\r\n",
	       __func__, phone_ex_book.target, phone_ex_book.index, phone_ex_book.name,  phone_ex_book.num_list_size);
#endif
	for (i = 0; i < phone_ex_book.num_list_size; i++) {		
		printf("\n num_index=%d, tel_type=%d, tel_num=%s\r\n", i,  phone_ex_book.number_list[i].tel_type,  phone_ex_book.number_list[i].number);
	}
	
}

static void index_callhistory_ind_cbk(phone_book_t phone_book)
{
#ifdef SPLIT_NAME
	printf("\n -----> Pbap %s, target: %d, index: %d, lastName:%s, firstName:%s, middleName:%s, tel_type: %d, number: %s, time: %s", __func__, phone_book.target, phone_book.index, phone_book.lastName, phone_book.firstName, phone_book.middleName, phone_book.tel_type, phone_book.number, phone_book.time);
#else
	printf("\n -----> PBAP %s , target: %d, index: %d, name: %s, tel_type: %d, number: %s, time: %s",
	       __func__, phone_book.target, phone_book.index, phone_book.name,  phone_book.tel_type, phone_book.number, phone_book.time);
#endif
}
#endif

static char s_photo_name[256];
static unsigned char new_photo = 1;
static FILE *fp = NULL;

static void photodata_ind_cbk(uint8_t completed, uint16_t index, uint16_t data_len, uint8_t * data)
{
	if (new_photo) {
		snprintf(s_photo_name, 255, "/tmp/%d.jpeg", index);
		printf("create new file:%s.\n", s_photo_name);
		fp = fopen(s_photo_name, "w+");

		if (fp == NULL) {
			printf("File open failed:%s.\n", strerror(errno));
		}
	}

	if (fp != NULL) {
		fwrite(data, 1, data_len, fp);
	}

	new_photo = 0;

	if (completed) {
		new_photo = 1;
		if (fp) {
			fclose(fp);
		}
		fp = NULL;
	}

	printf("\n -----> PBAP %s , completed:%d, index:%d,  data_len:%d -- photo  \n", __func__, completed, index, data_len);
	
}

pbap_callback_t s_pbap_cbks = {
	connection_status_cbk,
	get_phonebook_status_cbk,
	get_phonebook_size_cbk,
#ifdef PBAP_SEPARATE_DATA_FLAG
	index_phonebook_ind_cbk,
	index_callhistory_ind_cbk,
#else
	index_data_ind_cbk,
#endif //PBAP_SEPARATE_DATA_FLAG
	photodata_ind_cbk,
};

pbap_callback_t * hlp_pbap_get_cbks()
{
	return &s_pbap_cbks;
}

static sync_type_t choose_sync_type()
{
	char buffer[16];

	printf("\n");
	printf("1.	SYNC_SIM_CONTACT. \n");
	printf("2.	SYNC_PHONE_CONTACT. \n");
	printf("3.	SYNC_CALLLOG. \n");
	printf("\n");
	printf("Please choose a type\n");
	printf(">");
	fgets(buffer, 16, stdin);

	int hit = atoi(buffer);

	switch (hit) {
		case 1:
			return SYNC_SIM_CONTACT;
		case 2:
			return SYNC_PHONE_CONTACT;
		case 3:
			return SYNC_CALLLOG;
	}

	printf("Error choose, return Default Type SYNC_PHONE_CONTACT");
	return SYNC_PHONE_CONTACT;

}

enum {
	PBAP_BACK,
	PBAP_CONNECT,
	PBAP_DISCON,
	PBAP_SYNC_PB,
	PBAP_SYNC_PB_SIZE,
	PBAP_CANCEL_SYNC,
	PBAP_SET_SYNC_MASK,
};

int enter_pbap_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("%d.	Go to uplater menu.\n", PBAP_BACK);
	printf("%d.	Connect PBAP.\n", PBAP_CONNECT);
	printf("%d.	Disconnect PBAP.\n", PBAP_DISCON);
	printf("%d.	Sync PhoneBooks.\n", PBAP_SYNC_PB);
	printf("%d.	Sync PhoneBookSize.\n", PBAP_SYNC_PB_SIZE);
	printf("%d.	Cancel Sync.\n", PBAP_CANCEL_SYNC);
	printf("%d.	Set extension ferture(photo...).\n", PBAP_SET_SYNC_MASK);
	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);

	return cmd;

}

static int choose_offset()
{
	char buffer[16];
	printf("Please determine the start position of pbap sync\n>");
	fgets(buffer, 16, stdin);

	return atoi(buffer);
}

static int choose_max_count()
{
	char buffer[16];
	printf("Please determine the size of phonebooks that you want to sync\n>");
	fgets(buffer, 16, stdin);

	return atoi(buffer);
}

int execute_pbap_command(int cmd)
{
	switch (cmd) {
		case PBAP_CONNECT:
			if (choose_device() > 0) {
				brt_pbap_connect(context.devices[context.target_device].address);
			}
			break;
		case PBAP_DISCON:
			if (is_pbap_connected) {
				brt_pbap_disconnect(m_device);
			}
			break;
		case PBAP_SYNC_PB:
			if (is_pbap_connected) {
				sync_type_t type = choose_sync_type();
				int offset = choose_offset();
				int maxcount = choose_max_count();
				printf("brt_pbap_get_phonebook(%d, %d, %d)\n", type, offset, maxcount);
				brt_pbap_get_phonebook(type, offset, maxcount);
			}
			break;
		case PBAP_SYNC_PB_SIZE:
			if (is_pbap_connected) {
				sync_type_t type = choose_sync_type();
				printf("get_phonebooksize\n");
				brt_pbap_get_phonebook_size(type);
			}
			break;
		case PBAP_CANCEL_SYNC:
			if (is_pbap_connected) {
				brt_pbap_cancel_get_phonebook();
			}
			break;
		case PBAP_SET_SYNC_MASK:
			if(is_pbap_connected) {
				brt_pbap_filter_mask(PBAP_INFO_MASK_PHOTO);
			}
			break;
		case PBAP_BACK:
			return BACK;
		case ENTER:
		default:
			printf("\t NOT DEFINED COMMAND!!\n");
			break;
	}
	return PBAP_MENU;
}

