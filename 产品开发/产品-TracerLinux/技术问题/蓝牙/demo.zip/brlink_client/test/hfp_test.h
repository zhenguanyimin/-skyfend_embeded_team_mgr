#ifndef _HFP_TEST_
#define _HFP_TEST_

#include "brt_hfp.h"
#include "bluetooth.h"

enum {
	HF_BACK,
	HF_CONNECT,
	HF_DISCONNECT,
	HF_DIAL,
	HF_TERMINATE,
	HF_ACCEPTCALL,
	HF_REGECTCALL,
	HF_HOLD,
	HF_RELEASE,
	HF_TERMINATE_WITH_INDEX,
	HF_SWITCH_AUDIO,
	HF_SEND_DTMF,
};

int enter_hfp_command_line();
int execute_hfp_command(int cmd);
hfp_callback_t * hlp_hfp_get_cbks();

#endif  /*_HFP_TEST_*/
