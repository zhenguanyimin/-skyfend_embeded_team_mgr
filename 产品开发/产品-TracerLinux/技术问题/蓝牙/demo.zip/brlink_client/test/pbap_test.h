#include "brt_pbap.h"

int enter_pbap_command_line();
int execute_pbap_command(int cmd);
pbap_callback_t * hlp_pbap_get_cbks();
