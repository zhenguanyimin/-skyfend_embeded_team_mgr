#include <stdio.h>
#include <string.h>
#include "hfp_test.h"
#include "test.h"
#include "brt_audio_stream.h"
/*hfp start*/

static bt_bdaddr_t m_device;
static int is_hfp_connected = 0;
static void connection_state_cbk(uint8_t state, int peer_feat, int chld_feat, bt_bdaddr_t address)
{
	printf("\n -----> HFP connection_state_callback state: --> %d\n",  state);
	if (state == HFP_SLC_CONNECTED) {
		memcpy(&m_device, &address, sizeof(bt_bdaddr_t));
		is_hfp_connected = 1;
	} else if (state == HFP_DISCONNECTED) {
		memset(&m_device, 0, sizeof(bt_bdaddr_t));
		is_hfp_connected = 0;
	}
}
static void audio_state_cbk(uint8_t state, bt_bdaddr_t address)
{
	printf("\n -----> HFP audio_state_cbk, state: %d\n", state);
	if(state == STATE_AUDIO_CONNECTED) {
		audio_stream_open(AUDIO_STREAM_TYPE_SCO, 8000, 1, 16);
	} else if (state == STATE_AUDIO_CONNECTED_MSBC){
		//TODO
	} else if (STATE_AUDIO_DISCONNECTED) {
		audio_stream_close();
	}
}
static void vr_cmd_cbk(uint8_t state)
{
	printf("\n -----> HFP Voice Recognition, state: %d\n", state);
}

static void network_state_cbk(uint8_t state)
{
	printf("\n -----> HFP network_state_cbk，state: %d\n", state);
}

static void network_roaming_cbk(uint8_t state)
{
	printf("\n -----> HFP network_roaming_cbk, state: %d\n", state);
}

static void network_signal_cbk(uint16_t signal)
{
	printf("\n -----> HFP network_signal_cbk, signal: %d\n", signal);
}

static void battery_level_cbk(uint16_t battery_level)
{
	printf("\n -----> HFP battery_level_cbk signal: battery_level: %d\n", battery_level);
}

static void current_operator_cbk(char * name)
{
	printf("\n -----> HFP %s, operate_name: %s\n", __func__, name);
}

static void resp_and_hold_cbk(uint8_t resp_and_hold)
{
	printf("\n -----> HFP %s \n", __func__);
}

static void clip_cbk(char * number)
{
	printf("\n -----> HFP %s \n", __func__);
}

static void call_waiting_cbk(char * number)
{
	printf("\n -----> HFP %s \n", __func__);
}

static void current_calls_cbk(bluetooth_call_t call)
{
	printf("\n -----> HFP current call: {idx:%d, direction:%d, state:%s, number:%s}\n",
	       call.idx, call.direction, convert_call_state_to_string(call.state), call.number);
}

static void volume_change_cbk(uint8_t type, uint16_t volume)
{
	printf("\n -----> HFP %s, volume_type:%d, volume: %d\n", __func__, type, volume);
}

static void subscriber_info_cbk(uint8_t type, char * name)
{
	printf("\n -----> HFP %s, subscriber_type:%d, name: %s\n", __func__, type, name);
}

static void in_band_ring_tone_cbk(uint8_t state)
{
	printf("\n -----> HFP %s, state: %d \n", __func__, state);
}
static void last_voice_tag_number_cbk(char * number)
{
	//TODO
}

static void ring_indication_cbk()
{
	printf("\n -----> HFP %s \n", __func__);
}

static void ag_model_name_cbk(char * name)
{
	printf("\n -----> HFP %s, modle_name: %s \n", __func__, name);
}

static void ag_manufacturer_id_cbk(char * name)
{
	printf("\n -----> HFP %s, manufacturer_id: %s \n", __func__, name);
}

static void call_action_complete_cbk(int action, int err_code)
{
	printf("\n -----> HFP %s, action: %d, err_code: %d\n", __func__, action, err_code);
}

static void standby_indication_cbk()
{
	printf("\n -----> HFP %s.\n", __func__);
}

/*hfp end*/

static hfp_callback_t s_hfp_cbks = {
	connection_state_cbk,
	audio_state_cbk,
	vr_cmd_cbk,
	network_state_cbk,
	network_roaming_cbk,
	network_signal_cbk,
	battery_level_cbk,
	current_operator_cbk,
	resp_and_hold_cbk,
	clip_cbk,
	call_waiting_cbk,
	current_calls_cbk,
	volume_change_cbk,
	subscriber_info_cbk,
	in_band_ring_tone_cbk,
	last_voice_tag_number_cbk,
	ring_indication_cbk,
	ag_model_name_cbk,
	ag_manufacturer_id_cbk,
    call_action_complete_cbk,
    standby_indication_cbk,
};

hfp_callback_t *hlp_hfp_get_cbks()
{
	return &s_hfp_cbks;
}

int enter_hfp_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("%d.	Go to uplater menu.\n", HF_BACK);
	printf("%d.	Connect HFP.\n", HF_CONNECT);
	printf("%d.	Disconnect HFP.\n", HF_DISCONNECT);
	printf("%d.	Dial.\n", HF_DIAL);
	printf("%d.	Terminate.\n", HF_TERMINATE);
	printf("%d.	AcceptCall.\n", HF_ACCEPTCALL);
	printf("%d.	RejectCall.\n", HF_REGECTCALL);
	printf("%d.	HOLD_AND_ACCEPT or SWAP_CALLS\n", HF_HOLD);
	printf("%d.	RELEASE_AND_ACCEPT.\n", HF_RELEASE);
	printf("%d.	Terminate call with index.\n", HF_TERMINATE_WITH_INDEX);
	printf("%d.	SWITCH_AUDIO.\n", HF_SWITCH_AUDIO);
	printf("%d.	SEND_DTMF.\n", HF_SEND_DTMF);
	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);
	return cmd;
}

int execute_hfp_command(int cmd)
{
	switch (cmd) {
		case HF_CONNECT:
			if (choose_device() > 0) {
				brt_hfp_connect(context.devices[context.target_device].address);
			}
			break;
		case HF_DISCONNECT:
			if (is_hfp_connected) {
				brt_hfp_disconnect(m_device);
			}
			break;
		case HF_DIAL:
			if (is_hfp_connected) {
				printf("Please input a phone number \n > ");
				char buffer[MAX_NUM_LEN];
				fgets(buffer, MAX_NUM_LEN, stdin);
				brt_hfp_dial(buffer);
			}
			break;
		case HF_TERMINATE:
			if (is_hfp_connected) {
				brt_hfp_terminate_call(m_device, 0);
			}
			break;
		case HF_ACCEPTCALL:
			if (is_hfp_connected) {
				brt_hfp_accept_call(m_device, CALL_ACCEPT_NONE);
			}
			break;
		case HF_REGECTCALL:
			if (is_hfp_connected) {
				brt_hfp_reject_call(m_device);
			}
			break;
		case HF_HOLD:
			if (is_hfp_connected) {
				brt_hfp_accept_call(m_device, CALL_ACCEPT_HOLD);
			}
			break;
		case HF_RELEASE:
			if(is_hfp_connected) {
				brt_hfp_accept_call(m_device, CALL_ACCEPT_TERMINATE);
			}
			break;
		case HF_TERMINATE_WITH_INDEX:
			if (is_hfp_connected) {
				printf("Terminate Call With Specific Index! Please input the call index \n > ");
				char index[2];
				fgets(index, 2, stdin);
				brt_hfp_terminate_call(m_device, atoi(index));
			}
			break;
		case HF_SWITCH_AUDIO:
			if (is_hfp_connected) {
				printf("Choose your action -- 0: disconnect audio, 1: connect audio\n > ");
				char buf[2];
				fgets(buf, 2, stdin);
				if (atoi(buf) == 1) {
					brt_hfp_connect_audio(m_device);
				} else if (atoi(buf) == 0) {
					brt_hfp_disconnect_audio(m_device);
				}
			}
			break;
		case HF_SEND_DTMF:
			if (is_hfp_connected) {
				printf("DTMF mode please input one of {0,1,2,3,4,5,6,7,8,9,*,#}\n");
				char dtmf[2];
				fgets(dtmf, 2, stdin);
				brt_hfp_send_dtmf(dtmf[0]);

			}
			break;
		case HF_BACK:
			return BACK;
		default:
			printf("\t NOT DEFINED COMMAND!!\n");
	}
	return HFP_MENU;
}

