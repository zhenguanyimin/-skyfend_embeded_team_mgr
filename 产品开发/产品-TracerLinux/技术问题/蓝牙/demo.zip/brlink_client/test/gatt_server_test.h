#include "brt_gatt_server.h"

gatt_server_callback_t * hlp_gatt_server_get_cbks();
int enter_gatt_server_commmand_line();
int execute_gatt_server_command(int cmd);
