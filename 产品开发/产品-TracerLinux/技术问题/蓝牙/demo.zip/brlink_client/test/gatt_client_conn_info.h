#include "gatt_structs.h"

typedef struct tag_conn_info {
	uint8_t client_if;
	uint16_t conn_id;
	int srvc_num;
	GATT_Service_t gatt_srvc_array[MAX_GATT_SERVICE_NUM] ;
} conn_info_t;


void conn_info_init(uint8_t client_if, uint16_t conn_id);
void conn_info_destroy();
conn_info_t *get_conn_info(uint16_t conn_id);
GATT_Service_t *get_gatt_srvc_by_instId(uint16_t srvcInstId);
GATT_Chara_t *get_gatt_chara_by_instId(GATT_Service_t *gatt_srvc, uint16_t charInstId);
void conn_info_add_service(uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid);
void conn_info_add_characteristic(uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint8_t charProp);

