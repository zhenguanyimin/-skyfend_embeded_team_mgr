#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include "brt_sdk.h"
#include "brt_bluetooth.h"
#include "service_uuid_def.h"
#include "brt_rfcomm.h"
#include "hfp_test.h"
#include "a2dp_avrcp_test.h"
#include "pbap_test.h"
#include "gatt_client_test.h"
#include "gatt_server_test.h"
#include "audio_stream_test.h"
#include "test.h"

#define CASE_RET_STR(a) case a: return #a;

static int enter_command_line();
static int execute_command(int *cmd, int is_pending);
static int execute_local_properties_command(int cmd);
static void init_profiles();
static void cleanup_profiles();

context_t context;
static uint8_t s_port = 0;

bt_uuid_t SPP_UUID = {
	.uu = {
		0x00, 0x00, 0x11, 0x01, 0x00, 0x00, 0x10, 0x00,
		0x80, 0x00, 0x00, 0x80, 0x5F, 0x9B, 0x34, 0xFB
	},
};
static void select_one_device()
{
	int enter = 0;
	printf("Please choose a device:\n>");
	scanf("%d", &context.target_device);
	scanf("%c", &enter);
}

static void show_device_list()
{
	int i;
	uint8_t *addr;
	printf("\nDevice List:\n");
	for (i = 0; i < context.current_dev_num; i++) {
		addr = context.devices[i].address.address;
		printf("\t[%02d] <%02X:%02X:%02X:%02X:%02X:%02X>:%s.\n", context.devices[i].idex,
		       addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], context.devices[i].name.name);
	}
	printf("\t[%02d] <go back>.\n",i);

}

static const char *get_bond_state_string(bt_bond_state_t state)
{
	switch (state) {
			CASE_RET_STR(BT_BOND_STATE_NONE);
			CASE_RET_STR(BT_BOND_STATE_BONDING);
			CASE_RET_STR(BT_BOND_STATE_BONDED);
	}

	return "unknown";
};

static void *get_bonded_devices_proc(void *arg)
{
	execute_local_properties_command(6);
	return NULL;
}

static void brt_state_changed_cb(uint8_t state) //回掉蓝牙初始成功
{
	if (state == BT_STATE_ON) {
		printf("Bluetooth is enabled!\n");
		pthread_t thread;
		pthread_create(&thread, NULL, get_bonded_devices_proc, NULL);
	} else if (state == BT_STATE_OFF) {
		printf("Bluetooth is disabled!\n");
		//cleanup_profiles();
	}
}

static void bt_version_cb(char * version)
{
	printf("gocsdk Version:%s.\n", version);
}

static void add_device_to_list(bt_bdaddr_t addr, char *name)
{
	memcpy(&context.devices[context.device_offset].address, &addr, sizeof(addr));
	if (name && name[0]) {
		strcpy(context.devices[context.device_offset].name.name, name);
	}
	context.devices[context.device_offset].idex = context.device_offset;
	context.device_offset++;
	context.current_dev_num = context.device_offset > context.current_dev_num ? context.device_offset : context.current_dev_num;
	context.device_offset %= MAX_DEVICE_NUM;
}

static const char *get_service_str(uint16_t svc)
{
	switch (svc) {
		CASE_RET_STR(SERVICE_UUID_SERVER_SERVICE);
		CASE_RET_STR(SERVICE_UUID_BROWSE_GROUP);
		CASE_RET_STR(SERVICE_UUID_PUBLIC_BROWSE_GROUP);
		CASE_RET_STR(SERVICE_UUID_SERIAL_PORT);
		CASE_RET_STR(SERVICE_UUID_LAN_ACCESS);
		CASE_RET_STR(SERVICE_UUID_DIALUP_NET);
		CASE_RET_STR(SERVICE_UUID_IRMC_SYNC);
		CASE_RET_STR(SERVICE_UUID_OBEX_OBJ_PUSH);
		CASE_RET_STR(SERVICE_UUID_OBEX_FILE_TRANS);
		CASE_RET_STR(SERVICE_UUID_IRMC_SYNC_CMD);
		CASE_RET_STR(SERVICE_UUID_HEADSET);
		CASE_RET_STR(SERVICE_UUID_CORDLESS_TELE);
		CASE_RET_STR(SERVICE_UUID_AUDIO_SOURCE);
		CASE_RET_STR(SERVICE_UUID_AUDIO_SINK);
		CASE_RET_STR(SERVICE_UUID_AVRCP_TG);
		CASE_RET_STR(SERVICE_UUID_ADV_AUDIO_DISTRIB);
		CASE_RET_STR(SERVICE_UUID_AVRCP_CT);
		CASE_RET_STR(SERVICE_UUID_AVRCP_CT_CT);
		CASE_RET_STR(SERVICE_UUID_INTERCOM);
		CASE_RET_STR(SERVICE_UUID_FAX);
		CASE_RET_STR(SERVICE_UUID_HEADSET_AG);
		CASE_RET_STR(SERVICE_UUID_WAP);
		CASE_RET_STR(SERVICE_UUID_WAP_CLIENT);
		CASE_RET_STR(SERVICE_UUID_PAN_PANU);
		CASE_RET_STR(SERVICE_UUID_PAN_NAP);
		CASE_RET_STR(SERVICE_UUID_PAN_GN);
		CASE_RET_STR(SERVICE_UUID_DIRECT_PRINT);
		CASE_RET_STR(SERVICE_UUID_REF_PRINT);
		CASE_RET_STR(SERVICE_UUID_IMAGING);
		CASE_RET_STR(SERVICE_UUID_IMAG_RESPONDER);
		CASE_RET_STR(SERVICE_UUID_IMAG_AUTO_ARCH);
		CASE_RET_STR(SERVICE_UUID_IMAG_REF_OBJ);
		CASE_RET_STR(SERVICE_UUID_HANDSFREE);
		CASE_RET_STR(SERVICE_UUID_HANDSFREE_AG);
		CASE_RET_STR(SERVICE_UUID_DPS_REF_OBJ);
		CASE_RET_STR(SERVICE_UUID_REFLECTED_UI);
		CASE_RET_STR(SERVICE_UUID_BASIC_PRINT);
		CASE_RET_STR(SERVICE_UUID_PRINT_STATUS);
		CASE_RET_STR(SERVICE_UUID_HID);
		CASE_RET_STR(SERVICE_UUID_HCRP);
		CASE_RET_STR(SERVICE_UUID_HCR_PRINT);
		CASE_RET_STR(SERVICE_UUID_HCR_SCAN);
		CASE_RET_STR(SERVICE_UUID_SIM_ACCESS);
		CASE_RET_STR(SERVICE_UUID_PBAP_PCE);
		CASE_RET_STR(SERVICE_UUID_PBAP_PSE);
		CASE_RET_STR(SERVICE_UUID_PBAP);
		CASE_RET_STR(SERVICE_UUID_MAP_MAS);
		CASE_RET_STR(SERVICE_UUID_MAP_MNS);
		CASE_RET_STR(SERVICE_UUID_MAP);
		CASE_RET_STR(SERVICE_UUID_PNP_INFO);
		CASE_RET_STR(SERVICE_UUID_GENERIC_NET);
		CASE_RET_STR(SERVICE_UUID_GENERIC_FILE_TRANS);
		CASE_RET_STR(SERVICE_UUID_GENERIC_AUDIO);
		CASE_RET_STR(SERVICE_UUID_GENERIC_TELE);
		CASE_RET_STR(SERVICE_UUID_VIDEO_SOURCE);
		CASE_RET_STR(SERVICE_UUID_VIDEO_SINK);
		CASE_RET_STR(SERVICE_UUID_VIDEO_DISTRIBUTION);
		CASE_RET_STR(SERVICE_UUID_HDP);
		CASE_RET_STR(SERVICE_UUID_HDP_SOURCE);
		CASE_RET_STR(SERVICE_UUID_HDP_SINK);
		CASE_RET_STR(SERVICE_UUID_GENERIC_ATT);
	}

	return "unknown";
}

static void device_found_cb(bt_bdaddr_t addr, uint8_t type_of_device, int class_of_device, uint8_t rssi, char * name, uint8_t num_svc, uint16_t *svc)
{
	int i;
	int found = 0;
	uint8_t *address = addr.address;

	if (!name || !name[0]) {
		return;
	}

	printf("Device found: %02X:%02X:%02X:%02X:%02X:%02X - %s.\n",
	       address[0], address[1], address[2], address[3], address[4], address[5], name);

	for (i = 0; i< num_svc; i++) {
		printf("\tservice[%d] = <%s>\n", i, get_service_str(svc[i]));
	}

	for (i = 0; i < context.current_dev_num; i++) {
		if (memcmp(&addr, &context.devices[i].address, sizeof(addr)) == 0) {
			found = 1;
			if (name && name[0]) {
				strcpy(context.devices[i].name.name, name);
			}
			return;
		}
	}

	if (!found) {
		add_device_to_list(addr, name);
	}
}

static void discovery_state_changed_cb(uint8_t state)
{
	if (state == BT_DISCOVERY_STARTED) {
		printf("Discovery started!\n");
	} else if (state == BT_DISCOVERY_STOPPED) {
		printf("Discovery stopped!\n");
		show_device_list();
	}
}

static void pin_request_cb(bt_bdaddr_t addr, int class_of_device, uint8_t min_16_digit, char * name)
{
	uint8_t *address = addr.address;
	printf("Device[%02X:%02X:%02X:%02X:%02X:%02X] \"%s\" request pair with this local device.\n",
	       address[0], address[1], address[2], address[3], address[4], address[5], (name ? name : "null"));
	brt_bluetooth_pin_reply(addr, 1, 4, "1234");
}

static void ssp_request_cb(bt_bdaddr_t addr, int class_of_device, uint8_t pairing_variant, int passkey, char * name)
{
	uint8_t *address = addr.address;
	printf("Device[%02X:%02X:%02X:%02X:%02X:%02X] \"%s\" request simple pair with this local device. passkey:%d.\n",
	       address[0], address[1], address[2], address[3], address[4], address[5], (name ? name : "null"), passkey);
	brt_bluetooth_ssp_reply(addr, pairing_variant, 1, passkey);
}

static void bond_state_changed_cb(uint8_t status, bt_bdaddr_t addr, uint8_t state)
{
	uint8_t *address = addr.address;
	printf("Device[%02X:%02X:%02X:%02X:%02X:%02X] bond state changed:%s.\n",
	       address[0], address[1], address[2], address[3], address[4], address[5], get_bond_state_string(state));
}

static void acl_state_changed_cb(uint8_t status, bt_bdaddr_t address, uint8_t state)
{
	printf("--->%s. state :%d\n", __func__, state);
}

static void app_gap_started_cb(uint16_t len,uint8_t * data)
{
	printf("--->%s, len :%d, data :%s\n", __func__, len, data);
}

static void connection_auth_req_cb(bt_bdaddr_t addr, uint8_t profile_id)
{
	uint8_t *address = addr.address;
	printf("--->%s, addr[%02x%02x%02x%02x%02x%02x], profile_id [%d]\r\n", __func__,
	       address[0], address[1], address[2], address[3], address[4], address[5], profile_id);
	brt_bluetooth_connection_auth(addr, profile_id, 1);
}

static void le_rx_test_cb(uint8_t status)
{
	printf("--->%s, status[0x%x]\r\n", __func__, status);
}

static void le_tx_test_cb(uint8_t status)
{
	printf("--->%s, status[0x%x]\r\n", __func__, status);
}

static void le_test_end_cb(uint8_t status, uint16_t number_of_packets)
{
	printf("--->%s, status[0x%x], number_of_packets[%d]\r\n", __func__, status, number_of_packets);
}

static void rfcomm_fetch_channels_cbk(bt_bdaddr_t addr, bt_uuid_t uuid, uint8_t channel)
{
	s_port = channel;
	uint8_t *address = addr.address;
	printf("%s([%02X:%02X:%02X:%02X:%02X:%02X], channel:%d.\n", __func__,
	       address[0], address[1], address[2], address[3], address[4], address[5], channel);
}

static void rfcomm_fetch_channels_end_cbk(bt_bdaddr_t addr, bt_uuid_t uuid, uint8_t status)
{
	uint8_t *address = addr.address;
	printf("%s([%02X:%02X:%02X:%02X:%02X:%02X], status:%d.\n",  __func__,
	       address[0], address[1], address[2], address[3], address[4], address[5], status);
}

static bluetooth_callback_t s_bluetooth_cbks = {
	brt_state_changed_cb,
	bt_version_cb,
	device_found_cb,
	discovery_state_changed_cb,
	pin_request_cb,
	ssp_request_cb,
	bond_state_changed_cb,
	acl_state_changed_cb,
	app_gap_started_cb,
	connection_auth_req_cb,
	le_rx_test_cb,
	le_tx_test_cb,
	le_test_end_cb,
};

static rfcomm_callback_t s_rfcomm_cbks = {
	rfcomm_fetch_channels_cbk,
	rfcomm_fetch_channels_end_cbk,
};

static int enter_local_properties_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("0.	GO to uplater menu.\n");
	printf("1.	Get bluetooth state.\n");
	printf("2.	Get name of local device.\n");
	printf("3.	Get address of local device.\n");
	printf("4.	Get class of local device.\n");
	printf("5.	Get scan mode of local device.\n");
	printf("6.	Get bonded devices.\n");
	printf("7.	Set name of local device.\n");
	printf("8.	Set local device under discoverable state.\n");
	printf("9.	Set local device under non-discoverable state.\n");
	printf("10.	Handle os sleep.\n");
	printf("11.	Handle os wakeup.\n");
	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);

	return cmd;
}

static int execute_local_properties_command(int cmd)
{
	bt_bdname_t *name;
	bt_bdaddr_t *addr;
	uint32_t cod;
	uint32_t scan_mode;
	int i, j, number = 8;
	bt_remote_device_t devices[8];
	uint8_t *address;
	char buffer[128];
	bt_bdname_t local_name = {0};
	int svc_num;
	uint16_t *svcs;

	switch (cmd) {
		case 1:
			printf("Bluetooth state is %s.\n", brt_bluetooth_get_state() == BT_STATE_ON ? "enabled" : "disabled");
			break;
		case 2:
			name = brt_bluetooth_get_name();
			if (name) {
				printf("Loal device name:%s.\n", name->name);
			}
			break;
		case 3:
			addr = brt_bluetooth_get_address();
			if (addr) {
				printf("Local device address:%02X:%02X:%02X:%02X:%02X:%02X.\n",
				       addr->address[0], addr->address[1], addr->address[2], addr->address[3], addr->address[4], addr->address[5]);
			}
			break;
		case 4:
			cod = brt_bluetooth_get_class();
			printf("Class of local device:0X%X.\n", cod);
			break;
		case 5:
			scan_mode = brt_bluetooth_get_scan_mode();
			printf("Scan mode of local device:%d.\n", scan_mode);
			break;
		case 6:
			brt_bluetooth_get_bonded_devices(devices, &number);
			for (i = 0; i < number; i++) {
				address = (*(devices + i)).address.address;
				name = &(*(devices + i)).name;
				printf("\t------------ bonded device[%02d --- %02d] ------------\n\t\t address: %02X:%02X:%02X:%02X:%02X:%02X.\n\t\tname:%s\n", i,number,
				       address[0], address[1], address[2], address[3], address[4], address[5], name->name);
				svc_num = (*(devices + i)).num_service;
				svcs = (*(devices + i)).services;
				printf("\t\tservice number:%d\n", svc_num);

				for(j=0;j<svc_num;j++) {
					printf("\t\t\tservice[%02d]:0x%04X - %s\n", j + 1, svcs[j], get_service_str(svcs[j]));
				}

				add_device_to_list(devices[i].address, NULL);
			}
			break;
		case 7:
			printf("Please enter the device name:\n>");
			fgets(buffer, 128, stdin);
			memcpy(local_name.name, buffer, strlen(buffer) - 1/*ignore the last 0x0A*/);
			brt_bluetooth_set_name(local_name);
			break;
		case 8:
			brt_bluetooth_set_scan_mode(BT_SCAN_MODE_CONNECTABLE_DISCOVERABLE);
			break;
		case 9:
			brt_bluetooth_set_scan_mode(BT_SCAN_MODE_NONE);
			break;
		case 10:
			brt_bluetooth_os_suspend_action();
			break;
		case 11:
			brt_bluetooth_os_wakeup_action();
			break;
		case 0:
			return BACK;
		default :
			printf(" NOT DEFINR COMMAND !\n");
	}
	return PROPERTIES_MENU;
}

static int enter_remote_properties_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("1.	Get priority of remote device.\n");
	printf("2.	Get manufacturer code of remote device.\n");
	printf("\n");
	printf("Please choose a command(enter the index of command, 'b' to go to upper level command line. 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	}

	cmd = atoi(buffer);

	return cmd;
}

static brt_bluetooth_socket_t *s_bluetooth_socket = NULL;

static void * read_spp_proc(void *arg)
{
	static long count = 0;

	brt_bluetooth_socket_t * socket = (brt_bluetooth_socket_t *) arg;
	if (socket) {
		int ret;
		uint8_t buf[256];

		s_bluetooth_socket = socket;
		bt_bdaddr_t addr = brt_rfcomm_get_address(socket);
		memset(buf, 0, 256);
		printf("socket connected. remote device[%02X:%02X:%02X:%02X:%02X:%02X]\n",
		       addr.address[0], addr.address[1], addr.address[2], addr.address[3], addr.address[4], addr.address[5]);
		while ((ret = brt_rfcomm_read(socket, buf, 256)) > 0) {
			count += ret;
			printf("Read %d bytes, total %ld bytes:[%s].\n", ret, count, buf);
			memset(buf, 0, 256);
		}

	}

	return NULL;
}

static void * accept_and_read_spp_proc(void *arg)
{
	brt_bluetooth_server_socket_t *server = (brt_bluetooth_server_socket_t *) arg;

	if (!server) {
		return NULL;
	}

    do {
        brt_bluetooth_socket_t * socket = brt_rfcomm_accept(server);
        if (socket) {
            int ret;
            uint8_t buf[256];

            s_bluetooth_socket = socket;
            bt_bdaddr_t addr = brt_rfcomm_get_address(socket);
            memset(buf, 0, 256);
            printf("socket accepted. remote device[%02X:%02X:%02X:%02X:%02X:%02X]\n",
                    addr.address[0], addr.address[1], addr.address[2], addr.address[3], addr.address[4], addr.address[5]);
            while ((ret = brt_rfcomm_read(socket, buf, 256)) > 0) {
                printf("Read %d bytes:[%s].\n", ret, buf);
                memset(buf, 0, 256);
            }

            printf("Socket close.\n");
        }

        printf("Waiting for a new client.\n");
    } while (server);

	brt_rfcomm_server_close(server);
	return NULL;
}

static int enter_spp_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("0.	GO to uplater menu.\n");
	printf("1.	Establish a new spp connection with a remote device.\n");
	printf("2.	Listen for a new spp connection from a remote device.\n");
	printf("3.	Close a spp connection.\n");
	printf("4.	Send data to remote device using spp connection.\n");
	printf("5.	Fetch all spp channels of a specified UUID in a remote deivce.\n");
	printf("6.	Stop Listening for spp connection(Quit Spp Server).\n");
	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);

	return cmd;
}

brt_bluetooth_server_socket_t *server = NULL;

static int execute_spp_command(int cmd)
{
	bt_uuid_t uuid; /*FIXME*/
	brt_bluetooth_socket_t *socket = NULL;
	pthread_t spp_thread;

	if (cmd == 0) {
		return BACK;
	}

	if (cmd != 2 && cmd != 4 && cmd != 6 && cmd != ENTER) {
		if (choose_device() == 0) {
			return BACK;
		}
	}

	switch (cmd) {
		case 1:
			socket = brt_rfcomm_connect(context.devices[context.target_device].address, uuid, s_port);
			pthread_create(&spp_thread, NULL, read_spp_proc, socket);
			break;
		case 2:
            if (server) {
                printf("There is one server ");
                break;
            }
			server = brt_rfcomm_listen(SPP_UUID, 0, "BRT Test Spp");
			if (server) {
				printf("brt_bluetooth_server_socket created:%p.\n", server);
				pthread_create(&spp_thread, NULL, accept_and_read_spp_proc, server);
                if(!server) {
                    printf("there is  no server");
                }
			}
			break;
        case 6:
            if (!server) {
                printf("No server can't to exit");
                break;
            }
            printf("Stop spp server");
            brt_rfcomm_server_close(server);
            server = NULL;
            break;
		case 3:
			if (s_bluetooth_socket) {
				bt_bdaddr_t addr = brt_rfcomm_get_address(s_bluetooth_socket);
				printf("Try to close bluetooth socket which connected to remote device:[%02X:%02X:%02X:%02X:%02X:%02X].\n",
				       addr.address[0], addr.address[1], addr.address[2], addr.address[3], addr.address[4], addr.address[5]);
				brt_rfcomm_close(s_bluetooth_socket);
				s_bluetooth_socket = NULL;
			}
			break;
		case 4:
			if (s_bluetooth_socket) {
				char buffer[256];
				bt_bdaddr_t addr = brt_rfcomm_get_address(s_bluetooth_socket);
				printf("Try to send data to remote device:[%02X:%02X:%02X:%02X:%02X:%02X].\n\tPlease enter the text to be sent:",
				       addr.address[0], addr.address[1], addr.address[2], addr.address[3], addr.address[4], addr.address[5]);
				fgets(buffer, 256, stdin);
				printf("Try to send:%s to remtoe device.\n", buffer);
				brt_rfcomm_write(s_bluetooth_socket, buffer, strlen(buffer));
			}
			break;
		case 5:
			brt_rfcomm_fetch_channels(context.devices[context.target_device].address, SPP_UUID);
			break;
		default:
			printf("\t NOT DEFINR COMMAND\n");
	}
	return SPP_MENU;
}

static void execute_remote_properties_command(int cmd)
{
	uint8_t priority;
	bt_manufacturer_code_t code;

	if (choose_device() == 0) {
		return;
	}

	switch (cmd) {
		case 1:
			priority = brt_bluetooth_get_device_priority(context.devices[context.target_device].address);
			printf("device priority:%d.\n", priority);
			break;
		case 2:
			code = brt_bluetooth_get_manufacturer_code(context.devices[context.target_device].address);
			switch (code) {
				case BT_MANUFACTURER_CODE_APPLE:
					printf("It is an Apple device.\n");
					break;
				case BT_MANUFACTURER_CODE_OTHER:
					printf("It is an Android device.\n");
					break;
				case BT_MANUFACTURER_CODE_UNKNOWN:
					printf("device manufacturer is unknown.\n");
					break;
			}
			break;
	}
}

static int enter_command_line()
{
	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("1.	Enable the bluetooth.\n");
	printf("2.	Disable the bluetooth.\n");
	printf("3.	Start to discover Bluetooth devices.\n");
	printf("4.	Stop discovering Bluetooth devices.\n");
	printf("5.	Set/Get local properties.\n");
	printf("6.	Set/Get remote device properties.\n");
	printf("7.	Pair with remote device.\n");
	printf("8.	Unpair with remote device.\n");
	printf("9.	Enter SPP(data transfer) subcommands.\n");
	printf("10.	Enter HFP subcommands.\n");
	printf("11.	Enter A2DP/AVRCP subcommands.\n");
	printf("12.	Enter PBAP subcommands.\n");
	printf("13.	Enter GATT_CLIENT subcommands.\n");
	printf("14.	Enter GATT_SERVER subcommands.\n");
	printf("\n");
	printf("Please choose a command(enter the index of command, 'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	}

	cmd = atoi(buffer);

	return cmd;
}

static char addr[] = {0x00, 0x15, 0x83, 0x11,0xBF, 0xCE};
static int execute_command(int *cmd, int is_pending)
{
	switch (*cmd) {
		case 1:
			{
				bt_bdaddr_t address;

				memset(&address, 0, sizeof(bt_bdaddr_t));
				memcpy(address.address, addr, sizeof(addr));
				//brt_bluetooth_preset_addr(address);
				brt_bluetooth_enable();
			}
			break;
		case 2:
			brt_bluetooth_disable();
			break;
		case 3:
			brt_bluetooth_start_discovery();
			break;
		case 4:
			brt_bluetooth_stop_discovery();
			break;
		case 5:
			*cmd = enter_local_properties_command_line();
			return execute_local_properties_command(*cmd);
			break;
		case 6:
			*cmd = enter_remote_properties_command_line();
			execute_remote_properties_command(*cmd);
			break;
		case 7:
			if (choose_device() > 0) {
				brt_bluetooth_create_bond(context.devices[context.target_device].address);
			}
			break;
		case 8:
			if (choose_device() > 0) {
				brt_bluetooth_remove_bond(context.devices[context.target_device].address);
			}
			break;
		case 9:
			*cmd = enter_spp_command_line();
			return execute_spp_command(*cmd);
			break;
		case 10:
			*cmd = enter_hfp_command_line();
			return execute_hfp_command(*cmd);
			break;
		case 11:
			*cmd = enter_a2dp_avrcp_command_line();
			return execute_a2dp_avrcp_command(*cmd);
			break;
		case 12:
			*cmd = enter_pbap_command_line();
			return execute_pbap_command(*cmd);
			break;
		case 13:
			*cmd = enter_gatt_client_command_line();
			return execute_gatt_client_command(*cmd);
			break;
		case 14:
			*cmd = enter_gatt_server_command_line();
			return execute_gatt_server_command(*cmd);
			break;
	}
	return -1;
}

int choose_device()
{
	if (context.current_dev_num == 0) {
		printf("There is not any saved devices. Please choose <3> command to discover firstly.\n");
		return 0;
	} else {
		show_device_list();
		select_one_device();
		if (context.target_device == context.current_dev_num) {
			printf("select: %d\n", context.target_device);
			printf("exit choose device !\n");
			return 0;
		}else if (context.target_device > context.current_dev_num) {
			printf("There is an out of range value.\n");
			choose_device();
		}
		return 1;
	}
}

void main(int argc, char **argv)
{
	int cmd = 0;
	int ret ;
	int execute_result = -1;

	memset(&context, 0, sizeof(context));
	context.pending_cmd = -1;

	//set socket path(save_path)
	if(argc > 1)
		ret = brt_sdk_init_ex(argv[1]);
	else 
		ret = brt_sdk_init();

	if (ret  > 0) {
		printf("Server connected!\n");
	} else {
		printf("Can NOT connect to the bluetooth server.\n");
		return;
	}

	brt_bluetooth_init(&s_bluetooth_cbks);
	init_profiles();
	while (cmd >= 0) {
		switch (execute_result) {
			case PROPERTIES_MENU:
				cmd = enter_local_properties_command_line();
				execute_result = execute_local_properties_command(cmd);
				break;
			case SPP_MENU:
				cmd = enter_spp_command_line();
				execute_result = execute_spp_command(cmd);
				break;
			case HFP_MENU:
				cmd = enter_hfp_command_line();
				execute_result = execute_hfp_command(cmd);
				break;
			case A2DP_AVRCP_MENU:
				cmd = enter_a2dp_avrcp_command_line();
				execute_result = execute_a2dp_avrcp_command(cmd);
				break;
			case PBAP_MENU:
				cmd = enter_pbap_command_line();
				execute_result = execute_pbap_command(cmd);
				break;
			case GATT_CLIENT_MENU:
				cmd = enter_gatt_client_command_line();
				execute_result = execute_gatt_client_command(cmd);
				break;
			case GATT_SERVER_MENU:
				cmd = enter_gatt_server_command_line();
				execute_result = execute_gatt_server_command(cmd);
			case ENTER:
				break;
			case QUIT:
				quit_client();
				break;
			case BACK:
			default :
				cmd = enter_command_line();
				execute_result = execute_command(&cmd, 0);
				break;
		}
	}

	brt_bluetooth_done();
	brt_sdk_done();
}

static int profiles_initialized = 0;
static void init_profiles()
{
	brt_rfcomm_init(&s_rfcomm_cbks);
	brt_hfp_init(hlp_hfp_get_cbks());
	brt_a2dp_init(hlp_a2dp_get_cbks());
	brt_avrcp_init(hlp_avrcp_get_cbks());
	brt_pbap_init(hlp_pbap_get_cbks());
	brt_gatt_client_init(hlp_gatt_client_get_cbks());
	brt_gatt_server_init(hlp_gatt_server_get_cbks());
	brt_audio_stream_init(hlp_audio_stream_get_cbks());
	profiles_initialized = 1;
}

static void cleanup_profiles()
{
	if (!profiles_initialized) {
		return;
	}

	profiles_initialized = 0;
	brt_rfcomm_done();
	brt_hfp_done();
	brt_a2dp_done();
	brt_avrcp_done();
	brt_pbap_done();
	brt_gatt_client_done();
	brt_gatt_server_done();
	brt_audio_stream_done();
}

