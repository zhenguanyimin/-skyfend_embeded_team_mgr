#include "brt_audio_stream.h"

void audio_stream_cb(uint8_t stream_type, uint8_t codec_type, uint16_t len, uint8_t *data);

audio_stream_callback_t *hlp_audio_stream_get_cbks();
