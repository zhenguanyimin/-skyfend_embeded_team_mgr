#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "test.h"
#include "a2dp_avrcp_test.h"
#include "brt_audio_stream.h"

static bt_bdaddr_t m_device;
static int is_a2dp_connected = 0;
static int is_avrcp_connected = 0;

static int s_fast_forward_status = 0;
static int s_rewind_status = 0;
static int s_abs_volume = 0x7F / 2; /*current volume. max value -> 100%*/
#define MAX_NUM_OF_ARR 128
static int s_arr_count = 0;
static int total_items_count = 0xff;
static uint8_t uid_arr[MAX_NUM_OF_ARR][BTRC_UID_SIZE];

static uint8_t *select_uid();
struct a2dp_config {
	int rate;
	uint8_t channels;
};
static struct a2dp_config s_a2dp_config;

/*  a2dp callbacks */
static void connection_state_changed_cbk(bt_bdaddr_t address, uint8_t state)
{
	printf("\n----->A2DP connection state callback state: %d\n", state);
	if (state == STATE_CONNECTED) {
		memcpy(&m_device, &address, sizeof(bt_bdaddr_t));
		is_a2dp_connected = 1;
	} else if (state == STATE_DISCONNECTED) {
		memset(&s_a2dp_config, 0, sizeof(s_a2dp_config));
		memset(&m_device, 0, sizeof(bt_bdaddr_t));
		is_a2dp_connected = 0;
	}
}

static void audio_state_changed_cbk(bt_bdaddr_t address, uint8_t state)
{
	printf("\n----->A2DP audio state callback state: %d\n", state);
	if(state == AUDIO_STATE_STARTED) {
		audio_stream_open(AUDIO_STREAM_TYPE_A2DP, s_a2dp_config.rate, s_a2dp_config.channels, 16);
	} else {
		audio_stream_close();
	}
}

static void audio_config_changed_cbk(bt_bdaddr_t address, int sample_rate, uint8_t channels)
{
	printf("\n----->A2DP %s sample: %d, channels: %d\n", __func__, sample_rate, channels);
	s_a2dp_config.rate = sample_rate;
	s_a2dp_config.channels = channels;
}

static void audio_stream_cbk(uint8_t type, uint16_t len, uint8_t* data)
{
	printf("\n----->A2dp %s, type is %d, len is %d\r\n", __func__, type, len);
}

/* avrcp callbacks */
static void on_connection_state_changed_cbk(uint8_t connected, bt_bdaddr_t address)
{
	printf("\n----->AVRCP %s connected: %d <---\n", __func__, connected);
	if(connected == STATE_CONNECTED) {
		is_avrcp_connected = 1;
	} else if (connected == STATE_DISCONNECTED ) {
		is_avrcp_connected = 0;
	}
}

static void get_rc_features_cbk(bt_bdaddr_t address,uint8_t features)
{
	printf("\n----->AVRCP %s. features:%x\r\n", __func__, features);
}

static void handle_set_abs_volume_cbk(bt_bdaddr_t address, uint8_t abs_val)
{
	printf("\n----->AVRCP %s. address:[%02x:%02x:%02x:%02x:%02x:%02x:], abs_val: %x <---\n", __func__,
			address.address[0], address.address[1], address.address[2],
			address.address[3], address.address[4], address.address[5], abs_val);
	s_abs_volume = abs_val;
	/* If accept this volume value, send response to phone.*/
	if (is_avrcp_connected) {
		brt_avrcp_send_abs_vol_rsp(address, s_abs_volume);
	}
}

static void handle_register_notification_abs_vol_cbk(bt_bdaddr_t address)
{
	printf("\n----->AVRCP %s. address:[%02x:%02x:%02x:%02x:%02x:%02x:], <---\n", __func__,
			address.address[0], address.address[1], address.address[2],
			address.address[3], address.address[4], address.address[5]);
	brt_avrcp_send_register_abs_val_rsp(m_device, BTRC_NOTIFICATION_TYPE_INTERIM, s_abs_volume);
}

static void handle_player_app_setting_changed_cbk(bt_bdaddr_t address, uint16_t data_len, struct AVRCP_NumIDPairStru data)
{
	printf("\n----->AVRCP %s. address:[%02x:%02x:%02x:%02x:%02x:%02x:], data_len: %d <---\n", __func__,
	       address.address[0], address.address[1], address.address[2],
	       address.address[3], address.address[4], address.address[5], data_len);

	printf("attr_num : %d \n", data.num);
	int k = 0;
	for (k; k < data.num; k++) {
		struct AVRCP_IDPairStru * p = data.id_value + k;
		printf("id_value_t_%d, attr_id: %d, value: %d. \n", k, p -> attr_id, p -> value);
	}
}

static void handle_track_changed_cbk(bt_bdaddr_t address, uint16_t data_len, struct AVRCP_Num4IDValueStru DATA)
{
	printf("\n----->AVRCP %s. address:[%02x:%02x:%02x:%02x:%02x:%02x:], data_len: %d <---\n", __func__,
	       address.address[0], address.address[1], address.address[2],
	       address.address[3], address.address[4], address.address[5], data_len);

	printf("attr_num : %d \n", DATA.num);
	int k = 0;
	for (k; k < DATA.num; k++) {
		struct AVRCP_4IDStringStru * p = DATA.id_value + k;
		if (p -> attr_id == MEDIA_ATTRIBUTE_UID) {
			printf("id_value_t_%d, attr_id: %d, len: %d, UID: %02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x \n", k, p -> attr_id, p -> len, 
                    p->value[0], p->value[1], p->value[2], p->value[3], p->value[4], p->value[5], p->value[6], p->value[7]);
		} else {
			printf("id_value_t_%d, attr_id: %d, len: %d, value: %s \n", k, p -> attr_id, p -> len, p -> value);
		}
	}
}

static void handle_play_position_changed_cbk(bt_bdaddr_t address, int song_len, int curr_song_position)
{
	printf("\n----->AVRCP %s song_len: %d, song_position: %d\n", __func__, song_len, curr_song_position);
}

static void handle_play_status_changed_cbk(bt_bdaddr_t address, uint8_t play_status)
{
	printf("\n----->AVRCP %s play_status: %d<---\n", __func__, play_status);
}

static void change_folder_path_rsp_cbk(bt_bdaddr_t address,uint8_t status,int count)
{
	printf("\n----->AVRCP %s status: %d count is %d<---\n", __func__, status, count);
	total_items_count = count;
}

static void get_total_number_of_items_rsp_cbk(bt_bdaddr_t address,uint8_t status,int count)
{
	printf("\n----->AVRCP %s status: %d count is %d<---\n", __func__, status, count);
	total_items_count = count;
}

static void play_item_rsp_cbk(bt_bdaddr_t address,uint8_t status)
{
	printf("\n----->AVRCP %s status: %d <---\n", __func__, status);
}

static void get_player_item_cbk(bt_bdaddr_t address, uint8_t status, btrc_item_player_t* player_item)
{
	printf("\n----->AVRCP %s status: %d , player_id=%d, player name :%s<---\n", __func__, status, player_item->player_id, player_item->name);
}

static void get_folder_item_cbk(bt_bdaddr_t address, uint8_t status, btrc_item_folder_t* folder_item)
{
	printf("\n----->AVRCP %s status: %d <---\n", __func__, status);
	if(s_arr_count < MAX_NUM_OF_ARR)
		memcpy(uid_arr[s_arr_count], folder_item->uid, BTRC_UID_SIZE);
	s_arr_count++;
}

static void get_media_item_cbk(bt_bdaddr_t address, uint8_t status, btrc_item_media_t* media_item)
{
	if(s_arr_count < MAX_NUM_OF_ARR)
		memcpy(uid_arr[s_arr_count], media_item->uid, BTRC_UID_SIZE);
	s_arr_count++;
	printf("\n----->AVRCP %s item name: %s , grand total: %d.<---\n", __func__, media_item->name, s_arr_count);
}

static void now_playing_content_changed_cbk(bt_bdaddr_t address, uint8_t state)
{
    printf("\n----->AVRCP %s, state is %d\r\n", __func__, state);
}

static void addressed_player_changed_cbk(bt_bdaddr_t address, uint16_t player_id)
{
    printf("\n----->AVRCP %s, playerid is %d\r\n", __func__, player_id);
}

a2dp_callback_t s_a2dp_cbks = {
	connection_state_changed_cbk,
	audio_state_changed_cbk,
	audio_config_changed_cbk,
	audio_stream_cbk,
};

avrcp_callback_t s_avrcp_cbks = {
	on_connection_state_changed_cbk,
	get_rc_features_cbk,
	handle_player_app_setting_changed_cbk,
	handle_set_abs_volume_cbk,
	handle_register_notification_abs_vol_cbk,
	handle_track_changed_cbk,
	handle_play_position_changed_cbk,
	handle_play_status_changed_cbk,
	change_folder_path_rsp_cbk,
	get_total_number_of_items_rsp_cbk,
	play_item_rsp_cbk,
	get_player_item_cbk,
	get_folder_item_cbk,
	get_media_item_cbk,
    now_playing_content_changed_cbk,
    addressed_player_changed_cbk
};

a2dp_callback_t * hlp_a2dp_get_cbks()
{
	return &s_a2dp_cbks;
};

avrcp_callback_t * hlp_avrcp_get_cbks()
{
	return &s_avrcp_cbks;
};

static void set_player_app_settings()
{
	char buffer[5];
	printf("当前功能只支持iPhone的原生播放器!! 是否继续？(n/N退出，其他继续) \n");
	fgets(buffer, 5, stdin);
	if (buffer[0] == 'N' || buffer[0] == 'n') {
		return;
	}

	struct AVRCP_NumIDPairStru settings;
	settings.num = 1;
	settings.id_value = (struct  AVRCP_IDPairStru *)malloc(sizeof(struct  AVRCP_IDPairStru) * settings.num);

	printf(" 输入设置的属性　\n");
	printf("1	ATTRIBUTE_REPEAT \n");
	printf("2	ATTRIBUTE_SHUFFLE \n");
	printf("\n >");
	fgets(buffer, 5, stdin);
	int attr_id = atoi(buffer);

	printf(" 输入属性的值 \n");
	switch (attr_id) {
		case 1:
			settings.id_value->attr_id = ATTRIB_REPEAT_STATUS;
			printf("1	REPEAT_STATUS_OFF \n");
			printf("2	REPEAT_STATUS_SINGLE_TRACK_REPEAT \n");
			printf("3	REPEAT_STATUS_ALL_TRACK_REPEAT \n");
			printf("\n >");
			fgets(buffer, 5, stdin);
			settings.id_value->value = atoi(buffer);
			break;
		case 2:
			settings.id_value->attr_id = ATTRIB_SHUFFLE_STATUS;
			printf("1	SHUFFLE_STATUS_OFF \n");
			printf("2	SHUFFLE_STATUS_ALL_TRACK_SHUFFLE \n");
			printf("\n >");
			fgets(buffer, 5, stdin);
			settings.id_value->value = atoi(buffer);
			break;
	}

	brt_avrcp_set_player_app_setting(m_device, settings);
}

static void set_addressed_player()
{
	char buffer[5];
	int player_id = 0;
	printf("Please input the addressed player id");
	printf("\n >");
	fgets(buffer, 5, stdin);
	player_id = (uint16_t)atoi(buffer);
	brt_avrcp_set_addressed_player(m_device, player_id);
}

static void get_player_app_settings()
{
	char buffer[5];
	int attr_id = 0;
	uint8_t  attr_num = 0;
	uint16_t  data_len = 0;
	uint8_t*  data = NULL;
	printf(" 输入希望获取的播放器属性 \n");
	printf("1   ATTRIBUTE_EQUALIZER \n");
	printf("2   ATTRIBUTE_REPEAT \n");
	printf("3   ATTRIBUTE_SHUFFLE \n");
	printf("4   ATTRIBUTE_SCAN \n");
	printf("\n >");
	fgets(buffer, 5, stdin);
	attr_id = atoi(buffer);
	switch(attr_id) {
		//case 1:
		case 2:
		case 3:
		//case 4:
			{
				/*user can get multi player settings at the same time*/
				data_len = 1;
				attr_num = 1;
				data = malloc(sizeof(uint8_t)*data_len);
				if(data != NULL) {
					memset(data, 0, data_len);
					data[0] = (uint8_t)attr_id;
				}
			}
			break;
		default:
			break;
	}

	if (attr_num > 0 && data_len > 0) {
		brt_avrcp_get_player_app_setting(m_device, attr_num, data_len, data);
	}

	if (data != NULL) {
		free(data);
	}
}

enum {
	AVRCP_BACK_MENU,
	A2DP_CONNECT,
	A2DP_DISCONNECT,
	AVRCP_CMD_PLAY,
	AVRCP_CMD_STOP,
	AVRCP_CMD_PAUSE,
	AVRCP_CMD_FAST_FORWARD,
	AVRCP_CMD_REWIND,
	AVRCP_CMD_FORWARD,
	AVRCP_CMD_BACKWARD,
	AVRCP_CMD_PLAYER_GET_SETTINGS,
	AVRCP_CMD_PLAYER_SET_SETTINGS,
	AVRCP_CMD_REGISTER_VOL_CHANGED_NOTIF_RSP,
	AVRCP_CMD_GET_NOWPLAYING_LIST,
	AVRCP_CMD_GET_FOLDER_LIST,
	AVRCP_CMD_GET_PLAYER_LIST,
	AVRCP_CMD_SET_ADDRESSED_PLAYER,
	AVRCP_CMD_CHANGE_FOLDER_PATH_DOWN,
	AVRCP_CMD_CHANGE_FOLDER_PATH_UP,
	AVRCP_CMD_GET_TOTAL_NUMBER_OF_ITEMS,
	AVRCP_CMD_PLAY_ITEM,
	AVRCP_CMD_CANCEL_BROWSING
};

int execute_a2dp_avrcp_command(int cmd)
{
	printf("%s,cmd %d,is_a2dp_connected %d",__func__,cmd,is_a2dp_connected);
	switch (cmd) {
		case A2DP_CONNECT:
			if (choose_device() > 0) {
				brt_a2dp_connect(context.devices[context.target_device].address);
			}
			break;
		case A2DP_DISCONNECT:
			if (is_a2dp_connected) {
				brt_a2dp_disconnect(m_device);
			}
			break;
		case AVRCP_CMD_PLAY:
			if (is_avrcp_connected) {
				brt_avrcp_play(m_device);
			}
			break;
		case AVRCP_CMD_PAUSE:
			if (is_avrcp_connected) {
				brt_avrcp_pause(m_device);
			}
			break;
		case AVRCP_CMD_STOP:
			if (is_avrcp_connected) {
				brt_avrcp_stop(m_device);
			}
			break;
		case AVRCP_CMD_REWIND:
			if (is_avrcp_connected) {
				if(s_rewind_status){
					s_rewind_status = 0;
				} else {
					s_rewind_status = 1;
				}
				brt_avrcp_rewind(m_device, s_rewind_status);
			}
			break;
		case AVRCP_CMD_FAST_FORWARD:
			if (is_avrcp_connected) {
				if(s_fast_forward_status){
					s_fast_forward_status = 0;
				} else {
					s_fast_forward_status = 1;
				}
				brt_avrcp_fast_forward(m_device, s_fast_forward_status);
			}
			break;
		case AVRCP_CMD_FORWARD:
			if (is_avrcp_connected) {
				brt_avrcp_forward(m_device);
			}
			break;
		case AVRCP_CMD_BACKWARD:
			if (is_avrcp_connected) {
				brt_avrcp_backward(m_device);
			}
			break;
		case AVRCP_CMD_PLAYER_SET_SETTINGS:
			if (is_avrcp_connected) {
				set_player_app_settings();
			}
			break;
		case AVRCP_CMD_PLAYER_GET_SETTINGS:
			{
				if (is_avrcp_connected) {
					get_player_app_settings();
				}
			}
			break;
		case AVRCP_CMD_REGISTER_VOL_CHANGED_NOTIF_RSP:
			if (is_avrcp_connected) {
				/* simulate the volume change */
				s_abs_volume = random() % 0x7F;
				brt_avrcp_send_register_abs_val_rsp(m_device, BTRC_NOTIFICATION_TYPE_CHANGED, s_abs_volume);
			}
			break;
		case AVRCP_CMD_GET_NOWPLAYING_LIST:
			if(is_avrcp_connected) {
				int start = 0;//The starting position of get folder list
				int items = total_items_count;//Expected count
				s_arr_count=0;
				brt_avrcp_get_nowplaying_list(m_device, start, items);
			}
			break;
		case AVRCP_CMD_GET_FOLDER_LIST:
			if(is_avrcp_connected) {
				int start = 0;//The starting position of get folder list
				int items = total_items_count;//Expected count
				s_arr_count=0;
				brt_avrcp_get_folder_list(m_device, start, items);
			}
			break;
		case AVRCP_CMD_GET_PLAYER_LIST:
			if(is_avrcp_connected) {
				brt_avrcp_get_player_list(m_device, 0, 10);
			}
			break;
		case AVRCP_CMD_SET_ADDRESSED_PLAYER:
			if (is_avrcp_connected) {
				set_addressed_player();
			}
			break;
		case AVRCP_CMD_CHANGE_FOLDER_PATH_DOWN:
			if(is_avrcp_connected) {
				uint8_t direction = 1;//The next layer(0x1) or the upper layer(0x0)
				uint16_t uid_len = 8;
				uint8_t * uid ;//The folder UID to enter, if direction is upper layer, It can be NULL.
				uid = select_uid();
				printf("AVRCP_CMD_CHANGE_FOLDER_PATH_DOWN, direction: %d, uid_len:%d, uid:%02x%02x%02x%02x%02x%02x%02x%02x.\n", direction, uid_len, uid[0], uid[1], uid[2], uid[3], uid[4], uid[5], uid[6], uid[7]);
				brt_avrcp_change_folder_path(m_device, direction, uid_len, uid);
			}
			break;
		case AVRCP_CMD_CHANGE_FOLDER_PATH_UP:
			if(is_avrcp_connected) {
				uint8_t direction = 0;//The next layer(0x1) or the upper layer(0x0)
				uint16_t uid_len = 8;
				uint8_t  uid[8] = {0};//The folder UID to enter, if direction is upper layer, It can be NULL.
				printf("AVRCP_CMD_CHANGE_FOLDER_PATH_UP, direction: %d, uid_len:%d, uid:%02x%02x%02x%02x%02x%02x%02x%02x.\n", direction, uid_len, uid[0], uid[1], uid[2], uid[3], uid[4], uid[5], uid[6], uid[7]);
				brt_avrcp_change_folder_path(m_device, direction, uid_len, uid);
			}
			break;
		case AVRCP_CMD_GET_TOTAL_NUMBER_OF_ITEMS:
			if(is_avrcp_connected) {
				brt_avrcp_get_total_number_of_items(m_device);
			}
			break;
		case AVRCP_CMD_PLAY_ITEM:
			if(is_avrcp_connected) {
				uint16_t uid_len = 8;
				uint8_t * uid = select_uid();;
				brt_avrcp_play_item(m_device, uid_len, uid);
			}
			break;
		case AVRCP_CMD_CANCEL_BROWSING:
			if(is_avrcp_connected) {
				brt_avrcp_cancel_browsing(m_device);
			}
			break;
		case AVRCP_BACK_MENU:
			return BACK;
		default:
			printf("\t NOT DEFINED COMMAND!!\n");
			break;
	}
	return A2DP_AVRCP_MENU;
}

int enter_a2dp_avrcp_command_line()
{

	int cmd = 0;
	char buffer[16];

	printf("\n");
	printf("%d.	Go to uplater menu.\n", AVRCP_BACK_MENU);
	printf("%d.	Connect A2DP.\n", A2DP_CONNECT);
	printf("%d.	Disconnect A2DP.\n", A2DP_DISCONNECT);
	printf("%d.	Avrcp play command.\n", AVRCP_CMD_PLAY);
	printf("%d.	Avrcp stop command.\n", AVRCP_CMD_STOP);
	printf("%d.	Avrcp pause command\n", AVRCP_CMD_PAUSE);
	printf("%d.	Avrcp fast forward command.\n", AVRCP_CMD_FAST_FORWARD);
	printf("%d.	Avrcp rewind command.\n", AVRCP_CMD_REWIND);
	printf("%d.	Avrcp forward command.\n", AVRCP_CMD_FORWARD);
	printf("%d.	Avrcp backward command.\n", AVRCP_CMD_BACKWARD);
	printf("%d.	Avrcp Player Get Settings.\n", AVRCP_CMD_PLAYER_GET_SETTINGS);
	printf("%d.	Avrcp Player Set Settings.\n", AVRCP_CMD_PLAYER_SET_SETTINGS);
	printf("%d.	Avrcp send register_volume_changed_notification response to CT(phone).\n", AVRCP_CMD_REGISTER_VOL_CHANGED_NOTIF_RSP);
	printf("%d.	AVRCP get nowplaying list..\n", AVRCP_CMD_GET_NOWPLAYING_LIST);
	printf("%d.	Avrcp get folder list..\n", AVRCP_CMD_GET_FOLDER_LIST);
	printf("%d.	Avrcp get player list..\n", AVRCP_CMD_GET_PLAYER_LIST);
	printf("%d.	Avrcp set addressed player.\n", AVRCP_CMD_SET_ADDRESSED_PLAYER);
	printf("%d.	Avrcp change folder path down.\n", AVRCP_CMD_CHANGE_FOLDER_PATH_DOWN);
	printf("%d.	Avrcp change folder path up.\n", AVRCP_CMD_CHANGE_FOLDER_PATH_UP);
	printf("%d.	Avrcp get total number of items.\n", AVRCP_CMD_GET_TOTAL_NUMBER_OF_ITEMS);
	printf("%d.	Avrcp play item.\n", AVRCP_CMD_PLAY_ITEM);
	printf("%d.	Avrcp cancel browsing\n", AVRCP_CMD_CANCEL_BROWSING);
	printf("\n");
	printf("Please choose a command(enter the index of command,'q' to quit.):\n");
	printf(">");
	fgets(buffer, 16, stdin);

	if (buffer[0] == 'q' || buffer[0] == 'Q') {
		quit_client();
	} else if (buffer[0] == 'b' || buffer[0] == 'B') {
		return 0;
	} else if (buffer[0] == '\n') {
		return ENTER;
	}

	cmd = atoi(buffer);

	return cmd;
}
/*local func*/
static uint8_t *select_uid()
{
	int i = 0;
	char buffer[16];
	printf("---->Total items: %d.\n", s_arr_count);
	for(i = 0; i<s_arr_count; i++)
	{
		printf("%d.	Avrcp item uid:%02X%02X%02X%02X%02X%02X%02X%02X.\n", i, 
				uid_arr[i][0], uid_arr[i][1], uid_arr[i][2], uid_arr[i][3], uid_arr[i][4], uid_arr[i][5], uid_arr[i][6], uid_arr[i][7]);
	}
	printf("\n");
	printf("Please choose a uid(enter the index of uid, if input error, default choose 1.):\n");
	printf(">");

	fgets(buffer, 16, stdin);
	int index = 1;
	if(buffer[0] == '\n') {
		return uid_arr[1];
	}
	
	index = atoi(buffer);
	if(index >= s_arr_count) {
		index = 1;
	}

	return uid_arr[index];
}
