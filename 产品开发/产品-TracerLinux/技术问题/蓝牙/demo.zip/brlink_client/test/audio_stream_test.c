#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "brt_audio_stream.h"

//#define OUT_PUT_FILE

#ifdef OUT_PUT_FILE
#include "wav_file.h"
#define OUT_PUT_DIR "/run/media/sda4" 
static WAV_FILE_HANDLE fp;
#endif

void audio_stream_open(int stream_type, int rate, int chnl, int bit)
{
	printf("%s------->stream_type:%d, rate:%d, chnl:%d, bit:%d\r\n", __func__, stream_type, rate, chnl, bit);
#ifdef OUT_PUT_FILE
	char file[256];
	memset(file, 0, 256);
	if(stream_type == AUDIO_STREAM_TYPE_SCO) {
		snprintf(file, 256, "%s%s", OUT_PUT_DIR, "sco_player.wav");
	} else {
		snprintf(file, 256, "%s%s", OUT_PUT_DIR, "a2dp_music.wav");
	}
	printf("wav_file_open :%s\r\n", file);
	fp = wav_file_open(file, rate, chnl, bit);
#endif
}

void audio_stream_close()
{
	printf("audio_stream_close-------->>>\r\n");
#ifdef OUT_PUT_FILE
	if(fp > 0) {
		wav_file_close(fp);
	}
#endif
}

void audio_stream_cbk(uint8_t stream_type, uint8_t codec_type, uint16_t len, uint8_t *data)
{
	printf("%s------>stream_type:%d, codec_type:%d, len:%d\r\n", __func__, 
			stream_type, codec_type, len);
#ifdef OUT_PUT_FILE
	if(fp > 0) {
		wav_file_write(fp, data, len);
	} else {
		printf("file is not open!!!");
	}
#endif
}

static audio_stream_callback_t s_audio_stream_cbks = {
	audio_stream_cbk
};

audio_stream_callback_t *hlp_audio_stream_get_cbks()
{
	return &s_audio_stream_cbks;
}
