#include <stdio.h>
#include <string.h>
#include "gatt_client_conn_info.h"

static conn_info_t conn_info;

void conn_info_init(uint8_t client_if, uint16_t conn_id)
{
	memset(&conn_info, 0, sizeof(conn_info));
	conn_info.client_if = client_if;
	conn_info.conn_id = conn_id;
}

void conn_info_destroy()
{
	memset(&conn_info, 0, sizeof(conn_info));
}

conn_info_t *get_conn_info(uint16_t conn_id)
{
	//TODO add lock
	if (conn_info.conn_id == conn_id) {
		return &conn_info;
	}
	return NULL;
}

static int is_service_exist(uint16_t srvcInstId)
{
	int i = 0;
	for (i; i < conn_info.srvc_num; i++) {
		if (conn_info.gatt_srvc_array[i].srvcInstId == srvcInstId) {
			return 1;
		}
	}

	return 0;
}

static int is_chara_exist(uint16_t srvcInstId, uint16_t charInstId)
{
	int i = 0;
	int j = 0;
	for (i; i < conn_info.srvc_num; i++) {
		if (conn_info.gatt_srvc_array[i].srvcInstId == srvcInstId) {
			for (j; j < conn_info.gatt_srvc_array[i].chara_num; j++) {
				if(conn_info.gatt_srvc_array[i].gatt_chara_array[j].charInstId == charInstId) {
					return 1;
				}
			}
		}
	}
	return 0;
}

static int is_desc_exist(uint16_t srvcInstId, uint16_t charInstId, uint16_t descrInstId)
{
	int i = 0;
	int j = 0;
	int k = 0;
	for (i; i < conn_info.srvc_num; i++) {
		if (conn_info.gatt_srvc_array[i].srvcInstId == srvcInstId) {
			for (j; j < conn_info.gatt_srvc_array[i].chara_num; j++) {
				if (conn_info.gatt_srvc_array[i].gatt_chara_array[j].charInstId == charInstId) {
					for (k; k < conn_info.gatt_srvc_array[i].gatt_chara_array[j].desc_num; k++) {
						if (conn_info.gatt_srvc_array[i].gatt_chara_array[j].gatt_desc_array[k].descrInstId == descrInstId) {
							return 1;
						}
					}
				}
			}
		}
	}
	
	return 0;
}

void conn_info_add_service(uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid)
{
	if (is_service_exist(srvcInstId)) {
		return;
	}

	GATT_Service_t *gatt_srvc_array = conn_info.gatt_srvc_array;

	gatt_srvc_array[conn_info.srvc_num].srvcType = srvcType;
	gatt_srvc_array[conn_info.srvc_num].srvcInstId = srvcInstId;
	memcpy(&gatt_srvc_array[conn_info.srvc_num].srvcUuid, &srvcUuid, sizeof(bt_uuid_t));

	conn_info.srvc_num++;
}

void conn_info_add_characteristic(uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint8_t charProp)
{
	if (is_chara_exist(srvcInstId, charInstId)) {
		return;
	}

	GATT_Service_t *gatt_srvc = get_gatt_srvc_by_instId(srvcInstId);

	gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].srvcType = srvcType;
	gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].srvcInstId = srvcInstId;
	memcpy(&(gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].srvcUuid), &srvcUuid, sizeof(bt_uuid_t));
	gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].charInstId = charInstId;
	memcpy(&(gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].charUuid), &charUuid, sizeof(bt_uuid_t));
	gatt_srvc->gatt_chara_array[gatt_srvc->chara_num].charProp = charProp;

	gatt_srvc->chara_num++;
}

void conn_info_add_descriptor(uint8_t srvcType, uint16_t srvcInstId, bt_uuid_t srvcUuid, uint16_t charInstId, bt_uuid_t charUuid, uint16_t descrInstId, bt_uuid_t descrUuid)
{
	if (is_desc_exist(srvcInstId, charInstId, descrInstId)) {
		return;
	}

	GATT_Service_t *gatt_srvc = get_gatt_srvc_by_instId(srvcInstId);
	GATT_Chara_t *gatt_chara = get_gatt_chara_by_instId(gatt_srvc, charInstId);

	gatt_chara->gatt_desc_array[gatt_chara->desc_num].srvcType = srvcType;
	gatt_chara->gatt_desc_array[gatt_chara->desc_num].srvcInstId = srvcInstId;
	memcpy(&(gatt_chara->gatt_desc_array[gatt_chara->desc_num].srvcUuid), &srvcUuid, sizeof(bt_uuid_t));
	gatt_chara->gatt_desc_array[gatt_chara->desc_num].charInstId = charInstId;
	memcpy(&(gatt_chara->gatt_desc_array[gatt_chara->desc_num].charUuid), &charUuid, sizeof(bt_uuid_t));
	gatt_chara->gatt_desc_array[gatt_chara->desc_num].descrInstId = descrInstId;
	memcpy(&(gatt_chara->gatt_desc_array[gatt_chara->desc_num].descrUuid), &descrUuid, sizeof(bt_uuid_t));

	gatt_chara->desc_num++;
}

GATT_Service_t *get_gatt_srvc_by_instId(uint16_t srvcInstId)
{
	int i = 0;
	for (i; i < conn_info.srvc_num; i++) {
		if (srvcInstId == conn_info.gatt_srvc_array[i].srvcInstId) {
			return &(conn_info.gatt_srvc_array[i]);
		}
	}
	return NULL;
}

GATT_Chara_t *get_gatt_chara_by_instId(GATT_Service_t *gatt_srvc, uint16_t charInstId)
{
	int i = 0;
	for (i; i < gatt_srvc->chara_num; i++) {
		if (charInstId == gatt_srvc->gatt_chara_array[i].charInstId) {
			return &(gatt_srvc->gatt_chara_array[i]);
		}
	}
	return NULL;
}







