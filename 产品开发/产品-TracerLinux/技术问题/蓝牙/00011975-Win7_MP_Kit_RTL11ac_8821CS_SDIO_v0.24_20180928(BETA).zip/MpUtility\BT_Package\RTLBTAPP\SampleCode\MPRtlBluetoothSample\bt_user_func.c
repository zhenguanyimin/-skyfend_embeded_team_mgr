#include "bt_user_func.h"
/***********************************************************************************
*	The function is provided by the vendor to coding. 
*	The function is Waiting function. 
*	@Name :UserDefinedWaitMs
*	<-return : None
*	          
*
***********************************************************************************/
void
UserDefinedWaitMs(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned long WaitTimeMs
	)
{
    Sleep(WaitTimeMs);
	return;
}
/***********************************************************************************
*	The function is provided by the vendor to coding. 
*	To open the device. 
*	@Name :UserDefined_Open_Func
*	<-return : 0  	 succress
*	         other   Fail  
*
***********************************************************************************/
int
UserDefined_Open_Func(
	BASE_INTERFACE_MODULE *pBaseInterface
	)
{
	return 0;	
}	

/***********************************************************************************
*	The function is provided by the vendor to coding. 
*	To send messages to the device. 
*	@Name :UserDefined_Send_Func
*	->pWritingBuf    	: Poting is unsigned char type,  Writing Buffer  
*	->Len	       	: unsigned long type ,  Reading Buffer size
*	<-return : 0  	 succress	 	
*	           other   Fail  
*
***********************************************************************************/
int
UserDefined_Send_Func(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned char *pWritingBuf,
	unsigned long Len
	)
{
	return 0;	

}		

/***********************************************************************************
*	The function is provided by the vendor to coding. 
*	To receive messages from the device. 
*	@Name :UserDefined_Recv_Func
*	->pReadingBuf    	: Poting is unsigned char type,  Reading Buffer  
*	->Len	       	: unsigned long type ,  Reading Buffer size	 	
*	->pRetLen 	: Poting is unsigned long type, Reading data Length
*	<-return : 0  	 succress
*	         other   Fail  
*
***********************************************************************************/

int
UserDefined_Recv_Func(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned char *pReadingBuf,
	unsigned long Len,
	unsigned long *pRetLen
	)
{
	return 0;	
	
}		

/***********************************************************************************
*	The function is provided by the vendor to coding. 
*	To close the device. 
*	@Name :UserDefined_Close_Func
*	<-return : 0  	 succress
*	         other   Fail  
*
***********************************************************************************/
int
UserDefined_Close_Func(
	BASE_INTERFACE_MODULE *pBaseInterface
	)
{
	return 0;
}		