#ifndef BT_MP_DLL_BUILD_H
#define BT_MP_DLL_BUILD_H

#include "RtlBluetoothMP.h"


void ReleaseBTPMPDLLObject(BASE_BTMPDLLObject *Modlue);

int BuildBTMPDLLObject(BASE_BTMPDLLObject *Modlue,char *SettingPath,int VendorVersion);

#endif