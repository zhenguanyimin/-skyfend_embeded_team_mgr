//---------------------------------------------------------------------------

#ifndef rtkbtTrxThreadUnitH
#define rtkbtTrxThreadUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
extern "C"
{
        #include "RtlBluetoothMP.h"
}

#include <stdio.h> 
#include <stdlib.h> 
//---------------------------------------------------------------------------
class rtkbtTrx : public TThread
{
  typedef struct tagTHREADNAME_INFO
  {
    DWORD dwType;     // must be 0x1000
    LPCSTR szName;    // pointer to name (in user addr space)
    DWORD dwThreadID; // thread ID (-1=caller thread)
    DWORD dwFlags;    // reserved for future use, must be zero
  } THREADNAME_INFO;
private:
  void SetName();

protected:
        void __fastcall Execute();
public:
        __fastcall rtkbtTrx(bool CreateSuspended);
public:
        int TX_RX;
	FILE *fp_cfo;

	unsigned long	oldTotalRxCounts;
	
        BASE_BTMPDLL_MODULE *pBluetoothModule;
        BT_PARAMETER *pParam;
        void SetUpdateTime(int Time);
        DWORD ReportUpdateTime;
	void SetTxRxUpdata(BASE_BTMPDLL_MODULE *pSourceBluetoothModule,unsigned long Command,BT_PARAMETER *pBTParam);

};
//---------------------------------------------------------------------------
#endif
 
