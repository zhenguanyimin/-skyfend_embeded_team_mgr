//---------------------------------------------------------------------------

#ifndef ShowUnitH
#define ShowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class SowObject : public TThread
{
  typedef struct tagTHREADNAME_INFO
  {
    DWORD dwType;     // must be 0x1000
    LPCSTR szName;    // pointer to name (in user addr space)
    DWORD dwThreadID; // thread ID (-1=caller thread)
    DWORD dwFlags;    // reserved for future use, must be zero
  } THREADNAME_INFO;
private:
  void SetName();
protected:
        void __fastcall Execute();
public:
        __fastcall SowObject(bool CreateSuspended);
public:

       DWORD SettingOfTimeOut;
       int SettingMaxValue;
       void SetTimeOutTime(int timeout,int Maxvalue);
       void PowerTrackProcess();
       int LeTest_TxGainValue  ;
       int ChipIndex ;
       int Mode;
       unsigned long LeTest_TxTestTime;

       void SetMode(int in);
       void SetLeTestPara(int inChipIndex,int inLeTest_TxGainValue,unsigned long inLeTest_TxTestTime);
       void ShowUIExecute();

};
//---------------------------------------------------------------------------
#endif
