#ifndef _BT_USER_FUNC_H
#define _BT_USER_FUNC_H
#include "RtlBluetoothMP.h"
/***********************************************************************************
*	The User define function is provided by the vendor to coding. 
*       To build interface needed api.    
*       Please refer to the "BTMPAPI_BuildInterfaceVendor" API structure,"RtlBluetoothMP.h" File 
*       and "bt_user_func.c" File 
*
*
*	RTKBTMP_API int BTMPAPI_BuildInterfaceVendor(
	BASE_INTERFACE_MODULE **ppBaseInterface,
	BASE_INTERFACE_MODULE *pBaseInterfaceModuleMemory,
	//Parmater
	unsigned int InterFaceType,
	unsigned char PortNo,
	unsigned long Baudrate,
	//basic fuction
	BASE_FP_OPEN Open,
	BASE_FP_SEND Send,
	BASE_FP_RECV Recv,
	BASE_FP_CLOSE Close,
	// ADB  
	unsigned long	TimeOut,     				   //Only ADB
	BASE_FP_ADB_SEND_WITH_RSP_BY_STRING ADBSendWithRspByString,//Only ADB
	BASE_FP_WAIT_MS WaitMs
	);
*
***********************************************************************************/
void
UserDefinedWaitMs(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned long WaitTimeMs
	) ;

int
UserDefined_Open_Func(
	BASE_INTERFACE_MODULE *pBaseInterface
	);



int
UserDefined_Send_Func(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned char *pWritingBuf,
	unsigned long Len
	);



int
UserDefined_Recv_Func(
	BASE_INTERFACE_MODULE *pBaseInterface,
	unsigned char *pReadingBuf,
	unsigned long Len,
	unsigned long *pRetLen
	);



int
UserDefined_Close_Func(
	BASE_INTERFACE_MODULE *pBaseInterface
	);




#endif