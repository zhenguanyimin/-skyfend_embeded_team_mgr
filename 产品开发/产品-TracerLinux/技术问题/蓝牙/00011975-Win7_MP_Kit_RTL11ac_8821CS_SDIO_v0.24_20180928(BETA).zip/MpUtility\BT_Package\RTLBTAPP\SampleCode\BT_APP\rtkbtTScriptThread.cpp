//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop


#include "FormMainUnit.h"
#include "rtkbtTScriptThread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TScript_Thread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall WorkerThread::WorkerThread(bool CreateSuspended)
        : TThread(CreateSuspended)
{


}

void WorkerThread::SetName()
{
        THREADNAME_INFO info;
        info.dwType = 0x1000;
        info.szName = "WorkerThread";
        info.dwThreadID = -1;
        info.dwFlags = 0;

        __try
        {
                 RaiseException( 0x406D1388, 0, sizeof(info)/sizeof(DWORD),(DWORD*)&info );
        }
        __except (EXCEPTION_CONTINUE_EXECUTION)
        {
        }
}

//---------------------------------------------------------------------------
void __fastcall WorkerThread::Execute()
{
	SetName();
	//---- Place thread code here ----
	FreeOnTerminate = true;

	MSG msg;
	BOOL bRet;
	String dstr;

	PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE);

	while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0)
	{
		if (bRet == -1)
		{
			// Handle the error and possibly exit
			dstr.sprintf("Execute: GetMessage error (%d)\n", GetLastError());
			Form_Main->Memo_msg->Lines->Add(dstr);
			continue;
		}

		switch (msg.message)
		{
		case MSG_BATTERY_RESISTANCE_CAL:
			ThreadBatteryResistanceCal();
			break;			
			
		default:
			break;
		}
	}
	
}
//---------------------------------------------------------------------------


void __fastcall WorkerThread::ThreadBatteryResistanceCal()
{
	String dstr;

	int i;
	unsigned char pData[512];
	unsigned char pEvtBuf[512];
	int Result;
	int tmp;
	
	unsigned int BatteryResistanceCal_FastChargeCurrent = StrToInt(Form_Main->Edit_BatteryResistanceCal_FastChargeCurrent->Text);
	unsigned int BatteryResistanceCal_AvgTimes = StrToInt(Form_Main->Edit_BatteryResistanceCal_AvgTimes->Text);
	
	if(Form_Main->pBluetoothModule == NULL)
	{
		dstr.sprintf(">>BluetoothModule is NULL...!!\n");Form_Main->Memo_msg->Lines->Add(dstr);
		return;
	}

	Form_Main->Button_BatteryResistanceCal->Enabled = false;

	Result = 0;

	for( i = 0; i < BatteryResistanceCal_AvgTimes; i++)
	{
		tmp = 0;
		pData[0] = 1;
		pData[1] = BatteryResistanceCal_FastChargeCurrent&0xff;
		pData[2] = (BatteryResistanceCal_FastChargeCurrent>>8)&0xff;
	
		if(Form_Main->pBluetoothModule->SendHciCommandWithEvent(Form_Main->pBluetoothModule, HCI_VENDOR_CHARGER_TEST, 3, pData, 0x0E, pEvtBuf)!=BT_FUNCTION_SUCCESS)
			goto error;
		
		tmp = pEvtBuf[6] | pEvtBuf[7]<<8;

		//dstr.sprintf("%dth : tmp = %d\n", i, tmp);Memo_msg->Lines->Add(dstr);
		
		Result +=tmp;

	}

	Result = Result / BatteryResistanceCal_AvgTimes;

	dstr.sprintf("%d\n", Result);

	Form_Main->Button_BatteryResistanceCal->Enabled = true;


	if(Result == 0)
	{
		 Application->MessageBox("Battery resistance calculates unsuccessfully", "ERROR", 16);
	}
	else
	{			
		Form_Main->Edit_BatteryResistanceCal_Result->Text = dstr;

		dstr.sprintf("Battery resistance calculates successfully = %d (mO)!!\n", Result); Form_Main->Memo_msg->Lines->Add(dstr);
	}

	return;  

error:
        Form_Main->Button_BatteryResistanceCal->Enabled = true;
        dstr.sprintf("Battery resistance calculates unsuccessfully!!\n"); Form_Main->Memo_msg->Lines->Add(dstr);

	return;

}

