#ifndef RTKBTMPDLL_H
#define RTKBTMPDLL_H

#define RTKBT_DYNAMIC_EXPORTS


#ifdef RTKBT_DYNAMIC_EXPORTS
#define API_RtKBTMP __declspec(dllexport)  //dynamic import
#else
#define API_RtKBTMP __declspec(dllimport)  //static import
#endif



typedef struct _RTKBT_TRXSTATISTICS
{
	unsigned long   RxBits;
	unsigned long   ErrorBits;
	float           RxBER;			// in %
	unsigned long   RSSI;			//in dBm
	float   CFO;				    //in KHz
	float   SignalQuality;
	unsigned long   TxBits;
} RTKBT_TRXSTATISTICS;


typedef struct _RTKBT_TRXPARAM
{
	UINT8      Rate;                 		// 1~3       
	UINT8      Channel;           		// 0~78
	UINT32     TxPktCnt;        		// 0: continue packet Tx 
	UINT8      TxPKtInterval;		//0~15-> 100ns~1600ns
	UINT8      PayloadType;      	 //0: ("All 0's"), 1:("All 1's"), 2:("0101"), 3:("1010"), 4:("0x0~0xf")  
	UINT16     PayloadLength;  		 // in bits, 1 ~ 8191
	UINT32     PacketHeader;            //0x0 ~ 0x3ffff
	UINT8      WhitenCoeff;		 // 0x0~ 0x7f, Whitening disable if out of this range
	char       BDAddress[13];           //13 hex digits
	UINT8      TxGainIndex;             // 1~7
} RTKBT_TRXPARAM;


typedef enum 
{
	eNoError=0,                //0
	eAdapterInitialFail,
	eInvalidHostType,
	eInvalidUSBPortNumber,
	eInvalidUARTPortNumber,
	eInvalidPCIePortNumber,  //5
	eInvalidUARTBaudRate,
	eNotRTKBTChip,
	eInvalidDataRate,
	eInvalidTxPktInterval,
	eInvalidChannelNumber,   //10
	eInvalidPayloadType,
	eInvalidPayloadLength,
	eInvalidPacketHeader,
	eInvalidBDAddress,
	eInvalidRegsiterType,   //15
	eInvalidTxIndex,
	eHCIResetFail,
	eEnableDUTModeError,
	eRedundancyTestAction,
	ePacketTxFail,   //20
	eContinueTxFail,
	ePacketRxFail,
	eStopFail,
	eCFOAdjustFail,
	eNotSupport,        //25
	eUnknowError,
	eNoHCIEventResponse,
	eHostInitFail,
	eInvalidTxGainIndex,
	eH5toH4TranslateFail,   //30
	eTestActionIsStillRunning,
    eH52H4Failed,
    eAdapterFromIsNotOpen ,
    eSettingModuleTypeFail,

	////////// new error define /////////
    eBtMpDllBuidFail,
    eBtOpenPorFail,
    eBtDownLoadPatchCodeFail,
    eBtModuleIsNull,
    eBtExecJobFail,
    eBtNoSuppost,
    eBtInvalidTestMode,
    eBtSetDefaultPowerFail,
    eErrorOfNumber  
}_ErrorCode;

#ifndef PG_EFUSE_CONFIG
#define PG_EFUSE_CONFIG
enum  PG_EFUSE_TAG
{
	SET_INDEX_BT_ADDR = 0,
	SET_INDEX_THERMAL,
	SET_INDEX_TX_POWER_DAC,
	SET_INDEX_XTAL,
	SET_INDEX_USB_VID_PID,		//pData[]= 0xDA,0x0B,0x68,0x81 => VID:0BDA PID:8168
};

#endif


#ifdef __cplusplus  
 extern "C" {
#endif                                   

#ifndef RTKBT_DYNAMIC_EXPORTS   //for static import


API_RtKBTMP int		RTKBT_MP(void); 
API_RtKBTMP bool	RTKBT_OpenAdapter(UINT8 HostType, UINT8 PortNo, UINT32 Rate);
API_RtKBTMP bool	RTKBT_CloseAdapter();
API_RtKBTMP bool	RTKBT_HCIReset();
API_RtKBTMP UINT32  	RTKBT_GetLastError();
API_RtKBTMP bool	RTKBT_ClearCounter();
API_RtKBTMP bool	RTKBT_RadioOff();
API_RtKBTMP bool	RTKBT_ShowUI(bool IsShow);
API_RtKBTMP bool	RTKBT_BTTestMode(UINT8 Type);
API_RtKBTMP bool	RTKBT_GetStatistics(RTKBT_TRXSTATISTICS* statistics);
API_RtKBTMP bool	RTKBT_StartPacketTx();
API_RtKBTMP bool	RTKBT_StartContinueTx();
API_RtKBTMP bool	RTKBT_StartRx();
API_RtKBTMP bool	RTKBT_StartSignalToneTx(); 
API_RtKBTMP bool	RTKBT_StopTest();
API_RtKBTMP bool	RTKBT_SetTRxParameters(RTKBT_TRXPARAM params);
API_RtKBTMP UINT8  RTKBT_ReadThermalMeter();
API_RtKBTMP bool	RTKBT_QueryTRxStatus();
API_RtKBTMP bool	RTKBT_SetUARTType(int type);
API_RtKBTMP bool	RTKBT_H52H4(int PortNumber,int Baudrate,int TimeOut_mSec);
API_RtKBTMP bool	RTKBT_ModuleSelect(int ModuleType);
API_RtKBTMP int		RTKBT_GetComHandle(HANDLE *ComHandle,HANDLE *ComEventHandle);
API_RtKBTMP UINT8*	RTKBT_SendHCICmd(UINT16 nOpcode, UINT8 nLength, UINT8* lpParam, UINT8 nEventcode);
API_RtKBTMP bool	RTKBT_SetRTL8761XTAL(unsigned char Value); 
API_RtKBTMP bool	RTKBT_WriteReg(UINT32 type, UINT32 RegAddr, UINT32 RegValue, UINT32 bitmask);
API_RtKBTMP UINT32 	RTKBT_ReadReg(UINT32 type, UINT32 RegAddr, UINT32 bitmask);
API_RtKBTMP bool	RTKBT_TxPowerAdjust(UINT8 FineTuneIndex) ;  //CorseTuneIndex: TBD, FineTuneIndex:1~5
API_RtKBTMP bool RTKBT_WriteMpParamterToConfig(unsigned char Index, unsigned char *pData);
API_RtKBTMP bool RTKBT_WriteMpParamterToEfuse(unsigned char Index, unsigned char *pData);
API_RtKBTMP bool	RTKBT_WriteMpPowerOnFunctionToEfuse(int PowerOn_enable,int PowerOn_Active);
#endif

#ifdef __cplusplus  
	}                                     
#endif


#endif
