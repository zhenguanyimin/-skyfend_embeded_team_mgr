*************************************************************************
   ____  ____ 
  /   /\/   / 
 /___/  \  /   
 \   \   \/    � Copyright 2017-2020 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary 
  /   /        information of Xilinx, Inc. and is protected under U.S. 
 /___/   /\    and international copyright and other intellectual 
 \   \  /  \   property laws. 
  \___\/\___\ 
 
*************************************************************************

Vendor: Xilinx 
Current readme.txt Version: 2.1
Date Last Modified:  18NOV2020
Date Created: 18NOV2020

Associated Filename: xapp1319-zynq-usp-prog-nvm.zip
Associated Document: XAPP1319, Programming BBRAM and eFUSEs

Supported Device(s): Zynq UltraScale+ MPSoC Devices
   
*************************************************************************

Disclaimer: 

      This disclaimer is not a license and does not grant any rights to 
      the materials distributed herewith. Except as otherwise provided in 
      a valid license issued to you by Xilinx, and to the maximum extent 
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE 
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL 
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, 
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and 
      (2) Xilinx shall not be liable (whether in contract or tort, 
      including negligence, or under any other theory of liability) for 
      any loss or damage of any kind or nature related to, arising under 
      or in connection with these materials, including for any direct, or 
      any indirect, special, incidental, or consequential loss or damage 
      (including loss of data, profits, goodwill, or any type of loss or 
      damage suffered as a result of any action brought by a third party) 
      even if such damage or loss was reasonably foreseeable or Xilinx 
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or 
      for use in any application requiring fail-safe performance, such as 
      life-support or safety devices or systems, Class III medical 
      devices, nuclear facilities, applications related to the deployment 
      of airbags, or any other applications that could lead to death, 
      personal injury, or severe property or environmental damage 
      (individually and collectively, "Critical Applications"). Customer 
      assumes the sole risk and liability of any use of Xilinx products 
      in Critical Applications, subject only to applicable laws and 
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS 
FILE AT ALL TIMES.

*************************************************************************

This readme file contains these sections:

1. REVISION HISTORY
2. OVERVIEW
3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
4. DESIGN FILE HIERARCHY
5. INSTALLATION AND OPERATING INSTRUCTIONS
6. OTHER INFORMATION
7. SUPPORT


1. REVISION HISTORY 

            Readme  
Date        Version      Revision Description
=========================================================================
18NOV2020   2.1          Xilinx release for 2020.1.
31AUG2020   2.0          Xilinx release for 2019.2.
15May2017   1.0          Initial Xilinx release.
=========================================================================



2. OVERVIEW

This readme describes how to use the files that come with XAPP1319. 

This reference design shows how to build a system for programming BBRAM and eFUSEs in Zynq UltraScale+ MPSoC. 
It shows followings: "Programming the AES Key in BBRAM", "Programming eFUSEs for AES and RSA Cryptographic Functions" and "Programming eFUSEs for Using PUF".



3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS

Software:
  -- Vivado Design Suite - 2020.1
  -- Xilinx Vitis software platform - 2020.1
  -- Communication Terminal (as TeraTerm)
  -- Silicon Labs USB to serial Windows Drivers
     

Hardware:
  -- Either Xilinx ZCU102 Development Board or Avnet UltraZed-EG board
  -- 16 GB uSD 
  -- Two Micro USB Cables
  -- 5 V power supply from USB port



4. DESIGN FILE HIERARCHY

The directory structure underneath this top-level folder is described
below:

|-- readme.txt                      	#  This file
|-- aes.nky                         	# AES key sources for programming the AES Key in BBRAM
|-- aes_fsbl.nky                    	# FSBL AES key sources for programming the AES Key in BBRAM
|-- xilskey_bbramps_zynqmp_example.c  	# This source file illustrates how to program AES key of ZynqMP BBRAM
|-- xilskey_efuseps_zynqmp_input.h      # This header file is used is programming eFUSEs for AES and RSA cryptographic functions
|-- xilskey_puf_registration.h          # This header file is used is programming eFUSEs for using PUF


5. INSTALLATION AND OPERATING INSTRUCTIONS 

1) Install the Xilinx Vivado 2020.1 and Vitis 2020.1.
2) See https://www.xilinx.com/support/documentation/boards_and_kits/zcu102/xtp426-zcu102-quickstart.pdf for setup of the ZCU102 board.
Please see the Getting Started with the Avnet UltraZed-EG Starter Kit for setup of the Avnet board.
3) Please follow the steps in XAPP13191319 - "Programming the AES Key in BBRAM", "Programming eFUSEs for AES and RSA Cryptographic Functions" and "Programming eFUSEs for Using PUF".



6. OTHER INFORMATION (OPTIONAL) 

Please note that this design design example files should only be used with Vitis 2019.2.


7. SUPPORT

To obtain technical support for this reference design, go to 
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database.  